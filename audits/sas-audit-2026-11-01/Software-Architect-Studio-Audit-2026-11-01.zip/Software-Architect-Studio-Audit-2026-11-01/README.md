# Software Architect Studio audit — 1 November 2026

Public repository export. Read PUBLICATION.md and repository-export-disclosure.json for publication scope and omitted private metadata.

Start with index.html for a browsable offline report, or AUDIT.md for the thirty-section assessment.

Native Google Doc: [private document link omitted]

Source of record: https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/tree/1fa377cc9cbe7054d7edbf8091e22efaa296c05e

This is a READ-ONLY audit and proposed redesign. No repository/plugin implementation, installation, connection, permission, publication or deployment was changed. The user authorized the separate Google Doc and downloadable ZIP.

Contents:
- AUDIT.md: reconciled30-section report, including final runtime transition and source boundaries.
- specialist01 through specialist10: all independent eighteen-section reports, cross-reviews, retained synthetic probe scripts/results/logs and relevant source/routing/runtime observations.
- github-skills-and-drafts.md and github-skill-adoption.json: seventeen inspected instruction candidates from six repositories, exact pinned URLs, ownership, license evidence, decisions and four original proposed references.
- implementation-initiatives.md: eleven bounded initiatives with acceptance, regression, error/security, prerequisites, effort, risks and rollback.
- benchmarks-and-stress.md / benchmark-contracts.json: twenty prospective lifecycle benchmarks and thirty stress scenarios. No live model baseline is fabricated.
- evidence-and-inventory.md, source-identity.json, component-inventory.json and document-readback-verification.json: exact source inventory, current test/blocked-check ledger, runtime observations and all20 native Doc tab readback results.
- historical regression and eleven-skill inventories are in specialist10 and specialist07 respectively.
- proposed-diagrams.md: six Mermaid logical maps covering system, routing, tools, context, code/verification, trust/providers, impact and recovery. Rendering was blocked; no render success is claimed.
- github/: captured read-only primary GitHub evidence, including reviewed skill definitions, selected rule files and applicable retrieved license texts. These are evidence snapshots, not an installable skill bundle. Uninspected helpers/scripts/hooks/assets/agents are excluded from adoption.
- scope/user-brief.txt: the supplied mandate.
- audit-package-manifest.json: SHA256 and size of every included file except the manifest itself. These hashes detect mismatches; they are not signatures/authentication.

Evidence boundaries:
193 Python tests passed with zero skips;37 Node minimal-DOM checks passed. Nine actual browser cases were blocked before execution by loopback socket policy; mmdc was absent. The audited remote GitHub run failed YAML parsing before jobs. Complete real-model/user-quality benchmarks and production/security/performance/provider-deployment checks remain unmeasured.

Runtime catalog initially exposed seven older roots, then refreshed during the audit. The final independently captured eleven root definitions exactly matched GitHub0.9.1. The cause/backend/helper parity remains unknown; this audit performed no publication.

Reproduction scripts use the original /workspace paths and disposable fixture locations. Inspect them before use and adapt source/scratch paths to a separately authorized checkout of the pinned commit. The ZIP does not include the entire repository, installed dependencies, browser binaries or copied QA checkout. Do not execute scripts or upstream helpers as an automatic installation step. Original scripts/results are retained for provenance, not presented as portable turnkey tooling.

Third-party terms:
Source URLs, immutable revisions and licenses are recorded per candidate. Superpowers MIT and inspected OpenAI/Anthropic/Microsoft Apache2 texts are included where fetched. The two selected Vercel skills declare MIT; standalone notice packaging remains an adoption prerequisite. Trail of Bits documentation is CC-BY-SA4.0; captured original material retains its source attribution and applicable license. A derivative requires full applicable compliance, not merely a separate folder. These records do not assert that all source dependencies/assets were reviewed. Proposed Studio instruction texts are separate original review artifacts, not a redistribution-ready plugin.

The HTML uses local text/CSS only, performs no automatic network requests and contains no JavaScript. External source links open only when selected. All generated fixtures use synthetic values. No credentials were read or intentionally included.
