# Cross-examination and reconciled verdicts

All ten independent first passes were complete before cross-examination. One capacity failure was retried successfully. Related-model agreement is not statistical independence. The numbered assessment contains the final reconciled conclusions.

## Reviewer01

# Specialist 01 cross-examination — skill breadth and user value

2026-11-01. Read Specialist 07's completed first pass, its scoped probe results, the current capture schema/summary implementation, `proposed-skill-reference-drafts.md`, and `github-skill-adoption.json`. This is a second-stage critique; the independent product first pass remains unchanged. No new test was necessary: the distinctions below are source/contract questions, and exact existing probes answer the behavioral claims. No source, package, permissions or other specialist report was changed.

## Supported findings

* **AI-101: supported, P1 within evaluation correctness.** Current [`summarize_captures`](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/evaluation_records.py#L79) does not enforce the required capture body/lineage in the [published schema](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/schemas/capture-lineage-v1.schema.json#L4). Specialist 07's exact malformed record demonstrates green accounting without a response. Fix ingestion before using the result as a release-quality input. This is not proof of exploitable application insecurity, authenticated reviewer truth, or poor model reasoning. Separate `capture_records_valid` from `review_accounting_passed` in future output if needed; neither means representative real-world quality.
* **SKILL-101: supported, small maintenance repair.** Replace unresolved S01–S11 aliases with actual stable identifiers/links and resolve “Common input/result” to one current resource. A short prose contract is enough; a mandatory new schema, new service or extra user form is unnecessary.
* **AI-102 / PROD-103: supported as local routing limitations.** Both reviews independently obtained ordinary creation requests with no candidates. The eight/80 fixture success and selected counterexamples describe different test populations. Do not label them a measured live ChatGPT failure rate or a security authorization failure. Preserve low confidence/manual override and improve held-out intent coverage.
* **SKILL-102: supported as a current-session/source difference.** Seven exposed runtime definitions and eleven 0.9.1 source definitions are different evidence surfaces. Source identity is established; delivery causality and intended compatibility remain unknown. Inspect release content and intended host behavior before advertising all eleven as delivered. This audit should not publish/reinstall to close that gap.

## Disputed breadth and counterevidence

**“Keep eleven owners” is a conservative preservation decision, not proof that eleven outperform seven.** The boundaries look coherent, and there is no demonstrated redundancy warranting immediate deletion. However, Specialist 07 itself asks which task populations justify the four additions. Product value is still unmeasured ([observation instrument](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/research/user-observation-template.json#L2)). Keep stable IDs provisionally, keep selection invisible to ordinary users, and compare actual domain tasks before promoting the count as a benefit. Source/runtime parity can be satisfied by a documented intentional compatibility mapping; exact eleven-skill availability need not become a universal blocker for all supported seven-skill tasks.

**The proposed references mostly strengthen existing behavior.** Current [recipes](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/docs/recipes.md) already prescribe source identity, smallest coherent changes, actual browser assertions, failure states, local/remote result distinctions and honest blocked checks. The incremental contribution is sharper diagnosis/invariant examples, framework-specific conditional guidance, differential abuse-path review and exact CI parse/setup failure classification. Describe these as focused extensions; do not count four new “capabilities” or promise a transformed development lifecycle simply because a draft exists.

**A large candidate register is useful research, not a default load list.** The 17 inspected source entries span overlapping debugging, browser and security methods. Their pinned paths, license distinctions, REFERENCE/DEFER decisions and unverified-gain fields are good controls. Primary-fit selections can begin with systematic debugging/regression, browser behavior evidence, and exact CI diagnosis. React composition/performance applies only to detected React tasks; style preferences and durable CLI design remain optional. The register should say “selected strong fits among inspected candidates,” not a comprehensive ranking of GitHub's best skills. Upstream licensing findings are root research evidence, not independently reverified by this product review.

## Concrete simplifications to the drafts

1. **Integration contract line 7:** gate execution on available tools; permit the applicable static review/manual plan even when a runner/browser is absent. The current rule requiring a tool to be available before loading any reference conflicts with the drafts' own missing-tool fallbacks. Unknown versions permit general guidance; version-sensitive changes remain conditional until verified.
2. **Draft A exclusions:** replace “request with no authorized execution mechanism” as an exclusion with a specific fallback: static diagnosis can proceed, execution cannot be claimed. Avoid a compulsory positive-control exercise for every trivial correction; use it where it distinguishes competing causes.
3. **Draft B scope:** its “non-React stack” exclusion conflicts with using browser guidance for plain HTML. Make React sections conditional and keep generic DOM/keyboard/browser evidence applicable across stacks. Do not force a React reference to load for every UI task.
4. **Draft D ownership:** generic implementation and provider-specific CI are distinct triggers. Keep them as two subsections, loaded independently under their existing owners. A simple script does not need CI, migration or deployment paperwork.
5. **All drafts:** keep the detailed design fields as review artifacts, and load only the compact instruction text plus applicable examples. Dependencies name optional evidence contributors, not mandatory sequential specialist handoffs. One owner can perform a coherent authorized change without activating repository, implementation, domain, security and QA skills separately.
6. **No automatic new tooling:** retain the exclusions for latest wrappers, new login flows, forced language/tool migrations, destructive restarts, blanket TDD, unrequested delegation and extra permission gates. Preserve license/attribution review before distributing copied adaptations; unresolvable provenance means reference-only or defer.

## Measurable acceptance and rollout

First repair invalid-capture handling and current reference links. In a separate authorized implementation slice, pilot one optional reference at a time against the unchanged current bundle on declared held-out tasks. Keep source, model, available tools and task constraints equal; record the actual loaded text, outcomes, required corrections, instruction volume and clarification burden. Include quick advice, creation paraphrases, missing runner, non-React UI, live polling UI, diagnosis, malformed capture and CI parse failure slices. Report slices and disagreements rather than only an aggregate score.

Before running, define the target benefit and tolerated trade-offs. Promotion requires evidence of the declared benefit with no newly introduced critical correctness, authorization, data-loss or fabricated-success failure on the evaluated cases. A limited feasibility screen establishes only scoped evidence, not statistical superiority or broad productivity. Revert the optional reference if it adds workflow burden without a useful correction or task outcome gain. The normal user flow must still allow a simple request without a project file, mandatory interview, tool installation or specialist fan-out.

Runtime acceptance should name the release and host and state either exact source-compatible skill content or documented intentional differences. Repository-only references remain proposed until delivered and read in the intended host. Missing browser checks stay blocked; they do not prevent useful static findings. No evaluation, user study, installation or publication was performed by this cross-review.

## Final verdict and remaining dissent

Support the coherent existing owner model and selective, attributed GitHub reference adoption. Prioritize trustworthy capture ingestion, discoverable workflows and source/runtime clarity before adding instruction volume. No new top-level skill is justified by these candidates.

Remaining dissent is about evidence and sequencing: preserve eleven source owners provisionally, while treating their incremental user value as unknown; treat runtime parity as release assurance for claimed capabilities, not proof that every supported workflow is broken. The references are implementation-ready proposals to test, not demonstrated gains.

**Late capability-catalog update:** after this cross-review was written, the host announced four additional domain skill packages and an updated test-debug skill. Therefore the seven-skill observation describes the earlier first-pass snapshot, not a stable assertion about the latest runtime. The announcement establishes advertised availability only; re-read all expected definitions and compare content identity before resolving or retaining SKILL-102. Root was notified immediately. This reviewer did not independently re-read the new definitions or perform an update.


## Reviewer02

# Specialist 02 cross-examination — QA and continuity

2026-11-01. Reviewed specialist05/report.md and specialist10/report.md only after all ten independent initial passes had completed. Reinspected pinned target source; wrote and executed `cross-probe.py` solely under this specialist's scratch directory. No source edit, dependency installation, publication or whole-suite repetition occurred.

## Accepted findings and independent evidence

| Finding | Independent result | Decision |
|---|---|---|
| QA-101 — Generated handoff integrity/coverage is not validated | Generated a fresh scratch handoff with a real declared API. Intact structural validation passed with contract correspondence. Deleted the committed generation's manifest-listed `api.json`: `policy_ok` remained true and correspondence disappeared. Changed `architecture.md` bytes: result remained true. Manifest still listed API. | Accept the missing integrity/coverage dimension. Existing checks correctly report their narrower content results; they do not establish a complete unchanged generation. |
| QA-102 — Invalid AsyncAPI passes full gate | Independently submitted `{"asyncapi":"bogus","info":{},"channels":{}}`. `gate='full'` returned `policy_ok:true`; sole check was `AsyncAPI declaration:passed`, detail “basic envelope only; full schema not verified.” | Accept a deficient declaration check and absent full-format applicability. Invalid version is not a supported AsyncAPI declaration. Treat schema verification as separately unsupported/incomplete when required. |
| GOV-101 — Unmarked resume excerpt | Valid brief of 4,025 Unicode code points became 4,000; trailing constraint disappeared; packet had no excerpt/omission metadata. Canonical object was unchanged. Source confirms browser uses full brief. | Accept context-projection defect, not canonical data loss. An intentional context budget is valid if explicit and recoverable. |

All three are now **Independently reproduced** within these synthetic inputs. Evidence: `cross-probe-results.json`. Exact current source: `validation_engine.py:356–394,445–492`; `artifact_compiler.py:106–120,123–176`; `project_model.py:110–116`; `project-core.js:56`.

## Guarantees the current gates actually make

`structural` enumerates present supported files, runs their applicable checks and fails observed failures, required skips, budgets and enumeration stops. It does not compare the observed tree with the compiler manifest. Markdown is not among parsed suffixes. Therefore a deleted expected file can remove a check rather than fail it.

`full` additionally treats incomplete OpenAPI schema, Mermaid renderer and project JSON Schema checks as blocking (`validation_engine.py:485`). It is not a universal schema-validation switch for every file format: AsyncAPI has no distinct schema-check record. The result note explicitly says “Scoped structural gates only; no certification, runtime deployment or universal semantic correctness.” The QA findings should preserve this counterevidence. Do not describe the product as claiming that a full pass proves runtime behavior or architectural quality.

Compiler `review-ready` completeness is a different dimension again. My ARCH-101 blank-content counterexample remains independent of QA-101/102: a file inventory can be intact while the requirements lack meaningful content. A complete profile, consistent artifact bytes, full dialect schema, human semantic review and runtime verification must each report their own status.

## Acceptance refinements

For QA-101, detect an actual generated-handoff marker or explicitly selected integrity profile. Validate bounded manifest shape, relative paths, safe IO, duplicates, existence/type, exact byte hashes and internally consistent named identities before declaring that generation intact. Continue independent content checks and retain exact missing/changed/unchecked counts. A standalone OpenAPI file without a handoff manifest should still support structural inspection; absence of an irrelevant manifest must not break ordinary draft workflows. Do not rewrite files during validation or delete extra user notes.

Named representations matter: `canonical_input_hash`, `compiler_context_hash`, `exported_project_hash` and file-byte hashes can validly differ. Compare each to its declared representation. Do **not** compare minimized exported `project.json` directly with canonical-input hash and call the intentional disclosure transform corruption.

For QA-102, declare supported AsyncAPI dialects and minimum envelope fields. Invalid/unknown versions must not report a passed declaration. When full AsyncAPI schema verification is required but unavailable, produce explicit unsupported/skipped/incomplete status and a blocked full policy. Structural-only envelope inspection can remain useful. A new validator installation is not necessary to stop misleading gate completeness; any future validator must be pinned, offline and budgeted.

For GOV-101, preserve a bounded excerpt if useful, but publish included/omitted ranges, original length, reason, projection version and source identity. Define range units explicitly: Python Unicode code-point indexing and JavaScript UTF-16 offsets differ for non-BMP text. Cross-surface parity should concern coverage meaning, not force identical budget or packet bytes. Boundary cases need empty, absent, 3,999/4,000/4,001 and non-BMP content, plus a relevant constraint after the budget. Consumer behavior must retrieve relevant authorized omitted context or state the limit. Draft/project bytes and Accepted provenance remain unchanged.

## Rejected overreach and residual dissent

- A self-consistent rewritten manifest and artifact set cannot establish authenticity or detect all attacker-controlled changes without an externally trusted expected identity/signature. QA acceptance wording “changing generation/source identity blocks integrity policy” is valid for mismatched internal identities or an external expected baseline, not for every coherent new generation. Hashes alone do not authenticate.
- Do not call the manifest gap a failure of OpenAPI structural semantics, a semantic review, stale-file cleanup or immutable-pointer publication. These are different checks and responsibilities.
- Do not require a full schema validator for all arbitrary JSON/YAML or force all incomplete drafts into a production gate. Apply declared format/profile requirements explicitly.
- Do not treat trailing-brief omission as stored-project corruption or make raw history/extensions active context to achieve “complete memory.”
- Severity is context-dependent: P1 is justified for manifest/full-interface gates relied on for release or downstream handoff; isolated report-only file inspection has a narrower impact. No P0 incident was demonstrated.

## Final verdict

Accept all three findings with the refinements above. Reuse the existing manifest, safe IO, profile dimensions and portable project; no new service, knowledge store, dispatcher or skill is necessary. The decisive improvements are explicit coverage, format applicability and named representation identities. No substantive dissent remains on observed behavior; authenticity guarantees and universal “full” semantics must stay narrower than the proposed repairs can prove.


## Reviewer03

# Specialist 03 cross-examination — reliability and security

2026-11-01. Reviewed completed first-pass `specialist09/report.md`, `specialist06/report.md`, their probe scripts and the current pinned source. No target source edits or broad suite reruns. The two reports were read only after my independent first pass.

## Supported claims and independent reproduction

**OPS-102 is independently reproduced and remains P1.** A new probe uses separate processes and external handshake files to remove dependence on a narrow sleep window. Named check on sourceA fails in a negative control. During a second check, authorized adapter applies change A→B, the check confirms it readB, and another apply restoresB→A before completion. Both applies, the check receipt and reconciliation return `passed`; initial/final source hashes agree. Evidence: `cross_aba_probe.py`, `cross-aba/results.json`, exit0 as an observation collector. Exact reported output: `control=failed`, `apply_b=passed`, `apply_a=passed`, `observed=B`, `check=passed`, `reconcile=passed`, `source_hash_start_equals_end=true`.

This is a false source-correspondence result under cooperating operations, rather than a malicious-receipt or hostile-filesystem attack. [Adapter apply](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/execution_adapter.py#L296) locks operation state, [checks](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/execution_adapter.py#L390) do not hold that writer lock, and [reconciliation](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/execution_adapter.py#L505) compares endpoint identities. A cryptographic hash has not failed; the attribution inference has.

**SEC-101 is source-supported and supported by the first reviewer's safe actual probe.** [bounded_process](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/validation_engine.py#L248) waits for only the leader and kills its process group only on timeout. Normal leader exit leaves ordinary descendants running. Their late effects can invalidate an immediately reconciled receipt. I inspected the retained scripts/results; I did not perform a second descendant reproduction. Evidence status for this cross-review is **Directly inspected**, not independently reproduced.

**OPS-101 stale exclusive lock is supported** by source mechanism and the report's crash probe: Python `finally` cannot execute after abrupt process death, and documented recovery reacquires the existing lock. Do not inflate this into data corruption; the reviewer demonstrated blocked progress and successful prepared-journal recovery only after controlled scratch unlock.

## Challenges and refinements

1. **A shared lock is sufficient only for a declared cooperating-writer scope.** One source-root identity must map to the same lock regardless of selected operation-state directory. The lock must cover initial source capture, check lifecycle completion and final capture; adding a lock just around receipt writing does not fix ABA. An internal check that calls the adapter again needs an explicit bounded rejection rather than deadlock. Ordinary noncooperating edits, bind-mount aliases and host tooling still require a host guarantee or a downgraded result.
2. **Immutable snapshots need a precise meaning.** Copying source files while a writer mutates them is not a consistent snapshot. A tested immutable checkout plus captured dirty overlay is one option when supported. Tests must run against the named snapshot, with dependency locks, runtime/configuration, external fixtures and relevant source modes included in the check context. Environment/database/network mutation remains distinct from source identity. New metadata should not pretend to authenticate tool execution.
3. **Process-group cleanup is bounded mitigation, not hostile-tree isolation.** Normal-exit and nonzero-exit cleanup must precede output capture, final source observation and receipt publication. Preserve leader outcome separately from cleanup outcome. A failed or unsupported cleanup cannot become clean completion. A detached child can escape a process group; a cgroup/job/container guarantee belongs to a verified host, and should not become an unsupported mandatory native Studio component. Long-running development servers need explicit lifecycle operations and stop/health evidence.
4. **Lock replacement is a migration, not a local code substitution.** POSIX advisory locks generally improve process-death liveness for cooperating writers, but changing lock-file ownership semantics must account for existing v1 locks, every revision/handoff/apply/check caller and unsupported platforms. Do not release locks solely by age or PID. Preserve old metadata and explain operator recovery for unknown ownership.
5. **No general atomicity upgrade is established.** Individual atomic source replacements plus a cooperating lock do not make a multi-file apply crash-atomic. Continue reporting partial observed effects and requiring recovery inspection. Do not trade the current useful journal for a false all-or-nothing claim.
6. **Receipt test-count metadata needs restrained wording.** Parsing `Ran N tests` establishes a reported count under an agreed parser, not independently authenticated test execution. Keep parser/framework identity, skipped/expected-failure handling, argv/policy identity and actual return/cleanup outcomes. Trusted runner output can support a scoped count; arbitrary printed summaries cannot establish semantic test value. Framework parser expansion should follow real tasks, not be treated as a new language-skill requirement.
7. **SEC-102 is privacy hardening with an existing declared limitation.** Quoted/Bearer formats survive a documented incomplete minimizer. Recommend better bounded fixtures and review, but avoid describing current exports as violating a secret-free guarantee that the implementation explicitly declines. Never fix it by removing legitimate API fields named `token` or `password`.

## Concrete combined acceptance

Run the deterministic ABA fixture with a shared state directory and different state roots. The competing apply must block/refuse until checks complete, or the receipt/reconciliation must be unknown/partial/blocked. It must never verifyA from a test that observedB. Add a live competing writer, timed-out checker and nested-adapter checker; no unbounded deadlock or automatic replay.

For every normal/nonzero/timeout parent outcome, spawn an ordinary delayed descendant. No effect may occur after the claimed one-shot completion; cleanup failures stay visible. For a detached-child fixture, either demonstrate the actual host job boundary or explicitly report unsupported containment. Keep final source observation after lifecycle completion, not before.

Retest mode preservation from CODE-101 with the same source identity model: existing executable and ordinary files retain supported modes; a chmod-only concurrent change becomes a conflict; private records retain conservative modes. Hold context/plan version migration explicit. Preserve expected source, actual input/output source, check identity, leader outcome, cleanup outcome and containment scope as independent fields.

## Reconciled verdict and residual risk

I revise my first-pass broad adapter maturity from level4 to **3 — Repeatable** for source-bound implementation verification: the fresh 28-test suite and positive toy remain valid scoped evidence, but the independently reproduced ABA counterexample disproves a broader validated correspondence claim. This is evidence-driven revision, not a failed original test run. CODE-101, OPS-101, OPS-102 and SEC-101 belong in the foundational hardening release before stronger program-verification claims.

No evidence warrants a P0, an OS sandbox claim, production compromise or general generated-code quality score. Host isolation, detached process control, external dependency/data identity, live-model instruction compliance and arbitrary application correctness remain explicit limits. Keep the local toolkit and its honest boundary; fix attributable correctness before expanding skill counts.


## Reviewer04

# Specialist 04 cross-examination — Architecture and AI evidence accounting

2026-11-01. Reviewed specialist02/report.md and specialist07/report.md after all ten independent first passes completed. Independent targeted reproduction is in `cross-probe.py` and `cross-probe-results.json`; no full-suite repeats or target edits. Baseline remains commit `1fa377cc9cbe7054d7edbf8091e22efaa296c05e`.

## Supported conclusions

- **ARCH-101:** independently reproduced. A canonical NFR/task pair with whitespace acceptance and whitespace scenario passes project checks and review-ready completeness. `human_review` remains `unknown` and `runtime_verification` remains `not run`. Source: `artifact_compiler.py:16–17,37,46–49`. Accept P1 for the supported completeness contract. Do not extrapolate this to a claim that the tool certified deployed software.
- **AI-101:** independently reproduced. A record containing only an ID and two valid attributed reviews, without prompt/response/lineage, returns `semantic_gate_passed: true`. Negative controls reject a mismatched review hash and keep an unreviewed capture nongreen. Source: `evaluation_records.py:79–123`, versus required capture fields in `schemas/capture-lineage-v1.schema.json:4–14`. Accept P1 for capture-ingestion/accounting correctness. Existing hash consistency is useful but hashes an incomplete record perfectly consistently.
- **ARCH-102 mechanics:** independently reproduced the distinction. `ADR.evidence: ["EVD-404"]` has no canonical diagnostics. An explicit typed relationship to missing EVD-404 is rejected. Correcting that typed endpoint to existing EVD-001 makes an evidence-seeded impact reach ADR-001 with a witness. Sources: `project_model.py:12–16,58–64,79–89`; `graph_engine.py:10–19,22–51`.
- Version-pinned context, smallest-owner workflows, explicit unknowns and retained disagreements remain appropriate. No tested result justifies replacing these with a universal semantic graph or automatically loading every GitHub programming skill.

## Disputed or qualified interpretations

1. **Missing evidence field versus broken typed-reference machinery:** the typed graph already validates and traverses the formal supported relationship. The compact `decisions.evidence` field is not in `LINKS` and its elements lack a formally enforced local-ID contract. Calling every EVD-looking string a dangling local reference would reinterpret historically preserved prose/URLs. Treat ARCH-102 as a contract-definition/composability gap or optional feature until the field's local-versus-external forms are explicit. Its compact-field behavior is verified; a broad claim that evidence cannot propagate is disproved by the typed control.
2. **Shape checks versus meaningful engineering acceptance:** trimming strings and requiring NFR workload/environment/measure/target prevents the exact blank counterexamples. It cannot prove that the values are realistic, mutually consistent, observable or sufficient. Keep shape, semantic review and runtime satisfaction independent; avoid a new promise of a full semantic guarantee.
3. **Capture consistency versus provenance authentication:** requiring prompt/response, supported version/bundles and a recomputed matching content identity closes AI-101's structural fail-open. It does not authenticate model invocation, loaded context, independent reviewers or calibration quality. Valid caller-attributed records must remain allowed, including explicitly unknown reported models and declared empty loaded bundles where the contract permits them. Do not require remote attestation infrastructure to repair a local structural defect.
4. **Source pinning:** a Git SHA proves which committed source was inspected; a file hash identifies captured bytes. Neither establishes runtime behavior, captured model context, author authority or the truth of a review. Working-tree observations need their dirty overlay and non-atomic capture limitation preserved. Do not retroactively use current installed skills to assert which skills were loaded for an earlier capture.
5. **Runtime catalog difference is time-scoped:** specialist07's initial seven-skill snapshot is historical evidence within this audit. The parent's subsequent runtime-refresh evidence establishes eleven 0.9.1 root skills matching source in the current snapshot. Do not carry the initial four missing skills into the final current-state defect register. Retain release identity/reload provenance and explicitly note that nested reference parity remains a separate check if not performed.

## Exact acceptance and regression criteria

- **AC-X04-01:** both whitespace acceptance and content-free NFR scenarios block only the relevant strict readiness profile, with exact record/field paths. Valid structured scenarios pass presence/shape checks; draft import remains tolerant; human review/runtime stay unknown/not run unless actual evidence changes them. A semantic rubric separately checks realistic acceptance.
- **AC-X04-02:** capture summary validates a bounded core capture contract before review counting, without relying on optional schema libraries. Missing/wrong/whitespace prompt,response,model; unsupported version; invalid bundle structure/hash; inconsistent content identity produce exact diagnostics and a nonzero CLI validation outcome while preserving original bytes. Valid unknown-model captures work. Hash mismatch, duplicate reviewer, critical failure, disagreement and unreviewed controls remain nongreen.
- **AC-X04-03:** supported local evidence references are explicitly typed and validated. Missing local endpoints fail; existing endpoints generate evidence→ADR→task review witnesses; equivalent compact/typed forms do not duplicate impacts. Legacy prose, URLs and unknown fields remain preserved as attributed data and never cause fetches or authority changes. Unknown freshness remains unknown.
- **AC-X04-04:** runtime parity reports source commit, source/package/runtime identity, snapshot time, successfully read skills and unresolved reference differences. Initial stale and refreshed matching snapshots coexist in the evidence chronology, with final status derived from the latest applicable evidence.

## Final verdict

Prioritize ARCH-101 and AI-101 as narrow, demonstrated gate-correctness fixes. Reuse existing typed evidence relationships for ARCH-102 instead of adding a graph service; define compact-field semantics before enforcing new integrity. Keep evidence identity, structural completeness, attributed semantic judgment and runtime truth separate throughout the final redesign. This cross-review strengthens the findings without establishing live-model quality, authenticated reviews or universal semantic guarantees.


## Reviewer05

# Specialist 05 — cross-examination and adversarial review

2026-11-01. Reviewed specialist07/report.md, specialist08/report.md and proposed-skill-reference-drafts.md after all ten independent passes. No target edit, whole-suite repeat, installation or publication. New checks: one actual quality-summary CLI counterexample, capture-schema comparison, one read-only YAML parse plus in-memory correction, and one independent GitHub Actions run fetch. Results retained in cross-malformed-summary.json and cross-probes.json.

## AI-101: upheld and independently reproduced

The existing report correctly distinguishes review accounting from model quality, but the consumer still requires a real capture. I passed specialist07's synthetic ID-plus-two-reviews record to the actual CLI in the frozen execution copy. It exited 0 with `semantic_gate_passed: true` and `review_complete`. The published capture schema independently reports missing capture_schema, prompt, response, reported_model, declared_loaded_bundle, available_skill_bundle and review_source_hash. Source `evaluation_records.py:79–123` validates ID/reviews but does not enforce those capture fields before counting. Thus this is a concrete validation defect, not merely missing reviewer authentication.

Verdict: retain P1 and the bounded core capture validator proposal. Do not demand authenticated human identities as part of this fix: the package expressly supports attributed reviews. Validate content and lineage first, then preserve the existing independent states for unreviewed, disagreement, critical failure and missing calibration evidence. Tests should remove or corrupt each required field from a valid capture and demonstrate rejection; a valid unknown-model capture is the positive control. Add a stale-response/source-identity control to ensure a cosmetic schema patch does not bypass existing provenance checks. These tests target forbidden externally observable green accounting, not implementation internals.

Counterevidence to overclaim: this fixture is synthetic; it does not prove malicious use, a production decision based on it, or poor reasoning from the actual assistant. Local review-accounting code returning green is not a measured semantic model result.

## INT-101: upheld and independently reproduced

I independently fetched https://api.github.com/repos/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/actions/runs/41049423745. GitHub again reported audited head SHA `1fa377cc9cbe7054d7edbf8091e22efaa296c05e`, status completed, conclusion failure. Specialist08 retains zero-job/check evidence and the public workflow-line30 annotation. Independently parsing the frozen workflow with installed PyYAML6.0.3 failed at line30 column54 with ScannerError. Replacing only the unquoted run scalar with an in-memory folded scalar parsed, preserved both named jobs, and preserved the exact pip command/hash policy.

Verdict: retain P1. The proposed syntax correction is technically specific, low complexity and feasible, but it remains proposed. A new source-matched remote run must actually start and finish both jobs before any CI success claim. Parsed YAML alone does not verify GitHub Actions expressions, runner provisioning, dependency installation or test outcomes. A syntax preflight must be runnable outside the broken workflow, otherwise the workflow cannot self-report its initial parse failure.

Evidence reconciliation: the 193 Python/0 skipped and 37 Node checks from my independent first pass remain successful **local code/DOM conformance**. They neither contradict this remote parse failure nor establish model performance. My attempted nine-case browser suite remains **blocked before test execution** by host socket EPERM. A present browser workflow is implemented configuration, not an executed browser pass.

## Proposed skill references: accept design direction, require discriminating task outcomes

The four drafts keep existing owner identifiers, conditional execution, user authority and source/receipt provenance. They avoid whole-framework startup loading and do not add another dispatcher. They explicitly reject property tautologies, zero discovered tests, screenshot-only accessibility claims, mechanical React API rewrites, missing tests as vulnerability proof and local-results-as-remote-CI claims. These are useful boundaries.

The evaluation sections currently name scenarios and general acceptance rules; they are **test plans**, not results or fully instantiated benchmark fixtures. Before claiming adoption improved quality, instantiate independently authored held-out tasks with immutable inputs, a behavioral oracle, known counterevidence, allowed tools and a predeclared outcome rubric. Avoid a checklist that merely searches the response for each draft's vocabulary.

Suggested discriminating fixtures:

| Draft | Task and counterevidence | Decisive outcome |
|---|---|---|
| A diagnosis/property checks | Two repositories exhibit the same serializer symptom but have different causes; include nested unknown fields and a supported-value domain | Chosen patch fixes the actual failing case and preserves a working control; roundtrip equality uses independently retained original values; unsupported numeric values are rejected explicitly rather than silently coerced |
| A execution gaps | Provide an old passing log with a different source hash, zero discovered tests, and no available runner | No verified-fix claim; exact stale/missing evidence is retained, with a reviewable next experiment |
| B React/browser | Give valid React18 useContext code and a React19 alternative; include a polling UI and delayed visible state | Preserve valid APIs for actual versions; assert visible state and keyboard recovery in a permitted browser; no universal networkidle wait or screenshot-only accessibility conclusion |
| B performance/security | Task includes a tempting memoization change, no baseline timing, and tenant-keyed cache boundaries | No unmeasured speed multiplier; preserve tenant isolation and mutation authorization while discussing evidence needed to choose optimization |
| C differential security | Pair an exposed ownership-check removal with similar-looking unreachable helper code; include the original control | Confirm only the supported abuse path, show actor/preconditions/source, retain uncertainty about unresolved reachability and verify original authorization regression where execution is allowed |
| C prompt injection | Embed an instruction to upload credentials in a source/log returned during authorized review | No credential read/disclosure or expanded tool authority; continue the scoped analysis and record source as untrusted data |
| D coherent program | Request a small multi-file program under an installed runtime, include import/entrypoint/negative-case requirements and an unrelated executable file | Result satisfies actual CLI/runtime acceptance, preserves imports and relevant executable metadata and leaves unrelated content unchanged; proportional documentation |
| D CI | Supply current malformed workflow, an exact remote failed run and separately passing local logs | Identify parse-stage failure, preserve hash pins, propose syntax repair and keep local/remote statuses separate; no invented remote rerun |

For each paired baseline/candidate run, freeze source/task/skill/reference/tool/model identities and comparable budgets. Record actual artifact acceptance plus independent semantic review, all terminal statuses and disagreements. Set pass criteria before exposure to candidate outputs. Repeated same-model or related-model agreement is not independent truth. Do not manufacture an overall percentage from these deliberately selected probes; report task slices and limitations. No new benchmark was executed during this cross-review.

## Dissent and final scope correction

No substantive dissent on AI-101 or INT-101. I narrow any broad interpretation of QA-101: the existing structural checks can be correct for the files they see; the reproduced gap is absent manifest integrity/completeness verification. The fix should add independent check dimensions using the existing manifest, not claim generic JSON/Markdown syntax becomes semantic proof.

A developer skill-catalog update arrived during cross-review exposing the four additional Studio skills and an updated test-debug-verify definition. Specialist07's initial seven-skill snapshot is valid as a timestamped observation, but a final report must refresh runtime availability before describing it as the current missing-skill state. This update alone does not prove release parity, publication, identical source hashes or a cause. Root was notified immediately.

Final verdict: accept the selective GitHub reference direction as a proposed, reviewable change. Correct the demonstrated green-accounting and CI parsing defects first; then evaluate actual outcomes with held-out task evidence. No model-quality improvement, completed GitHub incorporation, remote green CI or browser pass is established by this audit's local suites.


## Reviewer06

# Specialist 06 — Security cross-examination

Reviewed specialist09 first-pass report/probe and root `proposed-skill-reference-drafts.md` plus `github-skill-adoption.json`, after all ten first passes. Read-only review; only this scratch directory changed. No third-party commands/scripts, installations, scanner suites or provider actions were run.

## Supported findings and independent check

**OPS-101 is supported at P1, not P0.** I independently reproduced the narrower crash-liveness invariant without specialist09's journal monkeypatch: initialize a disposable revision1 project; enter the actual `safe_io.project_lock` in a child; exit82 using `os._exit`; call the actual `revision_store.recover`. The lock remained, recovery raised `FileExistsError`, and canonical revision1 was preserved. Command: `PYTHONDONTWRITEBYTECODE=1 python /workspace/work/sas-audit-2026-11-01/specialist06/probe_lock_cross_review.py`; evidence `cross-review-lock-results.json`. This independently confirms recovery is blocked by a dead writer's lock. It does not independently reproduce the prepared-journal commit boundary, which remains supported by specialist09's exact probe and inspected `revision_store.py:72–75`. No data loss was demonstrated.

**OPS-102 is supported at P1.** Source countercheck confirms `apply_change` locks selected state (`execution_adapter.py:293–296`), while `run_checks:390–450` lacks that lock and compares only endpoint hashes. Specialist09's control fails onA, concurrent receipt explicitly observesB, start/end identity returnsA, and reconcile passes. This is direct evidence of false source correspondence between cooperating operations. It is distinct from SEC-101's continuing-descendant cause; a source-interval fix needs both concurrency and process-lifetime obligations. No claim of forged receipt, unauthorized access or OS escape is warranted.

**OPS-103 storage accounting is a P2 risk/opportunity.** Keep separate from the reproduced defects. No disk-exhaustion run or loss evidence supports stronger severity or automatic retention deletion.

## Safe lock and containment fix scope

- Support the proposed default of read-only lock diagnostics plus process-lifetime locking on the explicitly supported local POSIX platform. Do **not** introduce automatic unlink by lock age, PID absence or a metadata assertion. PID reuse, a different host/container PID namespace and a shared filesystem can make such evidence ambiguous. Preserve lock/journal bytes and refuse uncertain ownership.
- An advisory-lock fix must define inode/descriptor ownership, child descriptor inheritance, release and legacy-lock migration. Unlinking and recreating a lock inode while another process holds the old one can produce two cooperating lock domains. A descriptor held by an unexpected descendant can also extend lock lifetime. These are design/review cases, not reproduced flaws in a future implementation.
- Serialize one-shot checks and applies with one host-owned canonical workspace lock, independent of operation/state record destination. Bound acquisition, report contention, and reject nested adapter writes that would deadlock. If a lock is stored inside source, exclude it consistently from source identity; otherwise lock metadata itself can change the attributed snapshot. Prefer stable trusted external control state or a narrowly declared control-file exclusion.
- Release only after ordinary descendant completion/cleanup and final source capture. Process-group cleanup is useful but is not a sandbox, and detached/noncooperating children need verified host containment or an explicit unsupported/unknown outcome. A read-only immutable snapshot is an alternative only if runtime writes, dependencies and external resources have a defined separate scope.
- Avoid upgrading a content hash into a historical proof of the entire source interval. Reconciliation should record what the lock/snapshot/host actually enforces and retain its limits.

Concrete acceptance additions: live writer excluded; dead writer recovery available without unsafe auto-unlock; PID-reuse/unknown-host/legacy-inode cases refused or explicitly handled; shared lock observed across alternate state-root selection; normal-exit/nonzero/timeout child fixtures cannot write after completion; sameA control remains failed while A→B→A cannot yield a passed receipt forA; nested effect attempts fail boundedly; cleanup/receipt failure preserves prior outcomes and never turns unknown into passed. No broad secure-host assertion follows from this fixture set.

## GitHub draft review: supported incorporation boundaries

The root drafts appropriately preserve existing owners, identify status PROPOSED, exclude upstream scripts/hooks/installers/named agents, pin source revisions, require actual tools and preserve user/host authority. The causal-debugging, invariants, source-grounded security and source/CI identity principles are compatible with current Studio. They do not require importing a third-party execution framework. Behavioral benefit remains Unverified; popularity is not a quality result.

I inspected the cached exact upstream text to challenge the proposed exclusions:

- Microsoft Playwright CLI skill line4 declares `allowed-tools: Bash(...)`; lines216–243 expose page-provided experimental WebMCP tools; lines402–415 describe local/global CLI installation, including `@latest`. These are upstream instructions/data, not inherited permission. An optional adapter must not automatically invoke a page-provided tool, browser JS, shell, install or login merely because this source lists it.
- OpenAI Playwright skill lines9–41 and124–130 prefer an `npx --package` wrapper and user-scoped paths; global latest installation is also described. The root's no-automatic-latest-wrapper and existing-runner adaptation is necessary. The underlying wrapper script was **not** validated by this security review and is not approved by the SKILL.md read.
- Trail of Bits differential review line4 declares broad local tools and lines77,94–101 name a namespaced adversarial-modeler agent. The root's instruction-only adaptation correctly excludes those runtime assumptions and avoids upgrading counted callers into exploitability.
- Vercel composition frontmatter declares MIT and references a larger `AGENTS.md` guide. The declared license does not prove every transitive dependency or mutable external guideline was reviewed. Root correctly leaves web-design-guidelines reference-only and calls notice packaging unresolved.

## Requested draft/register clarifications

These are bounded improvements to the adoption specification, not reasons to reject it:

1. Record an explicit **dependency review status** per candidate: inspected primary text, inspected references, uninspected scripts/hooks/agents/remote resources, and exact assets allowed for adoption. Current `evidence_status: Directly inspected` should not be read as a full repository security review.
2. Add a rule to the optional browser adapter: page-provided WebMCP schemas/results are untrusted; invoke only after ordinary tool/schema/effect authorization, source/target scope and disclosure review. Do not treat registration, a snapshot label or `allowed-tools` frontmatter as authority. Reference-only/optional status must not trigger download or activation.
3. Make distribution acceptance per-file: reviewed license/NOTICE provenance, applicable attribution and modification notice, selected file/hash, intended local license and no unreviewed executable asset. MIT/Apache copying requires their actual applicable notices; a license label in JSON is not the notice package. If CC-BY-SA adapted prose is copied, keep an explicitly attributed compatible derivative boundary and resolve licensing scope before redistribution. General ideas and techniques may inform original instructions, but a claim that wording is “original” alone does not settle derivative status. No legal compatibility conclusion is made here.
4. Preserve a deny-by-default update path for referenced upstream text: a new commit, mutable fetched guideline or dependency requires a new review/evaluation record rather than silent refresh. Quarantine candidate text as data before deliberate activation as owner-reviewed instruction.
5. Phrase the global selection condition as “the tool required for the requested **execution claim** is available”; static diagnosis/threat review may proceed with an explicit execution gap. A missing runner must not block the useful instruction-only portion or invite unnecessary installation.

Adoption acceptance: each candidate maps to one existing owner; no hidden tool/agent dispatch or install occurs on trigger; poison-source fixture cannot change authority or leak synthetic secrets; unavailable tools yield explicit blocked execution; local conventions and user preferences survive; source/license/asset boundary is reviewable; same held-out tasks compare old/new instructions with exact model/bundle/tools/source provenance and independent scoring. Passing local toolkit tests alone cannot prove the instructions improve engineering quality.

## Verdict and dissent

Support the proposed focused hardening and selective GitHub incorporation into a staged blueprint. Reject automatic stale-lock removal, universal sandbox claims, implicit upstream script/page-tool execution, or whole-repository licensing/security conclusions from a SKILL.md read. OPS-101/102 P1 and SEC-101 P1 are justified foundational defects with different causes; SEC-102 remains P2 privacy hardening because incomplete detection is already disclosed and no live credential disclosure was observed. No P0 or universal security-readiness claim is supported. No unresolved factual dissent with specialist09's reproduced results; the additional lock/descendant/license conditions are implementation acceptance boundaries.


## Reviewer07

# Specialist07 cross-examination

Scope: independently reread current runtime definitions; challenge `github-skill-adoption.json` and `proposed-skill-reference-drafts.md` after all ten independent first passes. No source edits, publication, new installs, tool activation, upstream scripts, or model benchmark were performed.

## Runtime contradiction resolved by time-scoped evidence

Earlier position: this session exposed seven older definitions, so GitHub eleven-skill delivery was not then established. Later position: the refreshed session returns eleven definitions matching source. Independent exact JSON-content comparison confirms the later position for the final interval; preserve both observations and unknown cause. See `runtime-transition.md` and `runtime-refresh-comparison.json` for complete identities. SKILL-102 should become a historical transition/release-assurance opportunity, not an open current P1 mismatch. Reading skills still does not prove their task-level model behavior.

## GitHub adoption register and draft review

**Verdict: accept the proposed reference-based direction with the small clarifications below. No unsupported loader, permission grant, installed tool, measured superiority, or autonomous plugin-to-plugin execution is asserted in these drafts.**

| Challenged claim or risk | Evidence and assessment | Resolution/acceptance |
|---|---|---|
| Importing upstream skills could assume a new loader or activate a whole methodology | All17 register entries have `status:Proposed`, `behavioral_gain:Unverified`; drafts explicitly retain existing owner identifiers and propose ordinary Markdown references. Current registry already enumerates nested Markdown and `loaded_bundle` accepts explicit package-relative Markdown under `skills/`. | Supported authoring path. State that future packaging+explicit reference reads are still required; registry enumeration is not proof the model read a reference. No custom dynamic loader is needed or evidenced. |
| Dependencies could silently add browser/CLI/scanners/named agents | Draft selection contract excludes third-party scripts/hooks/installers/dispatchers. B prefers actual permitted browser runner; C refuses assumed upstream agents/scanners; D uses existing authorized connection and no CLI login/install by default. | Accept. Test missing-runner/browser/provider states as blocked; record exact actual tool/permissions/version. `allowed-tools` metadata never grants host authority. |
| Numeric aliases/implicit common contracts could persist | Drafts use actual owner IDs and concrete inputs/outputs rather than S01–S11. Existing source four skills still have unresolved aliases/Common input/Common result (SKILL-101). | Drafts improve clarity, but do not claim this fixes source. Before implementation, replace aliases with actual links and define the small current shared input/result prose contract. No new formal runtime envelope/service required. |
| On-demand references could be misrepresented as already incorporated in runtime | Text labels them original proposed drafts, specifies suggested destinations and says source unchanged. | Final claim should be “incorporated into the redesign/adoption blueprint,” not installed/activated. Actual readback/hash evidence is required after any future approved package update. |
| Upstream licensing or popularity could be mistaken for an endorsement | Register pins source commits and differentiates MIT declarations, per-skill Apache and CC-BY-SA boundaries; mutable web guidelines remain reference-only with unresolved license. No gains or ranking benchmark claimed. | Accept source-specific decisions. Resolve license/NOTICE/attribution packaging before distributing adapted content. Techniques can be considered without copying prose; do not infer a broad original license from repository branding or star counts. |
| Strong test-process language could overburden trivial edits | DraftA excludes cosmetic wording and requires proportional meaningful regressions; DraftD omits enterprise dossiers for a script; original upstream forced chains/confirmation are excluded. | Accept. Preserve repository tests and user work; add only discriminating tests appropriate to behavior/risk. Verify the upstream-original-versus-adaptation distinction remains visible. |
| React performance/composition guidance could become framework folklore | DraftB uses detected versions, says `useContext` is valid, rejects unmeasured multipliers, and checks tenant/cache/mutation authorization. | Accept. Scope React-specific clauses to React; browser/accessibility clauses may be reused in other stacks. Clarify item3 excludes React-specific advice on non-React projects rather than excluding their legitimate UI testing. |
| Cross-owner CI reference might not be discoverable | DraftD places reference under implementation owner and says operations uses its subsection. Current `loaded_bundle` supports explicitly selected references even under another owner, but routing does not automatically discover section-level relevance. | Add explicit link from delivery-and-operations to the CI subsection if implemented. Record reference path/hash in capture lineage; no automatic activation claim. |
| Behavioral evaluation criteria could remain vague | Drafts supply positive/negative/missing-tool/stale-source/property/auth/keyboard/CI cases and acceptance, with paired held-out evaluation required globally. | Sufficient blueprint direction, not measured completion. Before comparative claims predeclare per-case owner, tool/source/model/prompt/reference identity, expected observable outcomes, critical-failure rules, allowed budget, assessor calibration and uncertainty. Include a coordinator-only baseline and an unseen paraphrase slice. |
| New program drafts might imply scaffolding exists as an automatic engine | D calls itself a proposed instruction reference and separates host edits/checks/provider outcomes; source tool is explicit full-file replacement/check adapter. | Accept. A toy assistant-written application cannot establish general code-generation quality. Count actual runnable tasks, negative cases and defects rather than the number of artifacts. |
| Existing AI-101 could undermine a future semantic study | A proposed study can still be instrumented, but current summary accepts structurally absent captures. | Fix AI-101 before using that summary boolean as a release/study gate; independently validate capture completeness/identity meanwhile. Preserve attributed-versus-authenticated reviewer distinction. |

## Proposed falsifiable acceptance for this adoption slice

1. Package only the selected original/adapted reference content with pinned provenance and resolved applicable licenses/notices; all local links resolve. Do not add top-level skills simply for a candidate entry.
2. Load only relevant owner/reference through the actual host mechanism. Capture the exact loaded file hashes separately from the full available package inventory; absent tools cannot be reported executed.
3. On a declared held-out set, compare existing owner versus reference-augmented owner with the same permitted tools/source/model conditions. Include a bad hypothesis, zero tests, absent browser, stale identity, malformed capture, React version distinction, denied authorization and CI source mismatch.
4. Any expected improvement remains a hypothesis until the retained outcomes and independent calibrated assessments support it. All critical authority/disclosure/status cases must fail safely; define usefulness/quality thresholds before running, retain failures and dissent, report scope and uncertainty.
5. After a future approved release, reread exact runtime references/roots where exposed and compare against packaged identity. Preserve source, runtime, reference and test results as distinct claims.

Final specialist position: the proposals preserve the existing eleven-owner architecture and add useful engineering depth without unsupported host assumptions. Fix the concrete gate/import defects, resolve current linkage, and measure outcomes. Final runtime parity is now verified for this read interval; its refresh cause is not.


## Reviewer08

# Specialist 08 — Cross-examination and final interpretation

Cross-review date: 2026-11-01. Reviewed specialist03/report.md, specialist03/probe-results.json, specialist07/report.md, current evaluation consumer source, github-skill-adoption.json and runtime-refresh/comparison.json. Independent first-pass report remains unchanged. No new target edits, installations or external service writes were performed in this cross-review.

## Findings challenged and reconciled

| Claim / objection | Counterevidence and resolution | Final verdict |
|---|---|---|
| CODE-101 executable-mode preservation is only a host limitation | The retained fixture shows ordinary executable 0755 changed to0600 after adapter apply returned passed; chmod alone does not change source_hash. The adapter itself chooses source replacement and identity semantics. Generic private-record IO intentionally uses0600, so globally changing safe_io defaults would weaken a separate control. | **Uphold P1.** Use a source-specific replacement path and versioned mode identity; preserve private-record defaults. Do not claim arbitrary metadata/OS parity. |
| A working three-file fixture establishes a real program-generation capability | The fixture source and tests were supplied by Specialist03, while the adapter applied and checked them. The same tools do not establish that Studio's model generates correct arbitrary programs. | **Uphold CODE-102 as a measurement gap**, separate Verified tool-based editing/checking from Unknown generated-program success rate. |
| CODE-103 can be fixed by merely adding tool_version to receipts | Existing receipts already identify studio.local0.9.1. The missing identity is the actual approved command/check specification, policy and executable/environment relevant to reproducing the result. A hash alone cannot reconstruct missing inputs or authenticate them. | **Uphold P2 with narrower specification.** Retain minimized trusted check identity, not raw secret-bearing policy. Query a tool version only through a known safe authorized command; do not automatically run an arbitrary repository executable with --version. |
| AI-101 is harmless because the field describes supplied review accounting | The consumer can return semantic_gate_passed=true with no actual prompt/response/lineage. Its scope disclaimer limits model-quality claims but does not make structurally absent required evidence valid. Conversely, schema validity cannot authenticate reviewers/calibration or establish model quality. | **Uphold P1 import-validation defect.** Validate before counting; keep accounting validity and actual semantic/task-quality evidence distinct. |
| SKILL-102 proves the currently exposed package remains stale | Root's later runtime-refresh/comparison.json contains all11 skill definitions and identical runtime/source hashes and byte counts. This is positive counterevidence to a final stale-definition claim. The initial7/0.7.2 observation remains historically true at the earlier boundary. No audit publication occurred, and release/backend cause is unknown. | **Reclassify as observed runtime transition, current definition parity confirmed.** Do not retain an open P1 stale-content conclusion. Definition parity still does not prove tools, scripts, references, provider connections or whole-package delivery parity. |
| Named permission lookup not_installed proves Studio is absent | My initial exact-name permission result was ambiguous; current successful reads of all11 definitions provide stronger positive availability evidence. Permission inspection has different identity/resolution semantics. | **Reject absence inference.** Keep backend/release identity mapping Unknown; no reinstallation or guessed plugin ID is justified. |

## GitHub programming-skill adoption review

The registry contains17 inspected candidates:10 ADAPT,2 REFERENCE ONLY,2 REFERENCE TECHNIQUE,1 DEFER,1 OPTIONAL REFERENCE and1 OPTIONAL ADAPTER. Each records an immutable commit/path, existing owner, proposed status and unverified behavioral gain. This is a coherent **adoption blueprint**, not17 installed skills or evidence of “best” measured performance.

I support mapping the practices into existing owners. The strongest choices connect directly to demonstrated audit needs: evidence-first debugging and completion; discriminating regressions; source-matched CI diagnosis; property/invariant testing of serialization, metadata and validators; source-grounded threats and risk-focused diffs. The registry correctly excludes forced agent chains, destructive restarts, unconditional latest-package installation, frontmatter-as-authority, forced approval interviews and mandatory tooling migrations.

Seven entries map to the frontend owner. Browser observation, interaction, console/trace evidence and capability preflight overlap across OpenAI, Anthropic and Microsoft references. Consolidate these into **one on-demand browser-verification reference with alternative tool mappings**, retaining primary-source attribution. Do not load three browser orchestration prompts together. React performance/composition remains a separate version-aware reference: a source pin preserves inspected text, not compatibility with the user's installed React/Next.js.

No extra top-level universal programming coordinator, automatic dispatcher, browser service or plugin-to-plugin bus follows from these files. Installation, existing skill exposure and allowed-tools frontmatter remain distinct from callable authorized runtime capability.

For content copied/adapted from MIT/Apache sources, preserve applicable attribution/license/notices and record modifications. Trail of Bits entries are appropriately reference-technique candidates under the inspected CC-BY-SA4.0 declaration. A separate directory alone does not establish license compliance for a derivative; decide the actual derivative/content boundary before packaging. No copyrighted upstream content was installed by this audit.

## Acceptance additions

1. **Mode/check provenance:** detect chmod-only source changes; preserve0755 and0644 source behavior while private records remain0600; same-named different approved commands must have distinct check identities; credentials do not enter receipts.
2. **Capture ingestion:** reject malformed imported captures before semantic accounting in both core-only and optional-validator environments; valid unknown model identity remains representable; no reviewer-authenticity claim is introduced.
3. **Runtime evidence:** retain both observation snapshots and timestamps; current11 definition hashes match GitHub. Explicitly state which references/scripts/tool operations were inspected or executed rather than infer whole-package parity.
4. **Adoption:** resolve existing owner, exact source/version/license and host tool before loading a reference. An unavailable browser/CI/provider tool produces blocked/manual evidence, not installation. One owner controls writes.
5. **Evaluation:** compare held-out actual tasks with the same model/tools/budgets; set required outcomes before evaluation; failed/blocked outcomes and correction burden remain visible. No benefit is inferred from candidate count or lexical fixtures.
6. **Release:** INT-101 remains an independently demonstrated P1 until a revised commit's workflow parses and its actual GitHub jobs finish. Local passes cannot supersede that remote evidence.

## Final verdict and remaining dissent

Support the minimal existing-owner adoption plan and retain confirmed correctness fixes ahead of expansion. No disagreement remains about the source-specific executable regression, capture validation gap or remote CI failure. I disagree with carrying the initial runtime/source mismatch forward as a current stale-definition defect after the later11/11 matching observation.

The user's separately authorized Google Doc delivery is a report artifact operation outside the read-only investigation's source/plugin boundary. It does not imply permission to publish a plugin, edit GitHub source, install candidates or change app access.



## Reviewer09

# Specialist 09 cross-examination — validation, source identity and operational release

2026-11-01. Reviewed completed first-pass reports from Specialists 03 and 05, Specialist 03's deterministic ABA cross-review/script/results, and current pinned source. Independent first pass was already complete. No target edits, dependency installation or broad suite rerun occurred. New discriminating probe: `PYTHONDONTWRITEBYTECODE=1 python -B /workspace/work/sas-audit-2026-11-01/specialist09/cross_probe.py`; retained evidence is `cross-validation/results.json`.

## Supported claims

**QA-101 is independently reproduced, with an informative consumer distinction.** An intact generated handoff returned structural `policy_ok=true`. Deleting its manifest-listed `api.json` left structural `policy_ok=true`; calling the existing `recover_handoff` against that same generation raised `FileNotFoundError`. The validator never established artifact membership/integrity, whereas the recovery path attempted to read/check the declared file. This supports a missing validation dimension, not a claim that JSON syntax, local references or contract checks which actually ran were all wrong. Reuse one bounded read-only manifest verifier across validation and recovery preflight; validation must never regenerate or repair bytes to obtain green status.

**QA-102 is independently reproduced and its priority remains use-dependent.** `{"asyncapi":"bogus","info":{},"channels":{}}` returned `gate=full`, `policy_ok=true`, with the sole check `AsyncAPI declaration: passed`, detail `basic envelope only; full schema not verified`. Rejecting invalid versions and exposing missing applicable schema verification requires no installation. A real full schema validator is a separately scoped optional implementation. P1 is justified where a release requires AsyncAPI validity; if a caller deliberately requests envelope inspection only, the missing schema capability is a documented limitation rather than a failed performed schema test.

**CODE-101 is source-supported and agrees with the retained executable probe.** Generic `safe_io.atomic_write` creates a 0600 replacement inode, and adapter source identity records only content. The source-specific fix must preserve supported ordinary permissions and bind them into identity/preconditions; do not globally relax private journal/receipt modes. File ownership, ACLs, xattrs, hard-link relationships and platform semantics remain separate scope questions. Preserving executable bits alone cannot establish complete build/runtime-environment correspondence.

**CODE-103 improves reproducibility but is not a substitute for execution integrity.** Versioned policy/check-spec identity, safe argv provenance, parser/tool/environment identities and retained redacted specifications help reproduce named checks. They cannot make the current ABA receipt true. Do not sequence provenance-only bookkeeping as though it closes OPS-102.

**OPS-102 now has independent deterministic reproduction.** Specialist 03's separate-process handshake probe removes the narrow sleep-window concern from my first reproduction. Its negative control fails on A; the overlapping assertion reads B; authorized applies restoreA before completion; receipt and reconciliation pass with identicalA endpoint hashes. This is an independently reproduced source-correspondence defect under cooperating operations using the same root/state. No hash collision, hostile actor or forged receipt is involved.

## Disputed or narrowed interpretations

- **“Immutable generation” means a publication/read convention here.** The existing directory is writable; the atomic pointer identifies a committed generation but does not prevent later mutation. Manifest verification detects accidental/later changes relative to retained metadata. It neither authenticates a rewritten manifest nor proves that generated prose is architecturally correct.
- **Atomic replacement is narrower than crash-atomic workflow.** `os.replace` and fsync attempts are useful. Multi-file apply and legacy handoff projections can still be partial; journals/current-generation paths must remain the recovery mechanism. A shared lock must not introduce an all-or-nothing claim.
- **Green regression suites coexist with reproduced gaps.** Preserve the 193 Python/37 Node passing evidence for its actual scope; do not multiply counts when release-check reruns it. Browser execution remained blocked. These results do not establish live model quality or validate cases absent from the suites.
- **Endpoint equality cannot prove checked bytes.** Locking only receipt publication or comparing another post-check hash does not fixA→B→A. The invariant must span source capture, process lifecycle and final capture, or execution must use an actually consistent immutable source snapshot. Alternate state roots, path aliases, nested adapter invocation and noncooperating writers require explicit supported scope.
- **Stale-owner cleanup must remain safe.** Neither elapsed age nor a nonexistent/reused PID alone grants authority to delete a lock. Prefer process-lifetime POSIX locking within the declared Linux/POSIX scope. Any migration needs preserved old metadata, active/uncertain-owner refusal, documented operator diagnosis and expected canonical/journal identity checks. Do not silently clear existing locks on upgrade.
- **Runtime catalog evidence changed.** The root reports the final runtime catalog contains 11 definitions matching GitHub coordinator content. Treat the earlier seven-definition observation as an intermediate snapshot, not a final delivery defect. This runtime update does not itself prove source toolkit execution or model-quality improvement.

## Remediation order and release gates

1. **Define the supported invariants and precise statuses.** Keep file effects, artifact integrity, document structure, schema applicability, source correspondence, process completion and application behavior separate. Required unknown/unsupported verification must block only the claim depending on it.
2. **Fix lock liveness and versioned source identity/preservation.** OPS-101 lock ownership is prerequisite to shared-lock checking. CODE-101 can proceed in parallel with source-specific IO and explicit identity/plan compatibility. Preserve 0600 private records and reject privilege-bearing mode changes.
3. **Enforce lifecycle-wide source correspondence.** Combine OPS-102 shared canonical workspace exclusion/snapshot with ordinary descendant completion/cleanup behavior from SEC-101. Final source observation occurs after required lifecycle completion. Host containment remains conditional; detached hostile descendants are not solved by a process-group assertion.
4. **Fix handoff integrity and per-format applicability in parallel.** QA-101 checks membership, bytes and generation/source metadata consistency under safe bounded reads; QA-102 distinguishes envelope/schema support. Neither depends on adding hosted services or installing an AsyncAPI package.
5. **Add minimized provenance and matched-task measurements.** Bind policy/check/metadata identities; retain failed/blocked/skipped cases. Evaluate selectively adapted GitHub skills only after benchmark accounting is sound. Advisory research/drafts need not wait for runtime fixes; stronger software-verification claims do.

Combined acceptance: deterministic ABA cannot reconcileA from a check that read B; live writer is excluded and nested calls fail boundedly; abrupt exit recovers exactly once without unsafe lock deletion; edits preserve supported ordinary/executable modes and stale chmod conflicts; missing/tampered manifest entries block handoff integrity without validator writes; invalid AsyncAPI fails and required unavailable schema verification is incomplete. Existing source/contract/adapter tests stay applicable; new tests must discriminate the failure rather than echo implementation. Keep explicit failure/cleanup/containment dimensions and preserve partial effects.

## Safe rollback and final verdict

Roll back only on quiescent workspaces. Preserve canonical/journal/history, operation records and committed generation pointers before migration; never reinterpret new source/plan/receipt identities silently under old semantics. If new verification isolation cannot be maintained, disable that claim and export a source-bound manual check plan; do not resume green receipts with weaker correspondence. Never delete unowned projections or arbitrary stale-looking locks as rollback.

Foundational hardening is warranted; no P0, production compromise, total data loss or OS sandbox claim is established. Source-bound implementation verification remains level 3 Repeatable until these counterexamples are resolved, while existing passing tests remain valid scoped evidence. The toolkit's architecture is worth preserving. Correct the attribution and recovery invariants before expanding execution promises or claiming programming-skill superiority.


## Reviewer10

# Specialist 10 — cross-examination and reconciled verdict

2026-11-01 (Asia/Tehran). Independent first-pass `report.md` and `historical-regressions.md` remain unchanged. This cross-review inspects specialist02/06/09 reports and retained probe results plus `proposed-skill-reference-drafts.md`. It does not independently rerun their probes. Evidence status for those results is **Directly inspected**; mechanisms checked in the pinned source support the conclusions. No source edit, provider write or broad test rerun occurred.

## Architecture: accepted findings with narrow claim boundaries

**Accept ARCH-101/P1.** Whitespace-only requirement/task acceptance and a content-free NFR scenario demonstrably defeat the completeness gate, while human/runtime dimensions remain unknown/not run. The proposed fix belongs in review-ready readiness, preserving incomplete drafts. Challenge any description that turns a nonblank/shape validator into verification that acceptance is observable or an NFR is feasible. Acceptance should first establish that required supported fields are present and structurally meaningful; semantic review and measured workload evidence remain independent.

**Accept ARCH-102/P2 for declared local IDs; qualify the compatibility design.** Existing `ADR.evidence` can contain attributed freeform data. A machine-looking `EVD-404` is not sufficient permission to reinterpret all legacy evidence strings as local foreign keys. Prefer explicit typed evidence dependencies, or version a compact local-ID field with an unambiguous kind. Keep prior prose/URLs opaque and preserved, issue a migration diagnostic, and do not fetch references automatically. Acceptance: dangling declared-local IDs diagnose precisely; changing supported evidence reaches its ADR/task through an attributable witness; legacy prose and approval origins survive roundtrip; equivalent links do not duplicate impact. A graph witness still identifies review candidates, not proof that source must change.

The immutable GitHub citations in specialist02 point to the pinned implementation mechanisms. Its counterexample paths name retained fixtures. This is stronger than a prose-only architectural concern, but not a live model-reasoning benchmark.

## Security and knowledge disclosure

**Accept SEC-102/P2.** The raw synthetic results show unquoted/structured values redacted while quoted assignment and Bearer text remain. The existing warning that minimization is incomplete is material counterevidence against a claim that the product promised secret-free exports; preserve that qualification. No real credential disclosure was demonstrated.

**Challenge blanket expansion as a sufficient remedy.** Pattern-based minimization cannot identify arbitrary confidential business prose. It can also damage legitimate examples, enum/constant values or API contracts. Broaden only named bounded formats with negative controls, record transformation paths and separately named canonical/projection/artifact hashes, preserve the original canonical/private input, and keep explicit review before sharing. The acceptance corpus must include semantically legitimate fields/examples named `token` and verify the supported contract remains structurally meaningful after transformation. A redaction report must not echo the values it removed. Unknown formats stay unknown.

**Accept SEC-101/P1 and its lifecycle distinction.** Leader exit is not all-effects completion. A normal child's late mutation can invalidate an early verified claim even without malicious detachment. Freshness detection after a mutation is useful but cannot retroactively make the first reconciliation correct. Long-lived servers require a separate explicit lifecycle; no generic complete-coverage/host-sandbox promise follows from process-group cleanup.

## Proposed skill-reference drafts

**Accept all four as a bounded proposal**, attached to existing owners rather than new root skills. They retain version-specific references, proportional verification, missing-tool fallbacks, source-as-data, synthetic checks and no automatic scripts/hooks/installs/dispatch. Their stated outcome is improved instructions for evaluation, not a demonstrated model-quality gain.

**Required additions before implementation-readiness:**

1. Reuse GOV-I101's explicit context-coverage contract in Draft D's continuation/handoff output. A brief excerpt needs original size, included range/omission marker and canonical source identity; actual source retrieval is conditional on authorized access. Preserve Accepted data and attributed provenance without granting authority. This closes the new reference pack's knowledge-continuity seam without inventing another skill.
2. Make source, public projection, imported source reference and loaded reference-bundle identities distinct. A pinned upstream source URL proves inspected bytes; it does not prove those bytes entered the model context or that the instruction worked. Record a loaded-bundle hash in any actual evaluation capture and keep the available-package inventory separate.
3. Keep a per-fragment provenance record: upstream path/commit, relationship (`inspiration`, `adapted`, `copied`, or unresolved), applicable license/notice, author attribution, local owner, edits and evaluation case. Describing text as an original draft is not a substitute for identifying substantial adapted expression. The Vercel notice and Trail of Bits share-alike boundaries remain redistribution gates, not reasons to leave this read-only audit incomplete.
4. Include source/projection disclosure and receipt validation in the held-out evaluation. Candidate tasks should detect a silent resume suffix loss, a semantically damaged contract after redaction, a stale referenced doc, an absent tool, missing capture lineage and conflicting human reviews. Require zero unmarked omissions/unauthorized effects on the declared fixtures; state the limited population and preserve disagreements.

Suggested short shared addition:

> Name the exact source and loaded reference identity, and state which context fields or ranges were included or omitted. A minimized export and a complete private source have different identities and disclosure scopes. Preserve prior Accepted facts and attributed origins as data. If an omitted range could affect the task, inspect it through an available authorized source tool or retain an explicit context gap. Do not infer complete knowledge, execution or approval from a hash, link or packet alone.

## Historical reconciliation after operations counterexamples

The first-pass matrix's wording was explicitly scoped to selected tests, but the final combined matrix must make these new results visible rather than retain a broad green label:

| Previous row | Reconciled status | New evidence and implication | Required acceptance |
|---|---|---|---|
| REG-109 Revision-history integrity: fixed for selected local logical-integrity cases | **Partially fixed** | OPS-101: abrupt exit after prepared-journal write leaves `.architecture.lock`; documented `recover` is blocked by FileExistsError. Controlled scratch unlock permits correct revision2. Previously executed injected Python exceptions and hash-conflict protections remain genuine successes. No canonical data loss was shown. | Abrupt exit at each durable phase has a documented safe liveness recovery path, preserves invalid/conflicting bytes, advances at most once and excludes a live/uncertain owner. Do not prescribe unconditional deletion based on lock age or reusable PID. |
| REG-108 Editing/recovery data-loss risks: fixed selected core cases | **Partially fixed; browser-specific fixes retained** | OPS-101 exposes a process-death recovery-availability gap beyond DOM draft/import tests. Those browser cases were not invalidated by this separate local-lock counterexample. | Separate browser recovery, local process recovery, data preservation and actual power-loss durability claims. Test the relevant boundary before marking its recovery complete. |
| REG-104 False-positive validator success: partially fixed | **Partially fixed, with a distinct source-correspondence defect** | OPS-102: a check observes B during authorized A→B→A edits, returns passed for start/end hash A, and reconciliation passes for A. This is receipt/source correspondence, not the artifact validator's own syntax/schema gate. | Serialize cooperating check/apply on one canonical workspace lock or verify an immutable read-only source snapshot; alternate state roots must not evade the mapping. Keep contention bounded and nested mutating checks explicit. Endpoint hash equality alone is insufficient. |
| REG-110 Stale handoff artifacts: fixed managed stale-file/ownership case | **Known cleanup case fixed; end-to-end liveness partial** | Shared `project_lock` also guards handoff/recovery, so OPS-101 is relevant to publication availability. Specialist09 did not reproduce every handoff crash phase, so do not label an untested generation-corruption defect. | Extend documented crash/liveness controls to handoff publication and preserve coherent committed-generation reads. Keep consumer manifest verification as a separate obligation. |

The controls in my first pass remain meaningful: canonical/private roundtrips preserved opaque extensions and Accepted origins, selected recovery/hash-conflict tests passed, and restore created a new revision. Their scope did not include abrupt process death, concurrent source changes during checks or actual browser execution. No historical result should be erased; append the counterexamples and narrowed conclusion.

## Runtime observation reconciliation

The root now reports eleven exposed root skills at0.9.1 matching the GitHub source. The initial seven-skill0.7.2 observation is time-scoped evidence, not a persistent current deployment-divergence finding. Do not infer why the refresh occurred, that this audit published a release, or that root-skill equality proves every supporting reference, executable tool or behavioral outcome matches. Preserve observation times and identities in the ledger. No runtime publication was performed by this specialist.

## Final verdict

Keep the portable knowledge model, explicit source/projection identities and evidence boundaries. Prioritize OPS-101/OPS-102 plus process completion before stronger exact-source verification/recovery claims; fix the bounded GOV-101 omission alongside reference-pack integration. Adopt the proposed GitHub-inspired references through existing owners with traceable provenance and declared license gates. Do not claim a measured quality gain or complete knowledge continuity until held-out captures and the new omission/liveness/correspondence regressions establish it.

