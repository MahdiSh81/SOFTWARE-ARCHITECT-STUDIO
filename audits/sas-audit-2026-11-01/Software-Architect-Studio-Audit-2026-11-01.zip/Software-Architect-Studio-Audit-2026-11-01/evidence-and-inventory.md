# Verification and source evidence

## Source identity

Source of record: https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/tree/1fa377cc9cbe7054d7edbf8091e22efaa296c05e
Remote master SHA equals local HEAD. Complete tree:455 tracked blobs, zero mismatches. Source inventory is a complete path inventory; content inspection is scoped in the specialist reports.

## Current test ledger

{
  "source_commit": "1fa377cc9cbe7054d7edbf8091e22efaa296c05e",
  "scope": "copy of target excluding .git/audits/node_modules/generated results",
  "environment": {
    "host_budgets": {
      "agent_count": "advisory; host must mediate",
      "external_tool_authority": "host enforcement required",
      "local_file_bytes": "enforced",
      "subprocess_deadline": "enforced",
      "tokens": "unsupported"
    },
    "io": {
      "bounded_reads": true,
      "non_posix": "preflight only; hostile path-race protection not claimed",
      "posix_descriptor_no_follow": true,
      "power_loss_durability": "fsync attempted; filesystem/platform durability not certified",
      "regular_file_reads": true,
      "writer_concurrency": "cooperating local writers under exclusive lock"
    },
    "mmdc": null,
    "network": "no automatic installs/fetching; host connector capabilities unprobed",
    "packages": {
      "PyYAML": "6.0.3",
      "jsonschema": "4.23.0",
      "openapi-spec-validator": "0.7.2"
    },
    "platform": "linux",
    "python": "3.12.14",
    "toolkit_version": "0.9.1"
  },
  "node_version": "v24.19.0",
  "commands": [
    {
      "id": "QA-E01",
      "command": "PYTHONDONTWRITEBYTECODE=1 /workspace/sas-env/bin/python -m unittest discover -s tests -v",
      "exit_code": 0,
      "status": "passed",
      "tests": 193,
      "skipped": 0,
      "log": "unittest.log"
    },
    {
      "id": "QA-E02",
      "command": "node tests/test_workbench.cjs",
      "exit_code": 0,
      "status": "passed",
      "checks": 37,
      "scope": "actual project-core and inline UI code in Node; minimal DOM model, not browser rendering",
      "log": "workbench.log"
    },
    {
      "id": "QA-E03",
      "command": "PYTHONDONTWRITEBYTECODE=1 /workspace/sas-env/bin/python tools/check_source_manifest.py --check",
      "exit_code": 0,
      "status": "passed",
      "files": 116
    },
    {
      "id": "QA-E04",
      "command": "PYTHONDONTWRITEBYTECODE=1 /workspace/sas-env/bin/python tools/check_release.py --output [scratch]/release-check.json --require-node",
      "exit_code": 0,
      "status": "passed",
      "scope": "second execution of same 193 Python tests and 37 Node checks, not additional unique cases",
      "log": "release-check.json"
    },
    {
      "id": "QA-E05",
      "command": "NODE_PATH=/workspace/sas-browser/node_modules PYTHONDONTWRITEBYTECODE=1 node /workspace/sas-browser/node_modules/@playwright/test/cli.js test --config=[scratch]/playwright.config.cjs",
      "exit_code": 1,
      "status": "blocked",
      "reason": "test web server could not create loopback socket: PermissionError EPERM; no browser case executed",
      "defined_cases": 9,
      "log": "browser.log"
    },
    {
      "id": "QA-E06",
      "command": "PYTHONDONTWRITEBYTECODE=1 /workspace/sas-env/bin/python [scratch]/probe.py",
      "exit_code": 0,
      "status": "executed",
      "results": "probes.json",
      "cases": "baseline/missing API/tampered Markdown/5 malformed project shapes/AsyncAPI full gate"
    }
  ],
  "target_baseline_changed_files": [],
  "live_model_evaluation": "not performed; no external model API invoked",
  "mermaid_render": "blocked: mmdc unavailable; no installation authorized"
}

## Runtime transition

# Runtime transition — final current observation

**Current conclusion: all eleven runtime skill definitions match the selected GitHub source exactly. SKILL-102 is a time-scoped earlier observation, not an open final parity defect.**

The first independent pass observed seven exposed cloud skills and read a coordinator identifying0.7.2; its specialist definitions were also shorter than GitHub0.9.1. Those records remain under `runtime/` and in the original first-pass probe. They establish what was returned then, without identifying installation/publication cause.

After the session catalog refreshed, this specialist independently reread all eleven `c6/<skill-id>` resources. Reads completed on1November2026 at **18:30:01–18:30:03 Asia/Tehran** (15:00:01–15:00:03 UTC). Every read had `next_cursor:null`. Raw returned `contents` strings were stored as JSON values in `runtime-refresh-json/*.json`; comparison decoded those JSON values and encoded UTF-8, rather than comparing a Markdown file written with an incidental serialization newline.

| Skill | Returned UTF-8 bytes | Exact equality with GitHub execution mirror |
|---|---:|---|
| software-architecture |16439|Yes|
| requirements-specification |2470|Yes|
| repository-intelligence |2557|Yes|
| implementation-planning-and-change |2498|Yes|
| test-debug-verify |2151|Yes|
| security-review |2120|Yes|
| api-data-contracts |2220|Yes|
| frontend-interaction-and-accessibility |5760|Yes|
| service-and-data-implementation |5887|Yes|
| delivery-and-operations |5842|Yes|
| ai-system-evaluation-and-safety |6153|Yes|

Source commit: `1fa377cc9cbe7054d7edbf8091e22efaa296c05e`. Exact source/runtime SHA-256 pairs, resource URIs, read timestamps and byte counts are in `runtime-refresh-comparison.json`; `all_exactly_equal:true`, expected11/observed11. Coordinator returned content identifies0.9.1. The parent separately verified the execution mirror against the GitHub source of record; this specialist verified exact runtime-to-mirror content equality.

Capability classification: **Verified tool-based** for reading the final eleven definitions and comparing bytes. Evidence status: **Successfully executed**. Confidence high within this session/read interval. This does not classify every model workflow as behaviorally verified, prove activation/routing quality, or establish source/package parity for other accounts/sessions.

No audit participant publication/update is evidenced by these reads, and this specialist did not publish, install, connect or edit source. The platform/session refresh cause, release operation and broader distribution remain **Unknown**. Do not invent a plugin deployment, reinstall, release failure, or remediation action from a catalog transition.

Acceptance for current parity is satisfied by eleven complete successful reads and exact hashes. Future release assurance should preserve source/package/runtime mapping and repeat readback at the intended surface. The current report should retain the earlier mismatch in the evidence chronology but remove it from the open P1 defect list. AI-101 malformed-capture accounting and SKILL-101 unresolved live aliases are unaffected by this transition; their source matches the reread runtime instructions, but the code defect itself belongs to repository tools.


{
  "source_commit": "1fa377cc9cbe7054d7edbf8091e22efaa296c05e",
  "expected_skills": 11,
  "observed_skills": 11,
  "all_exactly_equal": true,
  "rows": [
    {
      "id": "ai-system-evaluation-and-safety",
      "observed_at_utc": "2026-11-01 15:00:03 UTC",
      "resource": "skill://[private-package]/ai-system-evaluation-and-safety/SKILL.md",
      "runtime_bytes": 6153,
      "source_bytes": 6153,
      "runtime_sha256": "dc2bd50a5301585f5b6cfc8ff4cbe419252cf7063a75648aedb3c82be015fbfa",
      "source_sha256": "dc2bd50a5301585f5b6cfc8ff4cbe419252cf7063a75648aedb3c82be015fbfa",
      "exact_bytes_match": true,
      "next_cursor": null
    },
    {
      "id": "api-data-contracts",
      "observed_at_utc": "2026-11-01 15:00:03 UTC",
      "resource": "skill://[private-package]/api-data-contracts/SKILL.md",
      "runtime_bytes": 2220,
      "source_bytes": 2220,
      "runtime_sha256": "ca5eaf7dad68ecdf53babf1e91e1c5aff45b9ea80c2adc43678c28219f1465b2",
      "source_sha256": "ca5eaf7dad68ecdf53babf1e91e1c5aff45b9ea80c2adc43678c28219f1465b2",
      "exact_bytes_match": true,
      "next_cursor": null
    },
    {
      "id": "delivery-and-operations",
      "observed_at_utc": "2026-11-01 15:00:03 UTC",
      "resource": "skill://[private-package]/delivery-and-operations/SKILL.md",
      "runtime_bytes": 5842,
      "source_bytes": 5842,
      "runtime_sha256": "94abc8cbbab377768704849aa1f7ef3d94fbfa09e8039c218c2b2b4f59787687",
      "source_sha256": "94abc8cbbab377768704849aa1f7ef3d94fbfa09e8039c218c2b2b4f59787687",
      "exact_bytes_match": true,
      "next_cursor": null
    },
    {
      "id": "frontend-interaction-and-accessibility",
      "observed_at_utc": "2026-11-01 15:00:03 UTC",
      "resource": "skill://[private-package]/frontend-interaction-and-accessibility/SKILL.md",
      "runtime_bytes": 5760,
      "source_bytes": 5760,
      "runtime_sha256": "4e8a9e1acbf886ec1179a08e2c4b6df58d2f35fbfa7c977dbbffcf70f42d7504",
      "source_sha256": "4e8a9e1acbf886ec1179a08e2c4b6df58d2f35fbfa7c977dbbffcf70f42d7504",
      "exact_bytes_match": true,
      "next_cursor": null
    },
    {
      "id": "implementation-planning-and-change",
      "observed_at_utc": "2026-11-01 15:00:03 UTC",
      "resource": "skill://[private-package]/implementation-planning-and-change/SKILL.md",
      "runtime_bytes": 2498,
      "source_bytes": 2498,
      "runtime_sha256": "63bae26b5e95daea3767c0c8e66acfdf5c920666fd985f746417e3356304f179",
      "source_sha256": "63bae26b5e95daea3767c0c8e66acfdf5c920666fd985f746417e3356304f179",
      "exact_bytes_match": true,
      "next_cursor": null
    },
    {
      "id": "repository-intelligence",
      "observed_at_utc": "2026-11-01 15:00:03 UTC",
      "resource": "skill://[private-package]/repository-intelligence/SKILL.md",
      "runtime_bytes": 2557,
      "source_bytes": 2557,
      "runtime_sha256": "008969160405a9d7f4c15e832418d77bdf9802d6f60435fedf8bf971aca433f9",
      "source_sha256": "008969160405a9d7f4c15e832418d77bdf9802d6f60435fedf8bf971aca433f9",
      "exact_bytes_match": true,
      "next_cursor": null
    },
    {
      "id": "requirements-specification",
      "observed_at_utc": "2026-11-01 15:00:01 UTC",
      "resource": "skill://[private-package]/requirements-specification/SKILL.md",
      "runtime_bytes": 2470,
      "source_bytes": 2470,
      "runtime_sha256": "80e92bd573bdd55e9c3fb1b3206a14341adf032eff6f0069daabaaabb596db2c",
      "source_sha256": "80e92bd573bdd55e9c3fb1b3206a14341adf032eff6f0069daabaaabb596db2c",
      "exact_bytes_match": true,
      "next_cursor": null
    },
    {
      "id": "security-review",
      "observed_at_utc": "2026-11-01 15:00:03 UTC",
      "resource": "skill://[private-package]/security-review/SKILL.md",
      "runtime_bytes": 2120,
      "source_bytes": 2120,
      "runtime_sha256": "18ae44e453d3c4f0c91ebd3bf0065d92f525ce38965ed8935ff7387831c4d575",
      "source_sha256": "18ae44e453d3c4f0c91ebd3bf0065d92f525ce38965ed8935ff7387831c4d575",
      "exact_bytes_match": true,
      "next_cursor": null
    },
    {
      "id": "service-and-data-implementation",
      "observed_at_utc": "2026-11-01 15:00:03 UTC",
      "resource": "skill://[private-package]/service-and-data-implementation/SKILL.md",
      "runtime_bytes": 5887,
      "source_bytes": 5887,
      "runtime_sha256": "691c48a98ce53d9a17f873632d6ebba969d51b782bc2b3f22f93947a56584043",
      "source_sha256": "691c48a98ce53d9a17f873632d6ebba969d51b782bc2b3f22f93947a56584043",
      "exact_bytes_match": true,
      "next_cursor": null
    },
    {
      "id": "software-architecture",
      "observed_at_utc": "2026-11-01 15:00:03 UTC",
      "resource": "skill://[private-package]/software-architecture/SKILL.md",
      "runtime_bytes": 16439,
      "source_bytes": 16439,
      "runtime_sha256": "7e008fb3da211f92e633d6f5f625f9ee54f88f583ac138617e544bc1126ae8d3",
      "source_sha256": "7e008fb3da211f92e633d6f5f625f9ee54f88f583ac138617e544bc1126ae8d3",
      "exact_bytes_match": true,
      "next_cursor": null
    },
    {
      "id": "test-debug-verify",
      "observed_at_utc": "2026-11-01 15:00:03 UTC",
      "resource": "skill://[private-package]/test-debug-verify/SKILL.md",
      "runtime_bytes": 2151,
      "source_bytes": 2151,
      "runtime_sha256": "20df7942a4a29388935fed41d9ebdfe59d2678ef45aa05e0a371a8ee5cdbacaf",
      "source_sha256": "20df7942a4a29388935fed41d9ebdfe59d2678ef45aa05e0a371a8ee5cdbacaf",
      "exact_bytes_match": true,
      "next_cursor": null
    }
  ]
}

## Major reproductions and raw evidence locations

### Specialist01 evidence
The associated report and cross-review provide exact commands, source locations, observations and limits. Scratch artifacts: routing-probes.json.

### Specialist02 evidence
The associated report and cross-review provide exact commands, source locations, observations and limits. Scratch artifacts: contract-resolution.log, contract-semantics-optional.log, contract-semantics.log, cross-probe-results.json, cross-probe.py, integrity.log, probe-results.json, probe.py.

### Specialist03 evidence
The associated report and cross-review provide exact commands, source locations, observations and limits. Scratch artifacts: adapter-tests.log, cross_aba_probe.py, probe-results.json, probe.py.

### Specialist04 evidence
The associated report and cross-review provide exact commands, source locations, observations and limits. Scratch artifacts: controls.json, controls.py, cross-probe-results.json, cross-probe.py, probe.json, probe.py, repository-tests.log, target-scan.json.

### Specialist05 evidence
The associated report and cross-review provide exact commands, source locations, observations and limits. Scratch artifacts: asyncapi.json, baseline.json, browser.log, cross-malformed-summary.json, cross-probes.json, playwright.config.cjs, probe.py, probes.json, release-check.json, release-check.log, unittest.log, verification-ledger.json, workbench.log.

### Specialist06 evidence
The associated report and cross-review provide exact commands, source locations, observations and limits. Scratch artifacts: completion-results.json, cross-review-lock-results.json, probe-results.json, probe_check_completion.py, probe_lock_cross_review.py, probe_security.py.

### Specialist07 evidence
The associated report and cross-review provide exact commands, source locations, observations and limits. Scratch artifacts: malformed-captures.json, malformed-cli-result.json, probe-results.json, probe.py, runtime-refresh-comparison.json, skill-tests.log.

### Specialist08 evidence
The associated report and cross-review provide exact commands, source locations, observations and limits. Scratch artifacts: ci-checks.json, ci-jobs.json, ci-run.json, ci-web-annotation.txt, ci-yaml-probe.json, discovery-0.json, discovery-1.json, discovery-2.json, discovery-3.json, discovery-4.json, discovery-5.json, discovery-6.json, discovery-7.json, discovery-extra-0.json, discovery-extra-1.json, discovery-extra-2.json, discovery-extra-3.json, discovery-extra-4.json, discovery-extra-5.json, discovery-precise-0.json, discovery-precise-1.json, discovery-precise-2.json, discovery-precise-3.json, discovery-precise-4.json, discovery-precise-5.json, github-actions.json, github-dependencies.json, permissions-0.json, permissions-1.json, permissions-2.json, permissions-3.json, permissions-4.json, source-app.json, tool-schemas.json.

### Specialist09 evidence
The associated report and cross-review provide exact commands, source locations, observations and limits. Scratch artifacts: cross_probe.py, probe-results.json, probe.py.

### Specialist10 evidence
The associated report and cross-review provide exact commands, source locations, observations and limits. Scratch artifacts: focused-tests.log, probe-results.json, probe.py.

## Full source component inventory

Paths and byte sizes below identify all455 tracked source blobs at the pinned revision; historical snapshots are identified, not promoted to current evidence.

support | .app.json | 127 bytes
support | .codex-plugin/plugin.json | 1874 bytes
support | .github/workflows/ci.yml | 2622 bytes
support | .gitignore | 97 bytes
support | CHANGELOG.md | 5782 bytes
support | IMPLEMENTATION_STATUS.json | 28146 bytes
support | README.md | 13329 bytes
historical | audits/SOFTWARE-ARCHITECT-STUDIO-audit-2026-10-29.zip | 712118 bytes
historical | audits/sas-audit-2026-10-29/REPORT.md | 31431 bytes
historical | audits/sas-audit-2026-10-29/assemble-register.py | 14101 bytes
historical | audits/sas-audit-2026-10-29/coverage/skill-specifications.md | 26388 bytes
historical | audits/sas-audit-2026-10-29/ecosystem.md | 16291 bytes
historical | audits/sas-audit-2026-10-29/evidence/agent-roster.json | 2022 bytes
historical | audits/sas-audit-2026-10-29/evidence/baseline.json | 9392 bytes
historical | audits/sas-audit-2026-10-29/evidence/chromium.log | 2042 bytes
historical | audits/sas-audit-2026-10-29/evidence/component-inventory.json | 29016 bytes
historical | audits/sas-audit-2026-10-29/evidence/deliverable-checks.json | 807 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/01-init.stderr | 0 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/01-init.stdout | 207 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/02-empty-readiness.stderr | 0 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/02-empty-readiness.stdout | 604 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/03-change.stderr | 0 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/03-change.stdout | 9112 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/04-commit.stderr | 0 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/04-commit.stdout | 472 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/05-readiness.stderr | 0 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/05-readiness.stdout | 604 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/06-dry-handoff.stderr | 0 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/06-dry-handoff.stdout | 4467 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/07-handoff.stderr | 0 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/07-handoff.stdout | 4719 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/08-validate.stderr | 0 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/08-validate.stdout | 7314 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/09-validate-full.stderr | 0 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/09-validate-full.stdout | 7943 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/10-data-check.stderr | 0 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/10-data-check.stdout | 311 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/11-requirements-only-readiness.stderr | 0 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/11-requirements-only-readiness.stdout | 604 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/exercise.py | 6383 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/AGENTS.md | 148 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/adrs/ADR-001.md | 544 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/api.json | 132 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/architecture.md | 828 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/containers.mmd | 64 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/contracts.json | 360 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/data-model.md | 504 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/data-schemas.json | 522 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/diagram-map.json | 43 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/engineering-tasks.json | 1315 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/generation-manifest.json | 4545 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/handoff-report.json | 4379 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/implementation-tasks.md | 457 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/project.json | 4318 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/relationships.json | 3 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/requirements.md | 393 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/risk-register.json | 62 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/security.md | 136 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/tasks.json | 949 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.architecture-generations/1b07b9f7adbd4bfe8ed1e5e67428c4af/traceability.md | 339 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/.handoff-current.json | 432 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/AGENTS.md | 148 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/adrs/ADR-001.md | 544 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/api.json | 132 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/architecture.md | 828 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/containers.mmd | 64 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/contracts.json | 360 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/data-model.md | 504 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/data-schemas.json | 522 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/diagram-map.json | 43 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/engineering-tasks.json | 1315 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/handoff-report.json | 4379 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/implementation-tasks.md | 457 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/project.json | 4318 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/relationships.json | 3 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/requirements.md | 393 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/risk-register.json | 62 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/security.md | 136 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/tasks.json | 949 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff/traceability.md | 339 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/handoff-roundtrip.json | 569 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/idea.txt | 153 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/proposed.json | 3179 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/requirements-only.json | 1498 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/results.json | 42067 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/source-identity.json | 371 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/task-tracker/.architecture-history/commit-5adfd7d87c05449fa0fd3b8b7f36e248.json | 5190 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/task-tracker/.architecture-history/revision-0001.json | 428 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/task-tracker/.architecture-journal.json | 5190 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/task-tracker/HISTORY.md | 216 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/task-tracker/project.json | 4314 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/test_audit_followups.py.log | 2820 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert03/test_project_workflows.py.log | 1443 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert05-ci-manifest.log | 154 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert05-execution-summary.json | 1655 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert05-node.log | 2760 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert05-probes.json | 49117 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert05-probes.log | 4073 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert05-probes.py | 5507 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert05-python.log | 11632 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert05-source-inventory.json | 1035 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert07/probe-results.json | 4825 bytes
historical | audits/sas-audit-2026-10-29/evidence/expert07/probe.py | 2223 bytes
historical | audits/sas-audit-2026-10-29/evidence/final-source-preservation.json | 263 bytes
historical | audits/sas-audit-2026-10-29/evidence/proposed-diagrams-heuristic.json | 10271 bytes
historical | audits/sas-audit-2026-10-29/evidence/session-tools.json | 27636 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/.app.json | 127 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/.codex-plugin/plugin.json | 1874 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/.github/workflows/ci.yml | 1539 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/CHANGELOG.md | 2893 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/IMPLEMENTATION_STATUS.json | 28146 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/README.md | 8506 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/capabilities.json | 1364 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/docs/implementation-adapter.md | 1234 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/docs/integrations.md | 1252 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/evals/architecture-cases.json | 3255 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/evals/example-responses.json | 774 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/evals/semantic-review-rubric.json | 1076 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/examples/api.yaml | 461 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/examples/architecture.md | 1290 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/examples/atlas-project/project.json | 2639 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/examples/capacity.json | 404 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/examples/containers.mmd | 292 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/examples/score.json | 252 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/plugin.json | 2029 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/release/counterexamples-0.7.0.json | 15995 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/release/source-manifest.json | 7437 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/release/verification-0.7.0.json | 23008 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/release/verification.json | 26373 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/requirements-validation.lock | 400 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/requirements-validation.txt | 152 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/research/user-observation-template.json | 931 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/schemas/evidence-v1.schema.json | 1241 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/schemas/project-v2.schema.json | 8026 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/schemas/tool-capability-v1.schema.json | 1753 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/schemas/verification-receipt-v1.schema.json | 3270 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/api-data-contracts/SKILL.md | 995 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/implementation-planning-and-change/SKILL.md | 1294 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/repository-intelligence/SKILL.md | 1343 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/requirements-specification/SKILL.md | 1244 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/security-review/SKILL.md | 890 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/software-architecture/SKILL.md | 14559 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/software-architecture/references/automated-checks.md | 2115 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/software-architecture/references/capacity-cost.md | 2745 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/software-architecture/references/change-impact.md | 1492 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/software-architecture/references/decisions.md | 2599 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/software-architecture/references/deliverable-contracts.md | 1828 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/software-architecture/references/depth-and-audience.md | 1282 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/software-architecture/references/design-document.md | 3049 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/software-architecture/references/developer-handoff.md | 2226 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/software-architecture/references/diagrams.md | 1721 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/software-architecture/references/evaluation.md | 2082 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/software-architecture/references/github-review.md | 2182 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/software-architecture/references/implementation-status.md | 8536 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/software-architecture/references/project-lifecycle.md | 3014 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/software-architecture/references/review-checklist.md | 1810 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/software-architecture/references/scoring.md | 2428 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/software-architecture/references/specialized-designs.md | 2953 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/software-architecture/references/traceability.md | 1740 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/skills/test-debug-verify/SKILL.md | 941 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/strategy/deferred-decisions.md | 1245 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tests/browser/README.md | 570 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tests/browser/package.json | 239 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tests/browser/playwright.config.cjs | 502 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tests/browser/workbench.spec.cjs | 1952 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tests/fixtures/conformance.json | 13986 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tests/fixtures/rich-project.json | 5828 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tests/test_acceptance.py | 6071 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tests/test_architect_cli.py | 3723 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tests/test_audit_followups.py | 7876 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tests/test_project_workflows.py | 5244 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tests/test_release.py | 17642 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tests/test_workbench.cjs | 10493 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tools/architect_cli.py | 9970 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tools/artifact_compiler.py | 15557 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tools/behavioral_eval.py | 6009 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tools/calculators.py | 4162 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tools/check_release.py | 1634 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tools/disclosure.py | 1086 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tools/graph_engine.py | 4371 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tools/integration_contracts.py | 6487 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tools/project_model.py | 7954 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tools/project_workflows.py | 421 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tools/repository_evidence.py | 15023 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tools/revision_store.py | 7747 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tools/safe_io.py | 5299 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tools/validation_engine.py | 22824 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tools/validator_worker.py | 1128 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/tools/workflow_tools.py | 9115 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/workbench/index.html | 28947 bytes
historical | audits/sas-audit-2026-10-29/evidence/source-snapshot/workbench/project-core.js | 13313 bytes
historical | audits/sas-audit-2026-10-29/evidence/user-brief.txt | 128132 bytes
historical | audits/sas-audit-2026-10-29/finding-register.md | 13490 bytes
historical | audits/sas-audit-2026-10-29/findings.csv | 12142 bytes
historical | audits/sas-audit-2026-10-29/findings.json | 259380 bytes
historical | audits/sas-audit-2026-10-29/historical-regressions.md | 16042 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert01-browser-probes.json | 4284 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert01-cli-resume.json | 1022 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert01-doctor.json | 885 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert01-dom-probes-initial-harness-error.json | 4529 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert01-dom-probes.cjs | 3703 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert01-dom-probes.json | 2331 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert01-empty-readiness.json | 2111 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert01-expanded-notes.md | 33910 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert01-probes.cjs | 5428 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert01-rich-readiness.json | 2109 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert01-workbench-tests.json | 2760 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert01.md | 16953 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-architecture-notes.md | 15162 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/contradictory-handoff/AGENTS.md | 148 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/contradictory-handoff/api.json | 482 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/contradictory-handoff/architecture.md | 382 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/contradictory-handoff/containers.mmd | 47 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/contradictory-handoff/contracts.json | 482 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/contradictory-handoff/data-model.md | 44 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/contradictory-handoff/data-schemas.json | 3 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/contradictory-handoff/diagram-map.json | 3 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/contradictory-handoff/engineering-tasks.json | 277 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/contradictory-handoff/handoff-report.json | 4084 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/contradictory-handoff/implementation-tasks.md | 42 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/contradictory-handoff/project.json | 1080 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/contradictory-handoff/relationships.json | 3 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/contradictory-handoff/requirements.md | 106 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/contradictory-handoff/risk-register.json | 62 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/contradictory-handoff/security.md | 136 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/contradictory-handoff/tasks.json | 3 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/contradictory-handoff/traceability.md | 371 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/identity-project/.architecture-history/commit-d710878bc5c5451d933e99c7473fc4ff.json | 991 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/identity-project/.architecture-history/revision-0001.json | 417 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/identity-project/.architecture-journal.json | 991 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/identity-project/HISTORY.md | 192 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/identity-project/project.json | 417 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/large-project/.architecture-history/revision-0001.json | 413 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/large-project/HISTORY.md | 70 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/large-project/project.json | 413 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-probes/results.json | 4718 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-projection-probe.json | 983 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-schema-probe.json | 933 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-sqlite-input.json | 606 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02-sqlite-result.json | 807 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert02.md | 20906 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert03.md | 41013 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/checkout-impact.json | 7574 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/checkout-scan.json | 122417 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/cli-help.txt | 1121 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/cli-probes.json | 1782 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/delta-a-scan.json | 1840 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/delta-b-scan.json | 1840 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/edge-quota-scan.json | 23581 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/fixtures/delta-a/a.py | 9 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/fixtures/delta-b/a.py | 9 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/fixtures/edge-quota/ci.json | 938 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/fixtures/go-fitness/main.go | 54 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/fixtures/import-quota/a.py | 1017 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/fixtures/invalid-descriptors/package.json | 24 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/fixtures/invalid-descriptors/pyproject.toml | 42 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/fixtures/invalid-descriptors/requirements.txt | 15 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/fixtures/io-safety/safe.py | 43 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/fixtures/js-bleed/a.ts | 51 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/fixtures/large-declarations/a.py | 180000 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/fixtures/parse-cache/broken.py | 44 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/fixtures/prefix-boundaries/src2/a.py | 19 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/fixtures/relative-python/pkg/consumer.py | 24 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/fixtures/relative-python/pkg/forbidden.py | 0 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/freshness-stale-and-unknown.json | 663 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/go-fitness-scan.json | 1491 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/go-fitness.json | 438 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/go-rule-project.json | 578 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/import-quota-scan.json | 44759 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/interface-only-change.json | 5128 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/invalid-delta.json | 119 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/invalid-descriptors-scan.json | 2160 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/io-safety-scan.json | 1536 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/js-bleed-scan.json | 2325 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/large-declaration-probe.json | 746 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/migration-plan.json | 1756 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/optional-graph-impact.json | 3141 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/parse-cache-cold.json | 1534 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/parse-cache-warm.json | 1419 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/parse-cache.json | 370 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/prefix-boundaries-scan.json | 1887 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/probe-console-second.json | 8721 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/probe-console.json | 10235 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/probe-results.json | 13752 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/relative-python-scan.json | 2243 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/targeted-unittest.txt | 1313 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-evidence/unrelated-delta.json | 133 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04-probes.py | 7753 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert04.md | 37899 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert05.md | 30134 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert06.md | 41159 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert07.md | 15611 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert08-api-full.json | 1437 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert08-probes.json | 9096 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert08-probes.py | 5873 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert08.md | 16644 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert09-probes/bounded-input/item0.py | 10 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert09-probes/bounded-input/item1.py | 10 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert09-probes/bounded-input/item2.py | 10 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert09-probes/bounded-input/item3.py | 10 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert09-probes/evidence.json | 6474 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert09-probes/failed-validation-receipt.json | 337 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert09-probes/invalid-descriptor/compose.yaml | 19 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert09-probes/invalid-input/bad.json | 7 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert09-probes/probe.py | 4488 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert09-probes/probe.stdout.json | 6474 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert09-probes/scan-cache.json | 64554 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert09.md | 15574 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert10-probes/cli-probe.jsonl | 4422 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert10-probes/cli-probe.py | 1467 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert10-probes/failed-validation-receipt.json | 338 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert10-probes/focused-tests.log | 3287 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert10-probes/historical-tests.log | 1326 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert10-probes/invalid-api.json | 19 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert10-probes/probe.json | 5621 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert10-probes/probe.py | 3030 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert10-probes/wrong-responses.json | 464 bytes
historical | audits/sas-audit-2026-10-29/reviewers/expert10.md | 15966 bytes
historical | audits/sas-audit-2026-10-29/reviewers/peer-review-architecture.md | 7823 bytes
historical | audits/sas-audit-2026-10-29/reviewers/peer-review-integration.md | 4994 bytes
historical | audits/sas-audit-2026-10-29/reviewers/peer-review-quality-security.md | 8254 bytes
historical | audits/sas-audit-2026-10-29/roadmap.md | 11365 bytes
historical | audits/sas-audit-2026-10-29/skill-library.md | 34333 bytes
historical | audits/sas-audit-2026-10-29/specifications/diagrams/01-system.mmd | 234 bytes
historical | audits/sas-audit-2026-10-29/specifications/diagrams/02-request-deliverable.mmd | 137 bytes
historical | audits/sas-audit-2026-10-29/specifications/diagrams/03-skill-routing.mmd | 179 bytes
historical | audits/sas-audit-2026-10-29/specifications/diagrams/04-project-state.mmd | 203 bytes
historical | audits/sas-audit-2026-10-29/specifications/diagrams/05-repository.mmd | 205 bytes
historical | audits/sas-audit-2026-10-29/specifications/diagrams/06-code-generation.mmd | 202 bytes
historical | audits/sas-audit-2026-10-29/specifications/diagrams/07-debug-loop.mmd | 188 bytes
historical | audits/sas-audit-2026-10-29/specifications/diagrams/08-artifacts.mmd | 204 bytes
historical | audits/sas-audit-2026-10-29/specifications/diagrams/09-change-impact.mmd | 191 bytes
historical | audits/sas-audit-2026-10-29/specifications/diagrams/10-trust.mmd | 227 bytes
historical | audits/sas-audit-2026-10-29/specifications/diagrams/11-recovery.mmd | 230 bytes
historical | audits/sas-audit-2026-10-29/specifications/diagrams/12-discovery.mmd | 220 bytes
historical | audits/sas-audit-2026-10-29/specifications/diagrams/13-cross-plugin.mmd | 244 bytes
historical | audits/sas-audit-2026-10-29/specifications/engineering-contracts.md | 21137 bytes
historical | audits/sas-audit-2026-10-29/specifications/workflows-and-evaluation.md | 15875 bytes
support | capabilities.json | 1838 bytes
support | docs/contract-comparison.md | 2005 bytes
support | docs/implementation-adapter.md | 7431 bytes
support | docs/integrations.md | 3481 bytes
support | docs/recipes.md | 7690 bytes
support | evals/architecture-cases.json | 3255 bytes
support | evals/example-responses.json | 774 bytes
support | evals/routing-cases.json | 14195 bytes
support | evals/semantic-review-rubric.json | 1076 bytes
support | examples/api.yaml | 461 bytes
support | examples/architecture.md | 1290 bytes
support | examples/atlas-project/project.json | 2639 bytes
support | examples/capacity.json | 404 bytes
support | examples/containers.mmd | 292 bytes
support | examples/score.json | 252 bytes
support | plugin.json | 2029 bytes
support | release/counterexamples-0.7.0.json | 15995 bytes
support | release/followups-0.9.1.json | 4906 bytes
support | release/implementation-0.9.0.json | 39121 bytes
support | release/source-manifest.json | 12869 bytes
support | release/verification-0.7.0.json | 23008 bytes
support | release/verification-0.9.0.json | 40482 bytes
support | release/verification-0.9.1.json | 41460 bytes
support | release/verification.json | 26373 bytes
support | release/version.json | 277 bytes
support | requirements-validation.lock | 2160 bytes
support | requirements-validation.txt | 152 bytes
support | research/user-observation-template.json | 931 bytes
schema | schemas/capture-lineage-v1.schema.json | 6448 bytes
schema | schemas/evidence-v1.schema.json | 3283 bytes
schema | schemas/project-v2.schema.json | 8340 bytes
schema | schemas/run-summary-v2.schema.json | 2075 bytes
schema | schemas/semantic-review-v1.schema.json | 2618 bytes
schema | schemas/skill-bundle-v1.schema.json | 971 bytes
schema | schemas/skill-registry-v1.schema.json | 1389 bytes
schema | schemas/skill-routing-v1.schema.json | 850 bytes
schema | schemas/tool-capability-v1.schema.json | 1776 bytes
schema | schemas/user-observation-v1.schema.json | 938 bytes
schema | schemas/verification-receipt-v1.schema.json | 4007 bytes
skill | skills/ai-system-evaluation-and-safety/SKILL.md | 6153 bytes
skill | skills/api-data-contracts/SKILL.md | 2220 bytes
skill | skills/delivery-and-operations/SKILL.md | 5842 bytes
skill | skills/frontend-interaction-and-accessibility/SKILL.md | 5760 bytes
skill | skills/implementation-planning-and-change/SKILL.md | 2498 bytes
skill | skills/repository-intelligence/SKILL.md | 2557 bytes
skill | skills/requirements-specification/SKILL.md | 2470 bytes
skill | skills/security-review/SKILL.md | 2120 bytes
skill | skills/service-and-data-implementation/SKILL.md | 5887 bytes
skill | skills/software-architecture/SKILL.md | 16439 bytes
skill | skills/software-architecture/references/automated-checks.md | 2115 bytes
skill | skills/software-architecture/references/capacity-cost.md | 2745 bytes
skill | skills/software-architecture/references/change-impact.md | 1492 bytes
skill | skills/software-architecture/references/decisions.md | 2599 bytes
skill | skills/software-architecture/references/deliverable-contracts.md | 1828 bytes
skill | skills/software-architecture/references/depth-and-audience.md | 1282 bytes
skill | skills/software-architecture/references/design-document.md | 3049 bytes
skill | skills/software-architecture/references/developer-handoff.md | 2226 bytes
skill | skills/software-architecture/references/diagrams.md | 1721 bytes
skill | skills/software-architecture/references/evaluation.md | 2082 bytes
skill | skills/software-architecture/references/github-review.md | 2182 bytes
skill | skills/software-architecture/references/implementation-status.md | 8536 bytes
skill | skills/software-architecture/references/project-lifecycle.md | 3014 bytes
skill | skills/software-architecture/references/review-checklist.md | 1810 bytes
skill | skills/software-architecture/references/scoring.md | 2428 bytes
skill | skills/software-architecture/references/specialized-designs.md | 2953 bytes
skill | skills/software-architecture/references/traceability.md | 1740 bytes
skill | skills/test-debug-verify/SKILL.md | 2151 bytes
support | strategy/deferred-decisions.md | 1245 bytes
test | tests/browser/README.md | 1187 bytes
test | tests/browser/package-lock.json | 2286 bytes
test | tests/browser/package.json | 239 bytes
test | tests/browser/playwright.config.cjs | 483 bytes
test | tests/browser/serve_workbench.py | 1354 bytes
test | tests/browser/workbench.spec.cjs | 5571 bytes
test | tests/fixtures/conformance.json | 13986 bytes
test | tests/fixtures/rich-project.json | 5828 bytes
test | tests/test_acceptance.py | 6071 bytes
test | tests/test_adapter_readiness.py | 5593 bytes
test | tests/test_adapter_review.py | 2834 bytes
test | tests/test_architect_cli.py | 3723 bytes
test | tests/test_audit_followups.py | 7876 bytes
test | tests/test_contract_resolution_review.py | 5016 bytes
test | tests/test_contract_semantics.py | 7021 bytes
test | tests/test_integrity_implementation.py | 5541 bytes
test | tests/test_local_adapter.py | 12870 bytes
test | tests/test_project_workflows.py | 5244 bytes
test | tests/test_release.py | 17642 bytes
test | tests/test_release_inventory.py | 2798 bytes
test | tests/test_repository_integrity.py | 9937 bytes
test | tests/test_skill_evaluation.py | 7486 bytes
test | tests/test_validation_integrity.py | 7583 bytes
test | tests/test_workbench.cjs | 17233 bytes
tool | tools/architect_cli.py | 14317 bytes
tool | tools/artifact_compiler.py | 16031 bytes
tool | tools/behavioral_eval.py | 6009 bytes
tool | tools/calculators.py | 4162 bytes
tool | tools/check_release.py | 1634 bytes
tool | tools/check_source_manifest.py | 5716 bytes
tool | tools/codec.py | 1073 bytes
tool | tools/contract_resolution.py | 9858 bytes
tool | tools/disclosure.py | 1086 bytes
tool | tools/evaluation_records.py | 9659 bytes
tool | tools/execution_adapter.py | 29830 bytes
tool | tools/graph_engine.py | 6471 bytes
tool | tools/integration_contracts.py | 7944 bytes
tool | tools/operations_profile.py | 1149 bytes
tool | tools/project_model.py | 9455 bytes
tool | tools/project_workflows.py | 421 bytes
tool | tools/repository_evidence.py | 26881 bytes
tool | tools/revision_store.py | 8323 bytes
tool | tools/safe_io.py | 5163 bytes
tool | tools/skill_registry.py | 7836 bytes
tool | tools/validation_engine.py | 32589 bytes
tool | tools/validator_worker.py | 2311 bytes
tool | tools/workflow_tools.py | 9952 bytes
support | workbench/index.html | 36139 bytes
support | workbench/project-core.js | 15013 bytes
