# Proposed implementation initiatives

All initiatives are PROPOSED. No target source has changed. Effort ranges are rough engineering estimates for one maintainer after inspecting the current source; they exclude waiting for host/provider access, user studies and production rollout. Shared prerequisites: frozen GitHub baseline, current user/host authority, preserved user work, exact source identity, scoped regression evidence and no implicit publication. Common rollback: retain original data/journals/evidence and previous compatible code/reference bundle; quiesce cooperating writers before reverting state/identity machinery. Do not erase evidence or force a downgrade over incompatible new state.

## I01 — Restore real CI execution

- Findings/current behavior: INT-101. GitHub rejects ci.yml line30 before either job begins.
- Intended outcome/design: quote the full command or use a folded YAML scalar while retaining --only-binary=:all: and the hash lock. Validate workflow syntax outside the broken workflow; then observe the exact candidate commit's two jobs.
- Affected components: .github/workflows/ci.yml; release verification policy/docs. delivery-and-operations owns diagnosis; GitHub owns actual remote runs. No new tool is needed for the source correction.
- Dependencies/platform: GitHub workflow permission only when a later authorized task creates a commit/run; Python/Node/browser runner setup remains separate.
- Security/error handling: do not weaken dependency hashes or TLS to make CI green. Distinguish parse, setup, execution, cancellation and permission failure. Preserve unsuccessful runs.
- Acceptance/regression: the baseline file fails a YAML parser; the reviewed correction parses and retains both jobs. The revised commit actually starts and completes required Python/core and browser jobs, with run/attempt/log evidence. Parser success alone is insufficient.
- Effort/risk: 0.25–1 engineer day; low code risk, medium risk of discovering previously unexecuted setup/test failures.
- Rollback/success: revert only the workflow correction if necessary; retain failed run evidence and never call the prior workflow green. Success metric: required jobs executed against the exact candidate source, all required outcomes observed.

## I02 — Stable source-bound check completion

- Findings/current behavior: CODE-101, CODE-103, OPS-102, SEC-101. Editing executables loses mode; bytes-only identity omits chmod; cooperating A→B→A changes evade start/end hashes; descendants can outlive a passed check; receipts omit part of command/policy/executable provenance.
- Intended design: introduce source-edit-specific regular-file replacement that preserves reviewed safe metadata, leaving private state IO0600 intact. Version identities to include relevant modes. Hold one canonical workspace synchronization domain across inspect/check/final inspect and cooperating edits, independent of caller-selected state directory; alternatively check an immutable source snapshot with complete dependency/environment/fixture identity. Track ordinary process descendants through completion or return partial/blocked, then take the final identity. Capture canonical argv/cwd, selected policy identity, runner/executable/version provenance when obtainable without invoking an arbitrary --version command.
- Components/owners: tools/execution_adapter.py, tools/safe_io.py, tools/validation_engine.py, integration/receipt schemas and adapter docs; implementation-planning-and-change, test-debug-verify, delivery-and-operations and security-review. Host supplies process/isolation authority.
- Dependencies/platform: choose POSIX cooperative locking/process lifecycle contract; version plan/receipt/source identity formats before migration; host isolation for hostile/detached work remains external. Include control locks carefully so acquiring a lock does not change the source hash it protects.
- Security/errors: no global chmod relaxation, age/PID-only lock deletion, silent metadata promotion or sandbox claim. Unknown command identity, lingering children, stale source, conflicting locks or incomplete check discovery remains nongreen. Reconcile an uncertain effect before retrying.
- Acceptance/regression: executable0755 remains executable after edit; private receipts stay0600; chmod changes relevant identity; regular files/symlinks/user edits remain protected. Deterministic handshake A→B→A test cannot pass a receipt bound to A after observing B. Alternate state roots cannot create competing lock domains. Same-group child mutation after parent exit cannot coexist with a final completed green receipt. Stale/forged invocation metadata fails reconciliation. Positive ordinary checks still succeed with exact required counts.
- Effort/risk: 4–8 engineer days plus platform validation; high regression/compatibility risk around locks, signals, inherited descriptors and versioned identities.
- Rollback/success: quiesce writers; retain old/new identity version and journals; revert code only with a compatible state plan. Zero false source-bound completions in deterministic original counterexamples; all required baseline positive cases retain behavior. No claim covers unrelated writers or escaped hostile processes without host containment.

## I03 — Cooperative crash recovery without unsafe unlock

- Findings/current behavior: OPS-101. Abrupt exit leaves a persistent .architecture.lock; documented recover cannot obtain it even when the journal is otherwise recoverable.
- Design: prefer host/POSIX process-lifetime locking where compatible, with stable identity/diagnostic metadata and validated journal recovery. If retained ownership files are needed, verify process start/host/instance identity and distinguish dead, live and uncertain owners. Do not delete a lock merely because of age or a reused PID. Define stale-lock diagnosis separately from recovering canonical/history projections.
- Components/owners: revision_store.py and shared lock/recovery helpers; software-architecture and delivery-and-operations. It must compose with I02's workspace lock rather than create another competing lock.
- Dependencies/platform: explicit supported POSIX behavior, cooperating writers, source identity and journal schema compatibility. No distributed/hostile-writer lock guarantee.
- Security/errors: preserve original project, journal/history and ownership evidence on uncertainty; refuse live/uncertain owners; account for lock-inode replacement and inherited file descriptors.
- Acceptance/regression: terminate a real writer with os._exit during prepared and committed stages; recovery succeeds for a demonstrably dead cooperative owner, retains canonical identity and reconstructs only validated projections. Live owner, PID reuse, uncertain remote owner, conflicting/corrupt journal and source mismatch are refused safely. No data loss or duplicate logical revision in the tested cases.
- Effort/risk: 2–4 days; medium/high concurrency and compatibility risk.
- Rollback/success: stop writers, retain journals/owner diagnostics and use a validated compatible recovery path. Metric: recovery liveness plus preserved logical identity in the defined crash corpus; not certified power-loss durability.

## I04 — Honest, dimension-specific gates

- Findings/current behavior: QA-101, QA-102, AI-101, ARCH-101. Package validation ignores expected manifest inventory/hashes, AsyncAPI full gate is envelope-only, semantic summary accepts missing capture lineage, and review-ready accepts blank or content-free fields.
- Design: share a read-only generation integrity function between validator/recovery readers. Resolve the committed generation once, require managed expected files and supported internal identities, and verify each named representation. Preserve canonical_input versus compiler_context versus exported_project identities. Add explicit gate applicability/completeness: unsupported AsyncAPI version/schema is incomplete, not full-pass. Validate complete capture schema/lineage before reviewer accounting, without presenting schema/calibrated flags as reviewer authentication. At readiness time require nonblank acceptance and a supported meaningful NFR shape or explicit reasoned waiver; keep drafts importable.
- Components/owners: artifact_compiler.py, validation_engine.py, evaluation_records.py, project_model.py, architect_cli.py, schemas and readiness/QA docs; architecture, API contracts, test-debug, AI evaluation.
- Dependencies/platform: decide a versioned compatible NFR representation and legacy migration; optional jsonschema must not be the sole protection if dependency-free paths are supported. No network fetches for external schemas by default.
- Security/errors: validation never repairs source or projections; distinguish corruption/missing/unsupported/unknown. Local hashes cannot authenticate an attacker-consistent rewrite without an externally retained expected identity. Keep original malformed inputs recoverable.
- Acceptance/regression: missing API, altered Markdown and mismatched manifest internal representations are explicit integrity failures; untouched draft/full generations pass only applicable dimensions. Bogus AsyncAPI cannot pass full; supported version has actual validator evidence or incomplete status. ID+two self-consistent reviews without required capture fields is rejected in CLI and direct summary; valid captures retain dissent. Whitespace acceptance and malformed NFR scenario block review-ready without blocking draft import. Human approval/runtime remain independent.
- Effort/risk: 4–7 days; medium schema/compatibility/gate-consumer risk. Can split into independent reviewable changes while preserving common vocabulary.
- Rollback/success: keep old raw data and schema version; roll back code only after compatibility review. Metric: zero green results on original malformed/absent-evidence cases, positive applicable cases remain valid, required incomplete checks stay nongreen.

## I05 — Truthful bounded repository extraction

- Findings: REPO-101/102/103. Long valid JS imports disappear with false clean fitness; regex literals create imports; malformed nested descriptor shape aborts independent collection.
- Design/components: repository_evidence.py parser/extractor/fitness boundaries. Use a real supported syntax parser if a reviewed dependency is justified, or conservatively label unresolved lexical scope unknown. Recognition windows must never imply complete coverage after skipping a possible declaration. Distinguish literals/comments/regex, and isolate descriptor type failures per file while retaining unrelated observations and exact errors.
- Owners/dependencies: repository-intelligence plus test-debug-verify; preserve standard-library fallback and bounded IO/entry/time/declaration budgets. A new parser requires lock/license/version and supported grammar decisions.
- Security/errors: no execution of scanned code, remote refs or arbitrary repository scripts; unknown unsupported scopes cannot certify absence. Caches retain adapter/content identity and untrusted provenance.
- Acceptance/regression: baseline long/many-token imports yield violation or unknown, never satisfied-in-scope from absence. Regex fixture yields no import; valid control still extracts. Malformed project table retains other file observations and per-file diagnostics. Node syntax validity of fixtures remains an independent control. Symlink/FIFO/budget/cache protections stay intact.
- Effort/risk: 2–5 days; medium grammar/coverage/dependency risk. Rollback previous extractor identity with unknown results rather than reinstating false-clean claims. Metric: seeded precision/recall plus honest unknown rates on a declared held-out grammar corpus.

## I06 — Complete context, declared evidence and bounded disclosure

- Findings: GOV-101, ARCH-102, SEC-102. Resume silently cuts the brief; compact ADR evidence has ambiguous local-ID contract; some common credential formats survive minimization.
- Design/components: project_model.resume_packet and browser parity; graph/project schemas; disclosure.py and compiler identity records. Report context coverage/omitted ranges with defined Unicode units or preserve complete supported brief. Keep critical typed constraints/decisions explicitly accessible. Distinguish freeform evidence prose/URLs from declared-local-ID links; validate/traverse only explicit typed links, preserving original data. Exclude structured secret fields and add bounded common-format redaction with recorded transformations and remaining limitations.
- Owners/dependencies: coordinator, repository/contracts/security and knowledge workflows; capture canonical versus projected hashes. Avoid mandatory deep context for quick answers. Existing accepted origins and unknown extensions remain intact.
- Security/errors: do not follow evidence URLs automatically, expose raw secret values in diagnostics, or change authentication identifiers/business fields merely because their names resemble credentials. Unknown evidence reference or oversized context yields explicit gaps, not silent loss.
- Acceptance/regression: boundary/Unicode brief constraints are preserved or omitted with exact coverage; Python/browser projections disclose comparable scope; canonical bytes unchanged. Typed dangling local evidence fails while freeform URL/prose survives. Quoted/Bearer synthetic fixtures minimize correctly without corrupting ordinary semantics. Disclosure never claims exhaustive secret safety.
- Effort/risk: 2–5 days; medium compatibility and overredaction risk. Rollback reference/codec changes with original raw input retained; never restore an undisclosed secret-bearing export as a default. Metrics: context-coverage completeness, declared-link diagnostics and bounded-format secret fixture precision/recall.

## I07 — Current shared skill contracts and runtime evidence

- Findings: SKILL-101, reconciled SKILL-102, INT-102/103. Four roots use undefined aliases/common records; runtime initially differed then all11 root contents matched. Backend/full helper mapping remains unknown.
- Design: one current small contract reference maps exact skill identifiers and common input/result/evidence/status/source/authority fields. Link each relevant root explicitly. Keep skill loading progressive and do not require historical audit files. Capture source commit, package/backend identity when available, root/reference/helper bundle hashes and observed host tools/date. Preserve historical observations rather than rewriting them.
- Components/owners: skill roots/references, skill_registry/capture records, release docs; coordinator and AI evaluation. No new loader, dispatcher or plugin manifest format is proposed.
- Dependencies/platform: supported source/runtime release workflow and an actual backend ID before claiming marketplace mapping. The audit did not establish it through name lookup.
- Acceptance/regression: every alias resolves without old reports; no example grants authority or invents tools. A release comparison separates installed/exposed/read/executed and root versus helper parity. Initial7→later11 transition is shown accurately. No test equates number of skills with behavior quality.
- Effort/risk: 1–3 days plus platform mapping; low code/medium instruction context risk. Rollback to prior pinned bundle; retain observations. Metric: unresolved contract references zero in supported roots and exact bundle provenance for evaluated captures.

## I08 — Selective GitHub reference adoption

- Findings/value: optional domain detail can strengthen existing owners; benefit is expected/unverified. Seventeen inspected candidates, six repositories, four original proposed references.
- Design/affected skills: DraftA test-debug; B frontend; C security; D implementation plus explicit delivery-and-operations link for CI. Keep root IDs. Record each original path/revision/hash/license/attribution, adaptation, reviewer, dependency/assets status and evaluation. Load compact applicable subsections, not full specifications/frameworks.
- Dependencies/platform: I04 capture truth, I07 explicit contracts; optional actual tools. MIT/Apache notices and any NOTICE obligations must be retained for copied adaptations. Vercel notice packaging needs resolution. Trail of Bits content adaptation requires attributable CC-BY-SA compliance; a separated folder alone is not proof of compliance. Uninspected scripts/hooks/assets/agents/wrappers remain excluded until reviewed.
- Security/error rules: no automatic installers/latest npx, new logins, default agent spawning, source-provided tools/authority, blanket React/useContext rewrites or unconditional networkidle. Tool absence permits static review with explicit execution limits.
- Acceptance/regression: positive, negative, unsupported-version, missing-tool, injected-source and user-preference cases per draft; source/owner/license evidence present; no conflicting approval/authority rule imported. Paired real captures show incremental usefulness before improved model capability is claimed.
- Effort/risk: 2–4 days instruction/provenance work plus evaluation; medium behavior/context and license packaging risk. Roll back to previous reference bundle; no user-data migration. Metrics: held-out acceptance, evidence errors, user corrections, tokens/latency and unsupported activation, all with explicit denominators.

## I09 — Actual behavior and user outcome baseline

- Findings: PROD-101, ARCH-103, CODE-102, QA-103, AI-102, SEC-103 and historical REG107 are evidence gaps, not proof of poor quality.
- Design: freeze20 lifecycle benchmark contracts and30 stress scenarios before scoring. Use complete real captures with model/skills/tool/source/environment provenance, deterministic artifacts/checks plus calibrated independent semantic rubric. Run current baseline and candidate on comparable inputs; retain all runs, aborts and dissent. Separately observe representative users and correction burden.
- Components/owners: evals, capture/summary schemas, research observations, benchmark corpus; AI evaluation/test-debug/product. No fabricated model endpoint or extra provider subscription is assumed.
- Prerequisites: I04 prevents malformed capture success; actual authorized model/user collection mechanism and bounded task budget. Related subagent agreement is not statistical independence.
- Security/errors: synthetic/private-minimized tasks; prompt injection/authority refusal tests with no unsafe effects; unavailable runs count missing/blocked, not zero failures or passes. Blind reviewers to version when feasible.
- Acceptance: publish eligible task population, predeclared rubric/oracle, exact captures, source identities, reviewer calibration/disagreement, repeated-task variability, all terminal statuses and before/after limitations. Distinguish task success from lexical checks and user utility. No statistically significant claim without adequate design/sample.
- Effort/risk: 2–4 days harness/corpus plus variable run/reviewer/user effort; high measurement/design risk. Roll back claims/routing/reference changes if outcomes regress, retaining evidence. Targets: zero critical authority/evidence fabrication in seeded cases; task-specific improvement targets set after baseline, not invented now.

## I10 — Prove a minimal optional provider edge

- Finding: ECO-101/INT103 provider compatibility is largely unverified; catalog presence is not integration proof.
- Design: choose one real task and existing authorized provider; use minimized synthetic artifact, exact operation/source/schema identity, stable idempotency key where supported, required result/checks and reconciliation. Start with one-way immutable handoff; defer sync and canonical write-back.
- Components/owners: integration contracts/docs and selected provider skill. Actual provider tools own operations. Existing GitHub source reads are demonstrated; other edges require their own proof.
- Dependencies/platform: confirmed connection, task authority, schemas/scopes/retention/cost/rate limits, disposable target and recovery. No installation or permission change bundled into adoption.
- Acceptance: success, unavailable tool, denied permission, timeout/unknown effect, duplicate retry, stale source and conflicting output all produce correct bounded states. Provider state never overwrites Accepted ADRs without an authorized reconciliation. Record public/provider receipts only when actually returned.
- Effort/risk: 1–3 days per simple selected edge after access, integration-specific variability; medium privacy/reliability risk. Rollback disables optional edge and retains manual file/CLI handoff. Metric: task-specific conformance/failure-recovery outcomes and measured incremental benefit.

## I11 — Explicit retention accounting

- Finding: OPS-103 is an inspected unbounded cumulative history/generation growth risk, not observed data loss.
- Design/components: count history/generation bytes and retained revisions, expose diagnostics, document user-selected retention/export and perform explicit owned-generation cleanup only with reader/recovery protection. Never silently purge canonical accepted history or private backups.
- Owners/dependencies: delivery/knowledge/coordinator, actual filesystem; measure realistic storage before selecting limits. Existing per-input budgets stay enforced.
- Security/errors/acceptance: dry-run inventory first; protect unrelated/modified files and current committed generation, preserve recovery data, handle interrupted cleanup. Retention is opt-in and reversible by backup where applicable. No concurrent reader loses its committed generation in supported semantics.
- Effort/risk: 1–3 days after scope measurement; medium data-integrity risk. Rollback disables cleanup, retains prior backups. Metrics: measured storage growth, explicit user retention policy and successful recovery corpus; no arbitrary cost estimate.
