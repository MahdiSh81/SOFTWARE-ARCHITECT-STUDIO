# Logical maps — Mermaid source

These are source-reviewed logical diagrams for the proposed target and the inspected data model. They do not assert independently running services or a supported automatic plugin dispatcher. Actual Mermaid rendering was blocked because mmdc was unavailable; no renderer/parser success is claimed.

## System, request routing and skill selection

```mermaid
flowchart TD
  U["User request and host authority"] --> C["Coordinator: intent, depth, audience, scope"]
  C --> O["One primary owner among eleven skills"]
  O --> R["Applicable optional reference subsection"]
  O --> A["Available authorized host tool"]
  O --> M["Static review or manual handoff"]
  A --> E["Attributed source, artifacts and terminal outcomes"]
  M --> E
  E --> G["Independent applicable gates and reconciliation"]
  G --> V["Proportionate answer or portable handoff"]
```

## Tool selection, trust and cross-provider workflow

```mermaid
flowchart LR
  S["Selected task and target"] --> D["Discover actual tool and schema"]
  D --> P{"Authority and capability available?"}
  P -->|"Yes"| I["Minimized input and expected result"]
  P -->|"No"| F["Explicit blocked status and manual fallback"]
  I --> T["Host or provider owns execution"]
  T --> X["Untrusted result data and observed effects"]
  X --> Q["Compare invocation, source and required checks"]
  Q --> Z["Reconcile or preserve conflict and partial outcome"]
```

## Project context, artifact generation and change impact

```mermaid
flowchart TD
  P["Versioned canonical intent and Accepted origin"] --> R["Requirements, NFRs and constraints"]
  P --> A["ADRs, components, contracts and tasks"]
  N["Captured native source and contracts"] --> E["Typed evidence with exact source identity"]
  E --> A
  R --> L["Declared typed relationships"]
  A --> L
  L --> W["Impact witnesses and explicit missing-link unknowns"]
  P --> D["Disclosure transform and context coverage"]
  D --> H["Immutable handoff generation and named hashes"]
  H --> G["Atomic pointer; recoverable projections"]
```

## Program creation, debugging and validation

```mermaid
flowchart TD
  R["Observable acceptance and exact source"] --> F["Coherent files, imports, types, contracts and config"]
  F --> A["Authorized minimal edit preserving metadata"]
  A --> L["One stable workspace interval or captured snapshot"]
  L --> T["Actual required checks with bounded process lifecycle"]
  T --> P{"Original behavior and required checks satisfied?"}
  P -->|"Failure"| D["Control, discriminating hypothesis and minimal correction"]
  D --> F
  P -->|"Yes"| E["Exact source, invocation, environment and outcomes"]
  E --> G["Separate completeness, integrity, structure, review and runtime"]
  G --> H["Reconciled handoff with limitations"]
```

## Security boundaries

```mermaid
flowchart LR
  U["User and host authorization"] --> H["Host policy and actual isolation"]
  R["Repository, project, page and tool data"] --> D["Bounded parsing and review as untrusted data"]
  D --> C["Coordinator proposals and evidence"]
  C --> H
  H --> T["Scoped tool operation"]
  T --> E["Observed effects and independently applicable checks"]
  E --> C
  P["Private source and history"] --> M["Explicit minimized disclosure profile"]
  M --> X["Selected external provider only if authorized"]
```

## Failure recovery

```mermaid
flowchart TD
  F["Failure, timeout or uncertain effect"] --> S["Preserve completed work, original data and evidence"]
  S --> L["Diagnose canonical lock ownership"]
  L --> U{"Dead owner proven in supported scope?"}
  U -->|"No or unknown"| B["Refuse unsafe unlock and report recovery blocker"]
  U -->|"Yes"| J["Validate journal, source and logical identity"]
  J --> C{"Consistent recoverable state?"}
  C -->|"No"| B
  C -->|"Yes"| R["Recover projections or complete validated commit"]
  R --> V["Verify current state before idempotent retry"]
```

## Proposed upstream provenance record

This is an internal design record, not a plugin manifest or authority grant. Required fields: owner_skill, source_repository, immutable_commit, selected_paths with captured content hashes, applicable license and attribution/NOTICE evidence, adaptation summary, reviewed instruction/dependency/assets scope, excluded helpers, reviewer/date, required tool capabilities, conflict decisions, evaluation case IDs and outcome evidence. Record the exact loaded local bundle separately from the source candidate list. A listed or reviewed source is not necessarily loaded, installed, executed or behaviorally validated.
