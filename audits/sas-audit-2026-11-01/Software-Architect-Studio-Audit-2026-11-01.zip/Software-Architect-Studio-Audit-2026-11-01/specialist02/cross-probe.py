import json
import sys
from pathlib import Path
from tempfile import TemporaryDirectory

sys.path.insert(0, '/workspace/SOFTWARE-ARCHITECT-STUDIO/tools')
from project_model import new_project, resume_packet
from artifact_compiler import handoff, resolve_generation
from validation_engine import validate

scratch = Path(__file__).parent
results = {}
with TemporaryDirectory(dir=scratch) as temp:
    base = Path(temp)
    p = new_project('Independent cross-review')
    p['requirements'] = [{'id':'FR-001','description':'Return a value','acceptance':'Returns one'}]
    p['tasks'] = [{'id':'TASK-001','requirements':['FR-001'],'acceptance':'A fixture observes one'}]
    p['interfaces'] = [{'id':'API-001','method':'GET','path':'/one','authentication':'public',
                        'operation':{'responses':{'200':{'description':'One','content':{'application/json':{'schema':{'type':'integer'}}}}}}}]
    source = base/'source'; source.mkdir()
    (source/'project.json').write_text(json.dumps(p))
    out = base/'handoff'
    handoff(source, out)
    generation = resolve_generation(out)
    def summary(result):
        return {k:result[k] for k in ('policy_ok','ok','checks','note')}
    results['intact_handoff'] = summary(validate(out,gate='structural'))
    (generation/'api.json').unlink()
    results['missing_manifest_listed_api'] = summary(validate(out,gate='structural'))
    (generation/'architecture.md').write_text('Entirely different architecture bytes.\n')
    results['missing_api_and_changed_markdown'] = summary(validate(out,gate='structural'))
    manifest = json.loads((generation/'generation-manifest.json').read_text())
    results['manifest_still_lists_api'] = 'api.json' in manifest['files']
    async_path = base/'asyncapi.json'
    async_path.write_text(json.dumps({'asyncapi':'bogus','info':{},'channels':{}}))
    results['invalid_asyncapi_full_gate'] = summary(validate(async_path,gate='full'))
    p['brief'] = 'A'*4000+' TRAILING HARD CONSTRAINT'
    packet = resume_packet(p)
    results['resume_projection'] = {'source_characters':len(p['brief']),
         'packet_characters':len(packet['brief']),
         'trailing_constraint_preserved':'TRAILING HARD CONSTRAINT' in packet['brief'],
         'packet_keys':sorted(packet), 'canonical_unchanged':p['brief'].endswith('TRAILING HARD CONSTRAINT')}

(scratch/'cross-probe-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({k:v if isinstance(v,bool) or k=='resume_projection' else {'ok':v['ok'],'policy_ok':v['policy_ok'],'checks':[(c['check'],c['status']) for c in v['checks']]} for k,v in results.items()},indent=2))
