# Specialist 02 cross-examination — QA and continuity

2026-11-01. Reviewed specialist05/report.md and specialist10/report.md only after all ten independent initial passes had completed. Reinspected pinned target source; wrote and executed `cross-probe.py` solely under this specialist's scratch directory. No source edit, dependency installation, publication or whole-suite repetition occurred.

## Accepted findings and independent evidence

| Finding | Independent result | Decision |
|---|---|---|
| QA-101 — Generated handoff integrity/coverage is not validated | Generated a fresh scratch handoff with a real declared API. Intact structural validation passed with contract correspondence. Deleted the committed generation's manifest-listed `api.json`: `policy_ok` remained true and correspondence disappeared. Changed `architecture.md` bytes: result remained true. Manifest still listed API. | Accept the missing integrity/coverage dimension. Existing checks correctly report their narrower content results; they do not establish a complete unchanged generation. |
| QA-102 — Invalid AsyncAPI passes full gate | Independently submitted `{"asyncapi":"bogus","info":{},"channels":{}}`. `gate='full'` returned `policy_ok:true`; sole check was `AsyncAPI declaration:passed`, detail “basic envelope only; full schema not verified.” | Accept a deficient declaration check and absent full-format applicability. Invalid version is not a supported AsyncAPI declaration. Treat schema verification as separately unsupported/incomplete when required. |
| GOV-101 — Unmarked resume excerpt | Valid brief of 4,025 Unicode code points became 4,000; trailing constraint disappeared; packet had no excerpt/omission metadata. Canonical object was unchanged. Source confirms browser uses full brief. | Accept context-projection defect, not canonical data loss. An intentional context budget is valid if explicit and recoverable. |

All three are now **Independently reproduced** within these synthetic inputs. Evidence: `cross-probe-results.json`. Exact current source: `validation_engine.py:356–394,445–492`; `artifact_compiler.py:106–120,123–176`; `project_model.py:110–116`; `project-core.js:56`.

## Guarantees the current gates actually make

`structural` enumerates present supported files, runs their applicable checks and fails observed failures, required skips, budgets and enumeration stops. It does not compare the observed tree with the compiler manifest. Markdown is not among parsed suffixes. Therefore a deleted expected file can remove a check rather than fail it.

`full` additionally treats incomplete OpenAPI schema, Mermaid renderer and project JSON Schema checks as blocking (`validation_engine.py:485`). It is not a universal schema-validation switch for every file format: AsyncAPI has no distinct schema-check record. The result note explicitly says “Scoped structural gates only; no certification, runtime deployment or universal semantic correctness.” The QA findings should preserve this counterevidence. Do not describe the product as claiming that a full pass proves runtime behavior or architectural quality.

Compiler `review-ready` completeness is a different dimension again. My ARCH-101 blank-content counterexample remains independent of QA-101/102: a file inventory can be intact while the requirements lack meaningful content. A complete profile, consistent artifact bytes, full dialect schema, human semantic review and runtime verification must each report their own status.

## Acceptance refinements

For QA-101, detect an actual generated-handoff marker or explicitly selected integrity profile. Validate bounded manifest shape, relative paths, safe IO, duplicates, existence/type, exact byte hashes and internally consistent named identities before declaring that generation intact. Continue independent content checks and retain exact missing/changed/unchecked counts. A standalone OpenAPI file without a handoff manifest should still support structural inspection; absence of an irrelevant manifest must not break ordinary draft workflows. Do not rewrite files during validation or delete extra user notes.

Named representations matter: `canonical_input_hash`, `compiler_context_hash`, `exported_project_hash` and file-byte hashes can validly differ. Compare each to its declared representation. Do **not** compare minimized exported `project.json` directly with canonical-input hash and call the intentional disclosure transform corruption.

For QA-102, declare supported AsyncAPI dialects and minimum envelope fields. Invalid/unknown versions must not report a passed declaration. When full AsyncAPI schema verification is required but unavailable, produce explicit unsupported/skipped/incomplete status and a blocked full policy. Structural-only envelope inspection can remain useful. A new validator installation is not necessary to stop misleading gate completeness; any future validator must be pinned, offline and budgeted.

For GOV-101, preserve a bounded excerpt if useful, but publish included/omitted ranges, original length, reason, projection version and source identity. Define range units explicitly: Python Unicode code-point indexing and JavaScript UTF-16 offsets differ for non-BMP text. Cross-surface parity should concern coverage meaning, not force identical budget or packet bytes. Boundary cases need empty, absent, 3,999/4,000/4,001 and non-BMP content, plus a relevant constraint after the budget. Consumer behavior must retrieve relevant authorized omitted context or state the limit. Draft/project bytes and Accepted provenance remain unchanged.

## Rejected overreach and residual dissent

- A self-consistent rewritten manifest and artifact set cannot establish authenticity or detect all attacker-controlled changes without an externally trusted expected identity/signature. QA acceptance wording “changing generation/source identity blocks integrity policy” is valid for mismatched internal identities or an external expected baseline, not for every coherent new generation. Hashes alone do not authenticate.
- Do not call the manifest gap a failure of OpenAPI structural semantics, a semantic review, stale-file cleanup or immutable-pointer publication. These are different checks and responsibilities.
- Do not require a full schema validator for all arbitrary JSON/YAML or force all incomplete drafts into a production gate. Apply declared format/profile requirements explicitly.
- Do not treat trailing-brief omission as stored-project corruption or make raw history/extensions active context to achieve “complete memory.”
- Severity is context-dependent: P1 is justified for manifest/full-interface gates relied on for release or downstream handoff; isolated report-only file inspection has a narrower impact. No P0 incident was demonstrated.

## Final verdict

Accept all three findings with the refinements above. Reuse the existing manifest, safe IO, profile dimensions and portable project; no new service, knowledge store, dispatcher or skill is necessary. The decisive improvements are explicit coverage, format applicability and named representation identities. No substantive dissent remains on observed behavior; authenticity guarantees and universal “full” semantics must stay narrower than the proposed repairs can prove.
