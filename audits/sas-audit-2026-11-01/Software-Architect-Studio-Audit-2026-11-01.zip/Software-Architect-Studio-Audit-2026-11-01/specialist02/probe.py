import copy
import json
import sys
from pathlib import Path

TARGET = Path('/workspace/SOFTWARE-ARCHITECT-STUDIO')
sys.path.insert(0, str(TARGET / 'tools'))
from project_model import new_project, project_checks
from artifact_compiler import readiness, compile_plan
from graph_engine import impacts_from_seeds

def minimal():
    p = new_project('Architecture audit synthetic record')
    p['requirements'] = [{'id': 'NFR-001', 'description': 'A complete testable latency scenario',
                          'acceptance': 'p95 stays within agreed budget',
                          'scenario': {'workload': '10 requests/sec', 'environment': 'isolated test',
                                       'measure': 'p95 latency', 'target': '<=100ms'}}]
    p['tasks'] = [{'id': 'TASK-001', 'requirements': ['NFR-001'],
                   'acceptance': 'A workload fixture records p95 latency'}]
    return p

results = {}
p = minimal()
p['requirements'][0]['acceptance'] = '   '
p['requirements'][0]['scenario'] = '   '
p['tasks'][0]['acceptance'] = '   '
results['whitespace_acceptance_and_scenario'] = {
    'input': p, 'project_diagnostics': project_checks(p),
    'readiness': readiness(p, 'review-ready')}
files, report = compile_plan(p, 'review-ready')
results['whitespace_acceptance_and_scenario']['compiled_profile_satisfied'] = report['readiness']['profile_satisfied']

p = minimal()
p['requirements'][0]['scenario'] = {'unrelated': True}
results['invalid_scenario_shape'] = {'input': p, 'project_diagnostics': project_checks(p),
                                    'readiness': readiness(p, 'review-ready')}

p = minimal()
p['decisions'] = [{'id': 'ADR-001', 'status': 'Accepted', 'title': 'Choose database',
                   'decision': 'Use a relational database', 'evidence': ['EVD-404']}]
results['dangling_decision_evidence'] = {'input': p, 'project_diagnostics': project_checks(p),
                                        'readiness': readiness(p, 'review-ready')}
files, report = compile_plan(p, 'review-ready')
results['dangling_decision_evidence']['adr_output'] = files['adrs/ADR-001.md']

p = minimal()
p['evidence'] = [{'id': 'EVD-001', 'path': 'src/schema.sql', 'sha256': 'synthetic'}]
p['decisions'] = [{'id': 'ADR-001', 'status': 'Accepted', 'evidence': ['EVD-001']}]
results['evidence_link_not_in_default_impact_graph'] = impacts_from_seeds(p, [{'group':'evidence', 'id':'EVD-001'}])
p['relationships'] = [{'id':'REL-001', 'kind':'depends_on',
                       'from':{'group':'decisions', 'id':'ADR-001'},
                       'to':{'group':'evidence', 'id':'EVD-001'}}]
results['explicit_typed_evidence_link_is_available'] = impacts_from_seeds(p, [{'group':'evidence', 'id':'EVD-001'}])

Path(__file__).with_name('probe-results.json').write_text(json.dumps(results, indent=2)+'\n')
print(json.dumps({k: {'project_diagnostics': v.get('project_diagnostics'),
                     'profile_satisfied': v.get('readiness', {}).get('profile_satisfied'),
                     'blockers': v.get('readiness', {}).get('blockers'),
                     'affected_decisions': v.get('affected', {}).get('decisions')}
                  for k,v in results.items()}, indent=2))
