# Specialist 02 — Principal Software Architect

Independent first pass, 2026-11-01 (Asia/Tehran). Target: `MahdiSh81/SOFTWARE-ARCHITECT-STUDIO`, commit `1fa377cc9cbe7054d7edbf8091e22efaa296c05e`; the parent verified that GitHub `master` and the local execution mirror match. No new specialist report was read before this assessment. No target file was changed, no package was installed, and no external account, publication, deployment or application database was touched. Bytecode writes were disabled.

Source links below use the pinned GitHub revision. Line numbers also identify the local mirror. Scratch evidence is beside this report.

## 1. Executive assessment

Retain the modular ChatGPT skill package, portable canonical project and optional local toolkit. Its strongest architectural choices already distinguish intent from implementation, record source identity, resolve competing HTTP contract representations, keep review/runtime/freshness dimensions separate, publish coherent immutable handoff generations, and expose graph witnesses as review scope. These choices are appropriate for a ChatGPT assistant and do not justify a rewrite or distributed service architecture.

The most consequential newly reproduced architecture defect is narrower than a general false-success claim: `review-ready` completeness accepts blank acceptance criteria and a content-free NFR scenario. The result continues to say human review is unknown and runtime verification was not run, but the completeness dimension itself becomes misleading. A second gap permits dangling ADR evidence references and leaves ordinary ADR evidence links outside change propagation. Preserve draft flexibility; strengthen readiness and explicitly typed evidence links.

Architectural reasoning quality is **unverified**. The inspected instructions are sensible, and deterministic checks exercise their supporting data machinery, but neither proves model reasoning, distributed-system correctness, migration safety or user benefit.

## 2. Scope inspected

| Component | Responsibility, inputs → outputs | Dependencies, security boundary, limitations |
|---|---|---|
| `skills/software-architecture/SKILL.md:9–106` | User goal/context → scoped design, decisions, review, handoff and task ownership | Host reasoning and actual available tools; instructions confer no execution authority |
| References `specialized-designs.md`, `design-document.md`, `decisions.md`, `review-checklist.md`, `traceability.md`, `change-impact.md`, `developer-handoff.md`, `deliverable-contracts.md`, `scoring.md` | Pattern, tradeoff, evidence and output guidance | Primarily instruction-only; not a semantic verification engine |
| `skills/api-data-contracts/SKILL.md:7–19` | Contracts/consumers/version → compatibility findings and migration obligations | Actual validator availability; external references blocked by default; no arbitrary SQL |
| `skills/service-and-data-implementation/SKILL.md:28–90` | Invariants and source/data scope → coherent service/data changes with actual receipts | Actual authorized runtime/database; fixture execution and recovery required for safety claims |
| `schemas/project-v2.schema.json:1–396` | Draft structural project contract | Additional properties deliberately preserved; schema alone does not validate all semantic references |
| `tools/project_model.py:7–129` | Canonical draft, known field checks, references, ADR supersession, resume, traceability | Pure serialization/hash module; local acceptance records preserve history but grant no tool authority |
| `tools/contract_resolution.py:45–179` | Native and embedded HTTP operations → resolved API, conflicts, auth policy | Pure, bounded offline references; conservative structural comparison, no general schema equivalence |
| `tools/artifact_compiler.py:11–176` | Project/profile/disclosure → readiness, files, manifest and immutable generation | IO publisher separate from compile plan; owned projections protected; not full schema/render/runtime verification |
| `tools/graph_engine.py:6–97` | Typed records/links and old/new project → deterministic closure and witnesses | Explicit/legacy declared links; missing semantic links require manual review |
| `tools/operations_profile.py:4–21` | Optional operations intent → unknown/specified profile | Presence checks only; all execution/deployment/restore outcomes stay not run |
| `tools/workflow_tools.py:17–34,46–68` | Migration worksheet, decision experiment plan, SQLite schema subset | Worksheet is proposed; SQLite only generated allowlisted DDL in memory |
| `docs/recipes.md`, `docs/contract-comparison.md` | Cross-owner workflows and supported contract semantics | Explicit host/tool, isolation and provenance limits |
| Relevant tests and historical release ledger | Reproduction fixtures and historical dispositions | Historical reports are not fresh verification; only listed suites were rerun |

No new multi-file application, live migration, cloud architecture, load test, fault injection, browser interaction or deployment was run by this specialist. Those omissions are scope limits, not claims that such capabilities are absent from the host.

## 3. Methodology

1. Established clean local HEAD and inspected current source before historical findings.
2. Followed architecture responsibility boundaries from skill methodology into canonical validation, resolution, readiness, compilation, impact and operational profiles.
3. Ran deterministic contract suites and safe synthetic counterexamples under scratch; imported toolkit modules with `PYTHONDONTWRITEBYTECODE=1`.
4. Checked counterevidence: confirmed explicit typed evidence relationships already propagate correctly, and existing runtime/human-review caveats survive the misleading completeness result.
5. Read historical specialist 02 and the implementation ledger only after the independent current-source pass; did not substitute their claims for new execution.

Capability labels use exactly one of the brief's categories per row; evidence status is separate.

## 4. Verified strengths

| Capability | Classification | Evidence status and scope |
|---|---|---|
| Reject supported native/embedded API disagreement; preserve literal property names and OpenAPI 3.0/3.1 reference semantics | Verified tool-based | Successfully executed: current contract semantics and resolution suites; 15+7 definitions, with optional-validator detail in section 15 |
| Default handoff export can be reloaded/regenerated; emitted project/object and byte hashes are named separately | Verified tool-based | Successfully executed: integrity suite `test_shareable_export_is_self_contained_and_named_hashes_match`; source `artifact_compiler.py:55–67,105–111` |
| Empty project remains valid draft but is blocked from review-ready completeness | Verified tool-based | Successfully executed: integrity suite; `artifact_compiler.py:20–23` |
| Supersession preserves predecessor without copying its approval and refuses a second successor | Verified tool-based | Successfully executed: integrity suite; `project_model.py:118–129` |
| Cross-project replacement is refused and advertised canonical size composes into recovery journal | Verified tool-based | Successfully executed: integrity suite fixtures, not a power-loss/durability test |
| Typed evidence dependency yields an attributable ADR impact witness | Verified tool-based | Successfully executed: `probe-results.json/explicit_typed_evidence_link_is_available` |
| Architectural guidance covers ownership, consistency, idempotency, bounded retries, failure domains, tenant authority, migrations and recovery | Instruction-only | Directly inspected: `SKILL.md:50–60`; `specialized-designs.md:3–27`; `review-checklist.md:10–20`; no live reasoning-quality claim |
| Immutable generations and atomic pointer distinguish authoritative output from recoverable projections | Implemented, unverified | Directly inspected: `artifact_compiler.py:123–176`; this specialist did not inject publisher failures |

## 5. Verified defects

### ARCH-101 — P1 — Review-ready completeness accepts whitespace and content-free NFR scenarios

**Observed behavior:** a synthetically valid canonical project has one NFR and one linked task. The requirement acceptance, task acceptance and scenario are three spaces each. `project_checks` returns `[]`; `readiness(project,'review-ready')` returns `profile_satisfied: true`, `blockers: []`, completeness `specified within supported scope`. `compile_plan(...,'review-ready')` succeeds with the same status. A separate case with meaningful acceptance but `scenario: {"unrelated": true}` also passes.

**Evidence:** `probe.py`, `probe-results.json/whitespace_acceptance_and_scenario` and `/invalid_scenario_shape`; [readiness checks](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/artifact_compiler.py#L11) use truthiness at lines 16–17,37; [canonical checks](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/project_model.py#L49) type acceptance as string without nonblank content and do not type scenario. The required NFR obligations are explicit at skill lines 52 and developer-handoff reference line 5.

**Impact:** an implementation handoff can be called complete while carrying no observable acceptance. This is a completeness gate defect, not proof that the system reports tests, human review or production correctness as passed; those dimensions remain correctly separate.

**Root cause:** permissive draft storage and semantic readiness share presence tests without a minimum supported content contract.

**Proposed change / initiative A02-01:** leave draft import tolerant. At review-ready time require trimmed nonblank acceptance on applicable requirements/tasks; validate NFR scenario structure for nonempty workload, environment, response measure and target, or an explicit scoped waiver. Return exact record/field issues. Use one conformance corpus across CLI, schema-supported subset and workbench where the gate exists. Never claim these checks prove acceptance quality.

**Acceptance:** both retained counterexamples produce blockers; a complete scenario passes; missing, wrong type, whitespace and empty nested values fail predictably; waived-with-reason remains distinct from passed; quick advice still needs no project; runtime/human review never become passed from completeness.

**Classification:** Verified tool-based. **Evidence status:** Successfully executed. **Confidence:** high for demonstrated inputs; frequency in real usage unknown.

### ARCH-102 — P2 — Local ADR evidence IDs lack integrity and ordinary links do not propagate impact

**Observed behavior:** an Accepted `ADR-001` with `evidence: ["EVD-404"]` and no evidence record passes canonical checks and review-ready compilation. Its ADR file repeats the unresolved ID. Separately an existing `EVD-001` is referenced by `ADR-001.evidence`; an evidence-seeded graph returns no affected decisions. Adding an explicit typed `depends_on` relationship produces the correct ADR witness.

**Evidence:** `probe-results.json/dangling_decision_evidence`, `/evidence_link_not_in_default_impact_graph`, `/explicit_typed_evidence_link_is_available`; [link metadata](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/project_model.py#L12) excludes evidence references from `LINKS`; `graph_engine.py:10–19` uses only that metadata and explicit relationships; compiler `artifact_compiler.py:78–79` prints ADR evidence. Traceability reference lines 3,20 requires attributed evidence and preserving source identity.

**Interpretation:** dangling machine-style local IDs are an evidence-integrity gap. The graph result is a documented missing-link limitation, not a violated promise of complete semantic impact. Explicit typed relationships already provide the simpler mechanism, so a new evidence service or graph database is unwarranted.

**Proposed change / initiative A02-02:** define supported local evidence links explicitly. Prefer existing typed `depends_on` relationships, or accept a documented compact array of local IDs and derive equivalent graph edges. Validate those declared local IDs and include them in ADR output and freshness/impact review. Retain legacy freeform evidence as attributed opaque data with a migration diagnostic; do not reinterpret URLs or prose as local IDs, fetch them automatically, discard them, or let them grant permission.

**Acceptance:** missing supported local IDs produce exact diagnostics; existing IDs survive export/regeneration; changing evidence reaches dependent ADR/task through a witness; typed and compact equivalent links do not duplicate impact; legacy prose remains preserved; unknown source freshness stays unknown.

**Classification:** Verified tool-based. **Evidence status:** Successfully executed. **Confidence:** high for the declared compact-field gap; broader impact cannot be inferred.

## 6. Missing capabilities and evidence gaps

**ARCH-103 — P1 for a quality claim, otherwise P2 — No measured architecture reasoning baseline in this inspection.** Pattern coverage, fixtures and a lexical harness are not evidence that the model chooses correct transaction boundaries, avoids overspecified services or handles contradictory NFRs. `docs/recipes.md:48–59` correctly states this limit. Capability classification **Unknown**; evidence status **Unverified**. Propose initiative A02-03: paired held-out architecture tasks with actual captures, equal tool access and calibrated review; retain disagreement. Do not call absent observations a failed model.

**ARCH-104 — P2 — NFR and operational intent are loosely structured.** Operational profile checks fields for truthiness and explicitly reports runtime/deployment/restore `not_run` (`operations_profile.py:9–21`). The program does not validate SLO units/windows, workload/target consistency, RTO/RPO or migration recovery feasibility. Classification **Partial**; evidence **Directly inspected**. Add typed on-demand scenario/operational reference contracts only when a real task needs executable comparison. Semantic judgment and measured drills remain necessary; do not require an operational dossier for a simple script.

**ARCH-105 — P2 — Framework/version-specific architecture guidance needs a maintained evidence path.** Specialized patterns are compact references, not a catalog of vendor compatibility, migrations or operational tests. The instructions already require current primary documentation for unstable model facts (`specialized-designs.md:27`) and version-sensitive language/framework references (`docs/recipes.md:61–63`). Classification **Tool-dependent**; evidence **Directly inspected**. A curated GitHub programming reference pack should attach to existing owners and detected versions; wholesale skill import is not justified by missing category names.

## 7. Risks

- Portable intent, captured source, review judgment and runtime evidence can drift independently. Preserve their separate identities and make stale evidence visible; hash equality establishes identity, not semantic truth.
- Schema/native-interface duplication is a continuing regression surface even with repaired normalization. Keep adversarial literals, schema context and reference semantics in the contract corpus.
- Local compiler/publisher and browser are separately implemented. New readiness rules need equivalence fixtures where each runtime supports them, with explicit unsupported cases rather than silent differences.
- A declared operational profile can be structurally present while practically useless. Keep `specified` separate from observed health, deployment, load and recovery.
- Compact, multi-statement source lines make policy review harder. Improve readability while touching affected seams; broad architectural refactoring has no measured benefit here.
- Imported GitHub skills may contain unwanted shell execution, hidden network assumptions, authority changes or conflicting instructions. Treat them as source material and review license, pinned revision, dependencies and behavior before adoption.

## 8. Redundant functionality

The inspected architecture has purposeful overlap: coordinator owns decisions, API/data owner owns contract evolution, service/data owner owns actual runtime invariants and operations owner owns rollout/recovery. Keep those boundaries. The duplicate native/per-interface HTTP representation remains justified for authoring only while conflict detection remains centralized. Avoid a new generic architecture-pattern skill, universal dispatcher, database of ADRs or service mesh around these existing functions. No source-backed case supports removing the local workbench or CLI merely because ChatGPT can output Markdown.

## 9. Recommended improvements

| Initiative | Finding | Concrete change and affected components | Dependencies / risks / effort / rollback |
|---|---|---|---|
| A02-01 | ARCH-101 | Semantic readiness helper for trimmed acceptance and structured NFR fields; exact diagnostics in `artifact_compiler.py`; relevant schema/JS parity corpus | No new infrastructure; preserve permissive draft input; estimated 1–2 engineer days incl. regression review, not a measured estimate; revert stricter profile gate while retaining old project bytes |
| A02-02 | ARCH-102 | Define local evidence link contract and reuse typed graph edges; validate supported IDs, export witness/source relationship | Requires legacy field inventory first; avoid treating prose as ID or authority; estimated 2–4 engineer days incl. migration fixtures; retain original fields and version the normalization, rollback via original data |
| A02-03 | ARCH-103 | Architecture decision casebook and paired actual captures with calibrated rubric and dissent | Needs authorized model runs/reviewers and representative tasks; no pass claim before evidence; initial instrument work 1–2 days plus task/review effort; reference/casebook rollback preserves captures |
| A02-04 | ARCH-104/105 | On-demand version-pinned pattern references for actual stacks and operational scenarios | Depends on task demand and primary docs/GitHub research; support only named versions, no universal promise; per-pack estimate after scope; pin previous pack hash for rollback |

Ready-to-use coordinator instruction draft for A02-01/A02-02:

> Before reporting a handoff as review-ready, check the supported applicable fields rather than their mere presence. Requirement and task acceptance must contain nonblank observable criteria. Significant NFRs need a workload, environment, response measure and provisional target, or a scoped waiver with a reason. Missing or malformed fields remain blockers; passing these presence/shape checks does not prove semantic quality, runtime satisfaction or human approval. Resolve declared local evidence references and preserve their source identity. Use explicit typed dependencies for evidence-to-decision impact; freeform evidence remains attributed data and never creates tool authority. Preserve incomplete drafts and use the smallest workflow the user needs.

## 10. Features to remove

Remove no working capability without evidence of harm or redundancy. Remove the false completeness outcome for blank required content. Do not add automatic activation of all specialist or third-party skills. Keep the historical audit and source snapshot separate from the current release. Stale reference title strings such as `developer-handoff.md` “0.7” should be refreshed when editing documentation, without treating a stale heading as a functional defect.

## 11. Features to add

Add stricter readiness diagnostics and evidence-link integrity to existing components. Add scenario-driven architecture reference packs and measured decision cases, not a standalone skill per language. A high-value test portfolio includes: modular monolith vs extraction, cross-tenant restore, payment retry/idempotency, event ordering and reconciliation, online schema evolution, consumer compatibility, unavailable execution tools, strict budget, contradictory NFRs, unknown workload and unsupported framework version. These are proposed evaluation cases, not tasks run in this audit.

## 12. ChatGPT compatibility assessment

The feasible target remains a host conversation selecting the smallest owner skill, portable project intent and captured implementation identities, optional available authorized tools, structured results and independent validation. Skills supply workflow instructions; the Python toolkit is a user/host-invoked facility, not a background service inside ChatGPT. Native source/API contracts retain their authority for implementation claims. The local project remains architectural intent; it must not override actual source or user/host permissions. Missing execution tools permit static analysis and a clear manual handoff. No automatic cloud sync, universal source index, arbitrary API invocation or tool grant follows from installing a skill.

Maturity applies per capability, with confidence separate:

| Capability | Maturity | Evidence confidence and boundary |
|---|---|---|
| Architecture methodology instructions | 2 — Defined | High that guidance exists; low/unknown that model behavior consistently follows it |
| Canonical validation/contract resolution/export identities | 4 — Validated | High for executed bounded regression corpus; not all possible contracts or adversarial inputs |
| Completeness/readiness | 3 — Repeatable | High that behavior repeats, with ARCH-101 material gap; not broadly validated completeness |
| Typed impact graph | 3 — Repeatable | High for executed typed evidence witness; unsupported/missing links remain incomplete |
| Operational and migration planning | 2 — Defined | High source confidence; no actual deployment/migration/drill by this specialist |
| Architecture reasoning, user value and comparative superiority | Not scored | Insufficient actual behavioral or user evidence; do not turn missing evidence into level 0 quality |

## 13. Relevant plugin integrations

Use the host's actually exposed repository/documentation/runtime tools to inspect exact source, fetch current primary references, run scoped checks and return attributable receipts. No external plugin invocation was exercised by this specialist. The local `.app.json` declares optional GitHub; it is not a universal integration dispatcher or permission grant. Parent-confirmed GitHub access establishes this session's source inspection capability, not downstream users' availability. Security scanners, databases, CI and deployment remain conditional tools or user-mediated workflows. Prefer existing providers over rebuilding them; compare availability, schemas, source freshness, privacy and recovery before adopting. Parent's ecosystem and GitHub research owns candidate-specific recommendations.

## 14. Priority rankings

P1: ARCH-101 before claiming review-ready complete specifications. ARCH-103 before claiming measured reasoning improvement or superiority. P2: ARCH-102 evidence links, then ARCH-104/105 reference/scenario refinements driven by actual tasks. No P0 incident, data loss or exploited vulnerability was established by this architecture review. No arbitrary aggregate quality score is warranted.

## 15. Evidence and confidence

Fresh execution:

| Run | Outcome | Evidence |
|---|---|---|
| System Python contract semantics | 15 test definitions: 14 passed, 1 optional-validator skip | `contract-semantics.log` |
| System Python contract resolution review | 7 passed | `contract-resolution.log` |
| Existing CPython 3.12.14 validation environment, same semantics suite | All 15 passed, no skips | `contract-semantics-optional.log`; this rerun checks previously skipped optional gate, not 15 new independent cases |
| Existing validation environment integrity suite | 10 passed | `integrity.log` |
| Synthetic readiness/evidence probes | ARCH-101 and ARCH-102 reproduced; explicit typed dependency succeeds | `probe.py`, `probe-results.json` |
| Git source identity / status | Frozen expected HEAD; target remains clean after reads/probes | Tool outputs from this specialist; no target write authorized |

There are **32 distinct repository test definitions** across the three suites, all successful in at least one observed environment; one suite was repeated to exercise an installed optional validator. Repeated tests are not additive independent coverage. The probe cases are separate synthetic observations, not model-quality trials.

Historical reconciliation, with exact limits:

| Historical 2026-10-29 expert02 finding | Current assessment |
|---|---|
| Native/embedded contract disagreement | Fixed for retained and new tested cases; shared resolver and current suites exercised |
| Project/revision envelope limit | Fixed for targeted regression; fresh integrity test passed; no power-loss guarantee |
| Known field shape/schema discrepancy | Current Python type regression passed; full Python/JS/schema equivalence not rerun by this specialist |
| Projection identity describes intermediate representation | Fixed for targeted rich export; exact exported-object and byte hashes exercised |
| Change seeds omit nonrequirement/optional classes | Current graph seeds and returns all supported groups by inspection; explicit evidence relationship probe works; compact ADR evidence limitation remains ARCH-102 |
| Native readiness/empty scope | Current native tests and empty-project regression passed; residual blank-content gate gap is ARCH-101 |
| SQLite raw exception boundary | Source now translates SQLite errors (`workflow_tools.py:59–68`); not freshly reproduced here |
| Project identity replacement | Fixed for targeted cross-project regression; fresh integrity test passed |
| No local execution adapter | Implementation now present in source/documentation; end-to-end adapter execution not owned or demonstrated by this specialist |
| Policy/pure contracts/effects mixed | Codec and pure resolver now separated; complete dependency inversion not claimed or required |

Historical evidence is the old expert02 report and `release/implementation-0.9.0.json`; the table intentionally distinguishes inspected changes from executed reproductions.

## 16. Proposed acceptance criteria

1. A02-01 counterexamples become precise review-ready blockers without rejecting their import as drafts; positive and waived cases preserve separate readiness dimensions.
2. A02-02 local evidence ID integrity and dependency witnesses survive export/regeneration and do not retrieve data or grant authority.
3. Supported native/embedded contract semantics retain all current positive and negative tests, including meaningful names/literals and version-specific reference behavior.
4. Handoff hashes continue to identify their named representation, and independent checks never infer runtime, human review or deployment from generated files.
5. An actual architecture reasoning evaluation reports task population, source/skill/tool/model identities, reviewer calibration, critical failures, disagreement, repeat variability and limits. No target such as “best” is accepted without a comparable baseline and measurement.
6. A GitHub reference pack is optional, pinned, license-attributed, scoped to detected versions, mapped to one existing owner, reviewed for tools/authority conflicts and tested on positive, negative and unavailable-tool scenarios before any adoption claim.

## 17. Unresolved questions

- What task population and users define architectural success, and which business/data invariants matter most?
- Which formats have real existing ADR `evidence` fields, and can supported local links be distinguished losslessly from provenance prose/URLs?
- Is `review-ready` intended to enforce only shape/completeness or any additional human review? Current code correctly keeps human review unknown, so product language must preserve that separation.
- Which runtimes/framework versions actually justify maintained reference packs rather than on-demand official documentation?
- Why does the parent-visible installed architecture skill identify v0.7.2 while the current source identifies v0.9.1? This is a release-surface question for parent/plugin inventory, not proof this checkout is wrong.
- Production durability, concurrent hostile writers, architecture reasoning quality, migration safety, current cloud pricing, team adoption and performance remain unmeasured here.

## 18. Final verdict

The architecture is a credible local-first foundation for ChatGPT-assisted software engineering. Keep the modular core and conditional execution boundaries; address the reproduced completeness defect, make evidence links explicit, and measure architecture decisions before adding more breadth. GitHub skills should enrich bounded existing workflows through reviewed reference packs, with pinned provenance and regression evidence. A hosted platform, universal graph system or larger always-active skill library has no demonstrated need in this review.

Independent initial report complete. Cross-examination remains a later phase; no claim of consensus or final adversarial closure is made here.
