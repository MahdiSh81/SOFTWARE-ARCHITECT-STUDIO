import time
from pathlib import Path
gate=Path('/workspace/work/sas-audit-2026-11-01/specialist03/cross-aba/signals')
(gate/'ready').write_text('ready')
def wait_for(name):
 deadline=time.monotonic()+4
 while not (gate/name).exists():
  if time.monotonic()>deadline: raise TimeoutError(name)
  time.sleep(.005)
wait_for('read')
value=Path('value.txt').read_text()
(gate/'observed').write_text(value)
wait_for('finish')
print('observed='+value,flush=True)
assert value=='B', value
