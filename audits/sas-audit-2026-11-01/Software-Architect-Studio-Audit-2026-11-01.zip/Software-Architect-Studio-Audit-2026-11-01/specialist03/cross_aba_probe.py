"""Independent deterministic ABA check-attribution control in disposable scratch."""
import json
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, '/workspace/SOFTWARE-ARCHITECT-STUDIO/tools')
import execution_adapter as a

BASE = Path(__file__).resolve().parent / 'cross-aba'
BASE.mkdir()
root = BASE / 'workspace'; root.mkdir()
state = BASE / 'state'
signals = BASE / 'signals'; signals.mkdir()
(root / 'value.txt').write_text('A')
check = '''import time
from pathlib import Path
gate=Path(SIGNAL)
(gate/'ready').write_text('ready')
def wait_for(name):
 deadline=time.monotonic()+4
 while not (gate/name).exists():
  if time.monotonic()>deadline: raise TimeoutError(name)
  time.sleep(.005)
wait_for('read')
value=Path('value.txt').read_text()
(gate/'observed').write_text(value)
wait_for('finish')
print('observed='+value,flush=True)
assert value=='B', value
'''.replace('SIGNAL', repr(str(signals)))
(root / 'check.py').write_text(check)
policy={'schema_version':1,'root':str(root),'authorization_reference':'independent-cross-audit',
 'allow_write':True,'allowed_paths':['value.txt'],'allow_checks':True,'include_output':True,
 'checks':{'read-value':{'argv':[sys.executable,'-B','check.py'],'timeout_seconds':5}}}
identity=a.inspect(root)['source_hash']
for name in ['read','finish']: (signals/name).touch()
control=a.run_checks(root,['read-value'],policy,expected_source_hash=identity,operation_id='control',state_root=state)
for item in signals.iterdir(): item.unlink()
(BASE/'config.json').write_text(json.dumps({'root':str(root),'state':str(state),'policy':policy,'identity':identity}))
runner='''import json,sys
from pathlib import Path
sys.path.insert(0,'/workspace/SOFTWARE-ARCHITECT-STUDIO/tools')
import execution_adapter as a
base=Path(sys.argv[1]); c=json.loads((base/'config.json').read_text())
r=a.run_checks(c['root'],['read-value'],c['policy'],expected_source_hash=c['identity'],operation_id='overlap',state_root=c['state'])
(base/'receipt.json').write_text(json.dumps(r))
'''
proc=subprocess.Popen([sys.executable,'-B','-c',runner,str(BASE)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
def wait_signal(name):
    deadline=time.monotonic()+4
    while not (signals/name).exists():
        if time.monotonic()>deadline: raise TimeoutError(name)
        time.sleep(.005)
wait_signal('ready')
plan=a.propose_change(root,[{'path':'value.txt','content':'B'}],expected_source_hash=identity)
apply_b=a.apply_change(root,plan,policy,operation_id='to-b',state_root=state)
(signals/'read').touch()
wait_signal('observed')
observed=(signals/'observed').read_text()
plan=a.propose_change(root,[{'path':'value.txt','content':'A'}],expected_source_hash=a.inspect(root)['source_hash'])
apply_a=a.apply_change(root,plan,policy,operation_id='to-a',state_root=state)
(signals/'finish').touch()
stdout,stderr=proc.communicate(timeout=6)
receipt=json.loads((BASE/'receipt.json').read_text())
reconcile=a.reconcile(root,receipt,expected_operation='overlap',expected_source_hash=identity,required_checks=['read-value'],state_root=state)
result={'control':control,'apply_b':apply_b,'apply_a':apply_a,'observed_during_check':observed,'receipt':receipt,'reconcile':reconcile,
 'source_hash_start_equals_end':identity==a.inspect(root)['source_hash'],'runner_returncode':proc.returncode,'runner_stdout':stdout,'runner_stderr':stderr}
(BASE/'results.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'control':control['status'],'apply_b':apply_b['status'],'apply_a':apply_a['status'],'observed':observed,'check':receipt['status'],'reconcile':reconcile['status'],'source_hash_start_equals_end':result['source_hash_start_equals_end']},indent=2))
