import json
import os
import platform
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, '/workspace/SOFTWARE-ARCHITECT-STUDIO/tools')
import execution_adapter as adapter

BASE = Path(__file__).resolve().parent
root = BASE / 'toy-app'
root.mkdir(exist_ok=True)
state = BASE / 'toy-state'
policy = {
    'schema_version': 1, 'root': str(root), 'authorization_reference': 'audit-disposable-toy',
    'allow_write': True, 'allowed_paths': ['price.py', 'app.py', 'test_price.py'],
    'allow_checks': True, 'include_output': True,
    'checks': {
        'unit': {'argv': [sys.executable, '-B', '-m', 'unittest', 'discover'], 'kind': 'test', 'minimum_tests': 5, 'timeout_seconds': 10},
        'runtime': {'argv': [sys.executable, '-B', 'app.py', '10', '20'], 'timeout_seconds': 10},
    },
}
changes = [
    {'path': 'price.py', 'content': 'def total(values):\n    if not values or any(v < 0 for v in values):\n        raise ValueError("positive basket required")\n    return round(sum(values), 2)\n'},
    {'path': 'app.py', 'content': 'import sys\nfrom price import total\nif __name__ == "__main__":\n    print(f"{total([float(v) for v in sys.argv[1:]]):.2f}")\n'},
    {'path': 'test_price.py', 'content': 'import unittest\nfrom price import total\nclass PriceTest(unittest.TestCase):\n def test_two(self): self.assertEqual(total([10, 20]), 30)\n def test_round(self): self.assertEqual(total([1.112, 2.222]), 3.33)\n def test_zero(self): self.assertEqual(total([0]), 0)\n def test_negative(self):\n  with self.assertRaises(ValueError): total([-1])\n def test_empty(self):\n  with self.assertRaises(ValueError): total([])\n'},
]
before = adapter.inspect(root)
plan = adapter.propose_change(root, changes, before['source_hash'])
applied = adapter.apply_change(root, plan, policy, operation_id='create-toy', state_root=state)
current = adapter.inspect(root)
checks = adapter.run_checks(root, ['unit', 'runtime'], policy, expected_source_hash=current['source_hash'], operation_id='verify-toy', state_root=state)
reconciled = adapter.reconcile(root, checks, expected_operation='verify-toy', expected_source_hash=current['source_hash'], required_checks=['unit', 'runtime'], state_root=state)

mode_root = BASE / 'mode-app'
mode_root.mkdir(exist_ok=True)
executable = mode_root / 'entry.sh'
executable.write_text('#!/bin/sh\nprintf before\n')
executable.chmod(0o755)
identity_executable = adapter.inspect(mode_root)
executable.chmod(0o644)
identity_noexecute = adapter.inspect(mode_root)
executable.chmod(0o755)
mode_plan = adapter.propose_change(mode_root, [{'path': 'entry.sh', 'content': '#!/bin/sh\nprintf after\n'}])
mode_receipt = adapter.apply_change(mode_root, mode_plan, {'schema_version': 1, 'root': str(mode_root), 'authorization_reference': 'audit-executable-edit', 'allow_write': True, 'allowed_paths': ['entry.sh']}, operation_id='mode-edit', state_root=BASE / 'mode-state')
try:
    ran = subprocess.run([str(executable)], check=False, text=True, capture_output=True)
    direct = {'returncode': ran.returncode, 'stdout': ran.stdout}
except OSError as exc:
    direct = {'exception': type(exc).__name__, 'errno': exc.errno}

result = {
    'runtime': {'python': sys.version, 'platform': platform.platform()},
    'toy': {'apply': applied, 'checks': checks, 'reconcile': reconciled, 'authorship': 'audit assistant supplied source; adapter applied and checked, no model generation evaluation'},
    'mode': {'before': '0755', 'after': oct(executable.stat().st_mode & 0o777), 'chmod_changes_source_hash': identity_executable['source_hash'] != identity_noexecute['source_hash'], 'apply': mode_receipt, 'direct_execution_after_edit': direct},
}
(BASE / 'probe-results.json').write_text(json.dumps(result, indent=2))
print(json.dumps({'toy_apply': applied['status'], 'toy_checks': checks['status'], 'toy_reconcile': reconciled['status'], 'mode_after': result['mode']['after'], 'mode_in_source_identity': result['mode']['chmod_changes_source_hash'], 'direct_execution_after_edit': direct}, indent=2))
