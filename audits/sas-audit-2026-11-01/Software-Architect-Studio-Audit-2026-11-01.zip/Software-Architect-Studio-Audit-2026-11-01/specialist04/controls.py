import json, os, subprocess,sys
from pathlib import Path
sys.path.insert(0,'/workspace/SOFTWARE-ARCHITECT-STUDIO/tools')
from repository_evidence import repo_scan, fitness
from project_model import new_project
from workflow_tools import freshness
root=Path('/workspace/work/sas-audit-2026-11-01/specialist04')
base=root/'boundaries';base.mkdir(exist_ok=True)
(base/'a.py').write_text('import allowed\n')
(base/'outside.py').write_text('import forbidden\n')
if not (base/'alias.py').exists():(base/'alias.py').symlink_to(base/'outside.py')
if not (base/'special.py').exists():os.mkfifo(base/'special.py')
scan=repo_scan(base,max_entries=50)
bounded=repo_scan(base,max_entries=1)
p=new_project('rules');p['fitness_rules']=[{'id':'RULE-001','kind':'forbid_import','source_prefix':'a.py','target_prefix':'forbidden'}]
p['evidence']=[{'id':'EV-001','path':'missing.py','sha256':'a'*64}]
result={'omissions':scan['omissions'],'safe_scope_fitness':fitness(p,scan),'bounded':{k:bounded[k] for k in ('enumeration_complete','total_candidate_files','stop_reasons','entries_visited')},'absent_freshness':freshness(p,scan)}
cli=subprocess.run([sys.executable,'/workspace/SOFTWARE-ARCHITECT-STUDIO/tools/architect_cli.py','repo-scan',str(root/'malformed-pyproject')],capture_output=True,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
result['malformed_cli']={'exit':cli.returncode,'stdout':cli.stdout,'stderr':cli.stderr}
(root/'controls.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
