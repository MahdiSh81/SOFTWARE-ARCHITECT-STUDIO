import copy,json,sys
from pathlib import Path
sys.path.insert(0,'/workspace/SOFTWARE-ARCHITECT-STUDIO/tools')
from evaluation_records import capture_identity,summarize_captures
from project_model import new_project,project_checks
from artifact_compiler import readiness
from graph_engine import impacts_from_seeds
c={'id':'independent-cross-missing-capture'}
reviews=[]
for who in ['reviewer04A','reviewer04B']:
 reviews.append({'reviewer_id':who,'capture_id':c['id'],'source_hash':capture_identity(c),'reviewed_at':'2026-11-01T18:00:00+03:30','rubric_version':1,'scores':dict.fromkeys(('correctness','evidence','risk_handling','constraint_adherence','usefulness'),3),'critical_failures':[],'evidence_refs':['synthetic:cross-probe'],'calibrated':True,'calibration_reference':'synthetic:test','conclusion':'Synthetic accounting fixture only.'})
c['reviews']=reviews
out={'absent_capture':summarize_captures([c])}
broken=copy.deepcopy(c);broken['reviews'][0]['source_hash']='a'*64
try:out['wrong_hash_control']=summarize_captures([broken])
except ValueError as e:out['wrong_hash_control']={'rejected':True,'message':str(e)}
empty=copy.deepcopy(c);empty['reviews']=[];out['unreviewed_control']=summarize_captures([empty])
p=new_project('Independent cross-probe');p['requirements']=[{'id':'NFR-001','description':'Latency scenario','acceptance':'  ','scenario':'  '}];p['tasks']=[{'id':'TASK-001','requirements':['NFR-001'],'acceptance':'  '}]
out['blank_readiness']={'diagnostics':project_checks(p),'readiness':readiness(p,'review-ready')}
p['evidence']=[{'id':'EVD-001','path':'a.py','sha256':'a'*64}];p['decisions']=[{'id':'ADR-001','evidence':['EVD-404']}]
out['opaque_missing_evidence']=project_checks(p)
p['relationships']=[{'id':'REL-001','kind':'depends_on','from':{'group':'decisions','id':'ADR-001'},'to':{'group':'evidence','id':'EVD-404'}}]
out['typed_missing_evidence']=project_checks(p)
p['relationships'][0]['to']['id']='EVD-001'
out['valid_typed_evidence_impact']=impacts_from_seeds(p,[{'group':'evidence','id':'EVD-001'}])['affected']['decisions']
Path(__file__).with_name('cross-probe-results.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'malformed_green':out['absent_capture']['semantic_gate_passed'],'wrong_hash_rejected':out['wrong_hash_control'].get('rejected'),'unreviewed_green':out['unreviewed_control']['semantic_gate_passed'],'blank_readiness_green':out['blank_readiness']['readiness']['profile_satisfied'],'human_review':out['blank_readiness']['readiness']['dimensions']['human_review'],'runtime':out['blank_readiness']['readiness']['dimensions']['runtime_verification'],'opaque_missing_diagnostics':out['opaque_missing_evidence'],'typed_missing_diagnostics':out['typed_missing_evidence'],'valid_typed_adr_count':len(out['valid_typed_evidence_impact'])},indent=2))
