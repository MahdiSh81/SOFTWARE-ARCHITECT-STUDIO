import json, sys, subprocess
from pathlib import Path
sys.path.insert(0, '/workspace/SOFTWARE-ARCHITECT-STUDIO/tools')
from repository_evidence import repo_scan, fitness
from project_model import new_project
root = Path('/workspace/work/sas-audit-2026-11-01/specialist04')
results=[]
def rule():
    p=new_project('Probe');p['fitness_rules']=[{'id':'RULE-001','kind':'forbid_import','source_prefix':'','target_prefix':'forbidden'}];return p
for key, files in [
 ('simple-import', {'a.mjs':'import { thing } from "forbidden";\n'}),
 ('long-static-import', {'a.js':'import {\n'+''.join('  item'+str(i)+',\n' for i in range(12))+'} from "forbidden";\n'}),
 ('many-token-static-import', {'a.js':'import { '+', '.join('item'+str(i) for i in range(90))+' } from "forbidden";\n'}),
 ('regex-not-import', {'a.js':'const pattern = /import "forbidden"/;\n'}),
 ('malformed-pyproject', {'pyproject.toml':'project = []\n'}),
 ('malformed-pyproject-string', {'pyproject.toml':'project = "x"\n'}),
 ('valid-control', {'a.js':'import { thing } from "forbidden";\n'}),
]:
    base=root/key;base.mkdir(exist_ok=True)
    for path,text in files.items():(base/path).write_text(text)
    item={'name':key}
    for path in files:
      if path.endswith('.js'):
        checked=subprocess.run(['node','--input-type=module','--check'],input=files[path],text=True,capture_output=True)
        item['node_syntax_exit']=checked.returncode
    try:
      scan=repo_scan(base)
      item.update(coverage=scan['coverage'], omissions=scan['omissions'], edges=scan['dependency_edges'],observations=scan['observed_files'], fitness=fitness(rule(),scan))
    except Exception as e:item['exception']={'class':type(e).__name__,'message':str(e)}
    results.append(item)
(root/'probe.json').write_text(json.dumps(results,indent=2))
print(json.dumps([{k:v for k,v in x.items() if k not in ('observations','fitness')}|({'fitness_status':x['fitness']['rules'][0]['status']} if 'fitness'in x else {}) for x in results],indent=2))
