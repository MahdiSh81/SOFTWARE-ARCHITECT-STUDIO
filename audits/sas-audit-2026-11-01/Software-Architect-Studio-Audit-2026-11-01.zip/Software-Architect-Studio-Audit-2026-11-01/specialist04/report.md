# Specialist 04 — Repository Intelligence and Codebase Analysis

Independent first-pass report, 2026-11-01. Investigator instance: `/root/specialist04_repository`. Source baseline: `MahdiSh81/SOFTWARE-ARCHITECT-STUDIO`, commit `1fa377cc9cbe7054d7edbf8091e22efaa296c05e`, local mirror `/workspace/SOFTWARE-ARCHITECT-STUDIO`. No other new specialist reports were read before this report. The target remained unchanged; fixtures, logs and reports are separate under `/workspace/work/sas-audit-2026-11-01/specialist04`.

## 1. Executive assessment

The repository subsystem is a useful, candidly bounded source-evidence collector with substantial regression coverage. It is not a semantic codebase index or runtime architecture reconstruction engine. Fresh tests confirm important earlier fixes: unsupported/failed extraction cannot prove clean fitness, cache use cannot prove a clean result, relative imports retain syntax, descriptor quotas remain visible, and nonrequirement changes seed typed impact traversal.

Three current defects remain. A valid long JavaScript static import can be silently omitted while fitness reports `satisfied-in-scope`; JavaScript regular-expression contents can be falsely reported as imports; and a malformed nested `pyproject.toml` structure aborts the whole collection rather than becoming a per-file diagnostic. The first defect merits P1 because it creates false clean evidence in the very boundary intended to prevent false assurance. Broad scanner expansion should wait until this boundary is repaired.

## 2. Scope inspected

Current source: `tools/repository_evidence.py`, `tools/safe_io.py`, `tools/graph_engine.py`, the freshness/migration functions in `tools/workflow_tools.py`, relevant CLI routing/error handling, `schemas/evidence-v1.schema.json`, the repository skill and its GitHub evidence reference, and relevant tests. Historical reconciliation was limited to repository findings in `audits/sas-audit-2026-10-29/findings.csv`, `release/implementation-0.9.0.json`, and implementation-status statements. These historical records were consulted after current source and fresh probes.

Covered mechanisms: file/line/hash mapping; traversal and collection budgets; Python import/route candidates; JS/TS static tokens; JSON/YAML/TOML/requirements descriptors; omissions; cache trust; fitness; evidence deltas; freshness; drift candidates; typed impact closure. Not covered: provider authentication, live GitHub connection behavior, every language parser, actual deployment topology, full program semantics or live-model architectural reasoning.

## 3. Methodology

1. Inspect actual contracts and implementation with line-numbered source.
2. Run the existing repository-integrity suite with `PYTHONDONTWRITEBYTECODE=1`.
3. Build discriminating positive/negative fixtures outside the target. Confirm valid JS syntax with Node's module syntax checker without executing repository code.
4. Scan the actual target with default read-only CLI settings and record coverage.
5. Exercise symlink, FIFO, entry-budget and missing-evidence boundaries in scratch.
6. Reconcile historical fixes without inheriting their success claims.

Artifacts: `probe.py`, `probe.json`, `controls.py`, `controls.json`, `repository-tests.log`, `target-scan.json`. The 16 existing repository-integrity tests passed freshly in 0.053 seconds. These tests did not include the new counterexamples. Node syntax checking confirms grammar acceptance, not dependency resolution or runtime behavior.

## 4. Verified strengths

| Capability | Capability classification | Evidence status | Evidence |
|---|---|---|---|
| Bounded local scanning, regular-file reads, source hashes, explicit omissions | Verified tool-based | Successfully executed | `repository_evidence.py:198–313`; `target-scan.json`; `controls.json` |
| Symlinks/FIFOs omitted without opening inspected code | Verified tool-based | Successfully executed | `repository_evidence.py:225–236`; `safe_io.py:43–60`; controls |
| Unknown unseen totals on interrupted enumeration | Verified tool-based | Successfully executed | `repository_evidence.py:220–221,313`; entry-budget control |
| Typed descriptor failures/quota diagnostics for covered fixtures | Verified tool-based | Successfully executed | `repository_evidence.py:179–195`; 16-test suite |
| Cache diagnostics preserved; untrusted cache cannot establish clean fitness | Verified tool-based | Successfully executed | `repository_evidence.py:275–287,385–390`; tests44–51 |
| Relative-import syntax retained without guessing root resolution | Verified tool-based | Successfully executed | `repository_evidence.py:42–50`; tests77–84 |
| Delta scope checks and unread/deleted distinction | Verified tool-based | Successfully executed | `repository_evidence.py:339–370`; tests103–113 |
| Typed impact seeds/witnesses, including optional records and relationship endpoints | Verified tool-based | Successfully executed | `graph_engine.py:22–51,75–92`; tests115–125,156–163 |
| Freshness absence remains unknown rather than deletion | Verified tool-based | Successfully executed | `workflow_tools.py:9–15`; missing-evidence control |
| Source trust/pinning/nonexecution guidance | Instruction-only | Directly inspected | `skills/repository-intelligence/SKILL.md:8–15`; `references/github-review.md:3–9` |

Default target scan observed 250 eligible files, read 2,079,965 bytes, visited 526 entries and enumerated 429 regular/special file entries. It recorded 207 omissions and `coverage: partial`, with no budget stop. Its own source ref remains explicitly unpinned. These counts describe this invocation, not semantic completeness or an immutable snapshot captured atomically.

## 5. Verified defects

### REPO-101 — Valid long static JS imports can produce false clean fitness — P1

**Evidence:** `repository_evidence.py:74` restricts lookahead to 79 following tokens; `:87` stops after eight lines. Neither limit emits an omission or changes extraction from `tokenized`. Fitness accepts fresh `tokenized` JS as evaluated evidence (`:385–390`). In `probe.json`, both a twelve-line named import from `forbidden` and a ninety-name single-line import from `forbidden` pass Node syntax checking with exit0. Scanner emits no edges, no omissions, `complete within supported static scope`, then fitness returns `satisfied-in-scope`. A short import positive control correctly yields `violation`.

**Classification:** Verified tool-based. **Evidence status:** Successfully executed. **Confidence:** High for the fixtures; impact across all JS grammar is unmeasured.

**Intended outcome:** No supported valid static import may disappear into clean evidence because of a hidden lexical limit. Until grammar support can establish complete static-import extraction, JS token evidence must not substantiate a clean fitness gate.

**Minimal design:** Immediately treat JS/TS lexical extraction as incomplete for clean fitness, or emit `partial` plus exact `lookahead/line/unsupported syntax` diagnostics when the scanner encounters an uncompleted import/export declaration. A grammar-aware, version-pinned optional JS adapter can later establish a specifically declared supported grammar. Keep lexical output as attributed review candidates. Avoid a universal semantic graph project.

**Acceptance:** Short, >8-line and >80-token valid imports either yield exact path/span/hash edges or return unknown with explicit omission. None returns clean. Malformed syntax does not return clean. Positive/negative fixtures retain exact target and line. Required fitness gates refuse unknown.

### REPO-102 — JS regex literals create false dependency observations — P2

**Evidence:** The token expression handles comments, strings and templates but not regex literals (`repository_evidence.py:61–69`). `const pattern = /import "forbidden"/;` passes Node syntax checking, has no module import, but scanner emits an import edge and fitness returns `violation` in `probe.json`. `:71–94` treats words inside the regex as module syntax.

**Classification:** Verified tool-based. **Evidence status:** Successfully executed. **Confidence:** High for the counterexample.

**Intended outcome:** Exact dependency violations must be based on actual import declarations. Ambiguous lexemes are candidates, not confirmed dependencies.

**Design:** Share REPO-101's parser boundary; do not patch only this regex spelling. Either use a constrained parser with documented grammar or downgrade uncertain token evidence before asserting violation. Add regex, division, comments, quoted strings, templates, JSX and TypeScript syntax negatives as relevant to declared support.

**Acceptance:** Regex fixture emits zero confirmed import edges and cannot yield a confirmed violation. Actual import positive control still yields the correct edge. Unsupported grammar is explicitly unknown, not clean or confirmed violation.

### REPO-103 — Malformed nested TOML structure aborts collection — P2

**Evidence:** `data.get('project', {}).get('dependencies', [])` at `repository_evidence.py:135` assumes `project` is a dict. Syntactically valid TOML `project = []` or `project = "x"` causes AttributeError; `_extract` does not catch AttributeError (`:185`). The entire `repo_scan` call aborts. The CLI correctly catches that error and returns structured error/exit2 (`architect_cli.py:152–157`), so this is not an unhandled CLI traceback. See `probe.json` and `controls.json`.

**Classification:** Verified tool-based. **Evidence status:** Successfully executed. **Confidence:** High.

**Intended outcome:** A malformed supported file is a per-file `parse_failed` observation and omission while other readable files retain collected evidence. Invalid root/authority should still fail the operation.

**Design:** Validate each nested descriptor's required object/list type before accessing it and convert expected descriptor-shape failures to typed parser diagnostics. Do not suppress arbitrary programming exceptions with a blanket broad catch. Preserve healthy-file observations and mark overall scope partial.

**Acceptance:** Arrays, strings, numbers, booleans and missing nested project tables are handled with deliberate semantics. Invalid shapes emit typed per-file failure; a neighboring healthy Python source still appears. CLI emits the resulting evidence envelope instead of discarding the collection.

## 6. Missing capabilities

| Capability | Classification | Evidence/implication |
|---|---|---|
| Automatic immutable Git commit plus dirty overlay in repo-scan output | Proposed | Scanner intentionally reports unpinned source (`repository_evidence.py:286,313`); caller must pin separately. Add optional read-only identity collection and a post-read consistency check only when actual Git is available. |
| Full call graph, runtime dataflow, framework binding, deployed topology | Unsupported | No general implementation path demonstrated by this scanner. Python route decorators are candidates (`:51–55`), not framework proof. |
| Go/Rust/Java/C#/SQL semantic extraction | Tool-dependent | Extensions can be identified/read but lack source adapters (`:22,167–181`). Demand-backed optional host parsers may supply evidence. |
| `.mjs` and `.cjs` module coverage | Proposed | `.mjs` fixture is honestly omitted as unsupported. Extend only after parser correctness; do not market language-wide completeness. |
| Business-aware modernization and architecture drift | User-mediated | Component/file existence candidates (`:314–331`) and migration worksheets (`workflow_tools.py:17–26`) require engineering review. |
| Atomic snapshot of a concurrently changing repository | Unknown | Per-file identities are real; collection is not an atomic whole-tree snapshot. No stable-tree/concurrent-change guarantee verified. |

## 7. Risks

The most material risk is evidence overstatement through JS fitness, not the absence of more languages. Source hashes establish captured bytes, not truth or authorship. An editable cache can inject candidate violations; it is explicitly untrusted and must be recollected for a release decision. Pattern redaction is incomplete. External source must remain non-authoritative. Cooperative parsing deadlines are not hard process-level wall-clock limits (`repository_evidence.py:313`); the host must supply stronger resource isolation when needed. Existing omissions can be unrelated to a narrow rule, so a global partial scan does not necessarily invalidate a correctly bounded source-prefix result. Do not collapse these scopes.

## 8. Redundant functionality

The scanner, typed project graph and GitHub connector are complementary, not interchangeable. Scanner extracts local observations; graph traverses declared project relationships; connector accesses remote source under host permissions. No verified reason to merge them into one universal engine. Duplicate caveats across the coordinator and repository reference could be consolidated into one evidence contract, while keeping short essential warnings at point of use.

## 9. Recommended improvements

1. **P1 / REPO-101:** close the JS false-clean boundary before expanding language coverage.
2. **P2 / REPO-102:** distinguish parsed import declarations from lexical candidates; add a discriminating grammar corpus.
3. **P2 / REPO-103:** validate nested descriptor shapes and retain partial evidence after per-file failures.
4. **P2 proposal:** expose source identity as resolved commit + dirty overlay + capture consistency, or explicitly unpinned. Keep access optional; never infer a Git SHA from a branch label.
5. **P3 proposal:** demand-backed `.mjs/.cjs`, lockfile and non-Python language adapters, each with explicit grammar, version, quotas, provenance and fixtures.
6. Keep old parser/cache/impact regressions and add these exact counterexamples. Do not replace them with implementation-mirroring assertions.

## 10. Features to remove

Remove no proven scanner/graph feature. Remove the ability for incomplete JS lexical extraction to substantiate a clean rule. Remove any presentation that treats a source map as runtime topology or a hash as approval. Defer universal call/dataflow/semantic indexing until a scoped user task and measurable benefit justify it.

## 11. Features to add

Add a compact per-adapter support contract: adapter/version, grammar, recognized declaration forms, known unresolved forms, completeness predicate, extraction diagnostics and verification class. Add corpus fixtures from actual syntax, including long declarations and noncode literals. Add optional stable Git identity only as host-supported read-only collection. These additions fit the existing evidence envelope; a new service is unnecessary.

## 12. ChatGPT compatibility assessment

The repository skill is a valid ChatGPT-native instruction workflow. Local scanner execution is **Verified tool-based in this session**, conditional on the actual terminal/filesystem supplied by this host; it is not a universal plugin-native capability. When local tools are absent, use exposed permissioned GitHub reads or a user-supplied source archive and label coverage. No direct plugin-to-plugin invocation is established by the optional GitHub declaration alone. Persist context through actual files, storage or a user-mediated handoff; never imply invisible durable chat state.

Maturity: bounded source collection **Level4 Validated**, confidence high within tested scope; JS import correctness/fitness **Level2 Defined**, confidence high that gaps exist; typed impact/delta **Level4 Validated**, confidence medium across untested project graphs; semantic/runtime repository intelligence **Level0 Absent** as a universal scanner capability, confidence high; source-to-requirement interpretation **Level2 Defined**, confidence medium because the workflow is specified but no live-model benchmark was run.

## 13. Relevant plugin integrations

Use the actual GitHub host connector for authorized source/ref reads; this agent did not invoke it. The parent verified the remote baseline separately. For future syntax/semantic support, use a selected authorized execution host with an installed parser and explicit resource policy, or accept user-produced parser artifacts with attributed provenance. Security scanners and official documentation can be used alongside via explicit supported host tools. A marketplace listing or copied GitHub skill does not grant execution authority. Incorporate external repository-review skills only after licensing, pinning, trigger-conflict review and a small negative/positive corpus; do not auto-execute downloaded skill scripts.

## 14. Priority rankings

| Rank | Item | User/engineering impact | Feasibility | Effort estimate | Dependency/maintenance risk |
|---|---|---|---|---|---|
| 1 | REPO-101 conservative JS fitness boundary | High: avoids false assurance | High | Small, 0.5–1 day for conservative boundary and tests | Low if no new parser; optional parser separate |
| 2 | REPO-103 nested descriptor validation | Medium: preserves useful scan evidence | High | Small, 0.5 day with shape fixtures | Low |
| 3 | REPO-102 parser/candidate distinction | Medium: avoids false violations | High for conservative downgrade | Small–medium; parser support 1–3 days for declared scope | Parser/version maintenance |
| 4 | Optional stable source identity | Medium: reproducible review | Conditional host Git | Medium, 1–2 days incl. dirty/concurrency fixtures | Git/worktree/submodule cases |
| 5 | More language adapters | Unknown until demand | Conditional parser availability | Estimate after task/corpus | High if broad |

These are rough engineering estimates, not measured schedules or arbitrary quality scores. All changes remain proposals.

## 15. Evidence and confidence

Immutable source base: `https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/`.

Core decisive references: `tools/repository_evidence.py#L59`, `#L74`, `#L87`, `#L134`, `#L185`, `#L198`, `#L335`, `#L373`; `tools/graph_engine.py#L22`, `#L75`; `tools/safe_io.py#L43`; `tools/workflow_tools.py#L9`; `tests/test_repository_integrity.py#L21`; repository skill `#L8`.

Historical reconciliation: previous REPO-002/003/004/006/007/008/010 and SEC-005 fixes are supported by fresh passing named regressions. Historical REPO-005 is **partially fixed**: invalid JSON is typed but malformed nested TOML can still abort. Previous REPO-007's preceding-export fixture is fixed; current regex and long-import counterexamples reveal additional current lexical gaps, rather than proving the exact historical fix regressed. REPO-009 is scoped: cooperative deadline limitation is candid, cache write failure retains evidence under its regression. REPO-011 remains a declared capability boundary, not a defect to manufacture.

## 16. Proposed acceptance criteria

- `AC-R101`: valid short, multiline (>8 lines) and long (>80 tokens) static imports yield exact supported edges or explicit unknown; never a false clean result.
- `AC-R102`: regex/comment/string/template negatives do not become confirmed imports; actual import controls still do. Grammar outside declared support reports unknown.
- `AC-R103`: nested malformed descriptor types emit per-file parse failure and retain a healthy neighbor's evidence; no whole-scan loss.
- `AC-R104`: parser/cache version change invalidates extraction reuse; warm cache cannot establish fresh clean fitness; existing diagnostics parity remains.
- `AC-R105`: source output declares immutable commit/dirty identity when actually captured; otherwise explicitly unpinned. Mid-capture changes must be detected or disclosed as non-atomic.
- `AC-R106`: scanner/impact/semantic claims remain separate; each material claim has source identity, scope and a verification class. Required gates cannot turn unknown/skipped into pass.

Validation should be a fresh corpus run plus existing 16-test suite, source inventory check and selected CLI integration checks. No live-model benchmark improvement follows from these deterministic checks alone.

## 17. Unresolved questions

Which languages and module forms dominate actual user projects? Is the desired source identity the working tree, committed tree or a user-supplied archive? What does the host guarantee about a stable capture? Are parser dependencies already available in the intended ChatGPT execution environments? Who reviews candidate violations before release decisions? No evidence of actual user demand, production runtime topology, scanner latency on representative large repositories, or model-level architecture quality was collected here.

## 18. Final verdict

Retain and improve the bounded repository workflow. Its evidence discipline and verified historical fixes provide a sound base, but the current JS token adapter must not substantiate clean fitness until it can prove the supported scope was actually extracted. Fix descriptor failure containment, preserve partial/unknown distinctions, and expand languages only against actual demand. Repository intelligence should remain a source-backed engineering aid inside ChatGPT, with host execution optional and semantic/runtime certainty earned separately.
