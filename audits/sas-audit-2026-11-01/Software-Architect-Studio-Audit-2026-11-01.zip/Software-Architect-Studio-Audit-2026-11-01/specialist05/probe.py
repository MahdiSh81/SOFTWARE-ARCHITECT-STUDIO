import json,sys,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'source/tools'))
from artifact_compiler import handoff,resolve_generation
from validation_engine import validate,openapi_checks
from codec import dumps
from project_model import project_checks
base=Path(__file__).parent; root=base/'probe-project'; root.mkdir(exist_ok=True)
p=json.loads((base/'source/tests/fixtures/rich-project.json').read_text());(root/'project.json').write_text(dumps(p))
out=base/'probe-handoff'; result=handoff(root,out); gen=resolve_generation(out)
summary={'manifest_listed_api': 'api.json' in json.loads((gen/'generation-manifest.json').read_text())['files'], 'baseline':validate(out,gate='structural')}
(gen/'api.json').unlink(); summary['missing_api']=validate(out,gate='structural')
(gen/'architecture.md').write_text('# Replaced architecture\nTHIS DOES NOT MATCH THE SOURCE\n'); summary['tampered_markdown']=validate(out,gate='structural')
# Independent parser / malformed-schema probes, not model task benchmarks.
summary['malformed_project_checks']={}
for label,x in [('null',None),('list',[]),('bad_requirements',{**p,'requirements':'wrong'}),('bad_refs',{**p,'verifications':[{'id':'V-1','requirements':'FR-001'}]}),('bad_nested',{**p,'components':[None]})]:
 try: summary['malformed_project_checks'][label]={'outcome':'returned','errors':project_checks(x)}
 except Exception as e:summary['malformed_project_checks'][label]={'outcome':'exception','type':type(e).__name__}
# Full gate applied to an AsyncAPI envelope.
asyncp=base/'asyncapi.json'; asyncp.write_text(json.dumps({'asyncapi':'bogus','info':{},'channels':{}}));summary['asyncapi_full']=validate(asyncp,gate='full')
(base/'probes.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:{'policy_ok':v.get('policy_ok'),'ok':v.get('ok'),'checks':[(c['check'],c['status']) for c in v['checks']]} if isinstance(v,dict) and 'checks' in v else v for k,v in summary.items()},indent=2))
