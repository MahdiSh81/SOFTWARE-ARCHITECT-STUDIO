# Specialist 05 — Principal Quality Assurance Engineer

Independent first pass, 2026-11-01. Source: SOFTWARE-ARCHITECT-STUDIO commit `1fa377cc9cbe7054d7edbf8091e22efaa296c05e`, version 0.9.1. No new specialist conclusions were read before this report. Target repository unchanged; test execution used a separate copy. This report evaluates the local toolkit and inspected workflow instructions, not an independently measured ChatGPT model.

## 1. Executive assessment

The current package has a substantial, reproducible regression suite with honest structural/semantic boundaries. Fresh execution passed **193 Python tests with zero skips and 37 Node workbench checks**, and its 116-file scoped source inventory matched. This supersedes the brief's historical 67/14 claim for the inspected commit; it does not prove live model quality, runtime correctness of generated applications, or UI behavior in a real browser.

Two fresh counterexamples expose gaps outside the current regression fixtures: generated handoff validation ignores manifest completeness/hashes, and the `full` gate can return green for an invalid AsyncAPI version using only an envelope check. Correct these before broadening verification claims. Actual browser execution was blocked by this host's socket policy before any case ran. The package's nine browser cases and CI job exist, but no fresh browser pass was obtained here.

Maturity: local regression process **4 — Validated**, high confidence within the tested Linux/Python/Node scope; live semantic engineering quality **2 — Defined**, medium confidence from inspected instruments, unmeasured outcomes. Do not aggregate those into a global product grade.

## 2. Scope inspected

Inspected `tools/validation_engine.py`, `validator_worker.py`, `behavioral_eval.py`, `evaluation_records.py`, `check_release.py`, `artifact_compiler.py`, CLI argument/gate routing, tests across all 16 Python modules, `tests/test_workbench.cjs`, all nine `tests/browser/workbench.spec.cjs` cases, browser configuration/server, CI workflow, optional validator versions, source inventory, rich/conformance fixtures, lexical cases and semantic rubric. Specialist workflow instructions were read for verification boundaries. No production deployment, external security scan, model API or external account was invoked.

## 3. Methodology

1. Freeze commit and hash source files; copy to isolated scratch excluding `.git`, historical audits, generated dependencies and results.
2. Run documented suites using installed Python 3.12.14 environment, optional PyYAML 6.0.3/jsonschema 4.23.0/openapi-spec-validator 0.7.2, and Node v24.19.0. No dependencies installed.
3. Run source inventory and release checker; record that release checker repeats the same unique suites.
4. Attempt browser suite with installed Playwright and `/usr/bin/chromium`; record host denial separately.
5. Construct counterexamples independently of implementation tests: remove a manifest-listed generated API file, alter generated Markdown, submit five malformed project shapes, submit an invalid AsyncAPI version to `full`.
6. Verify original target hashes unchanged. Exact commands/results are in `verification-ledger.json`; probes are reproducible with `probe.py` and `probes.json`.

## 4. Verified strengths

| Strength | Capability classification | Evidence status and source |
|---|---|---|
| Current Python regression suite: 193/193 pass, 0 skip | Verified tool-based | Successfully executed; `unittest.log` and `release-check.json` |
| Current workbench code/DOM conformance: 37/37 pass | Verified tool-based | Successfully executed; `workbench.log`; explicitly a minimal DOM model |
| Strict duplicate/nonfinite JSON rejection, duplicate YAML rejection, malformed project typed errors | Verified tool-based | Successfully executed tests plus five new malformed-shape probes; `tests/test_validation_integrity.py`; `probes.json` |
| OpenAPI local references/security declarations/path parameters and 3.0/3.1 semantic distinction have meaningful counterexample tests | Verified tool-based | Successfully executed `test_audit_followups`, `test_contract_resolution_review`, `test_contract_semantics`, `test_validation_integrity` |
| Missing required optional validators, budget limits, failed renderer output do not silently pass the selected applicable gates | Verified tool-based | Successfully executed `test_release` and `test_validation_integrity`; `validation_engine.py:484–492` |
| Render exit 0 must produce nonempty safe SVG before passing | Verified tool-based | Successfully executed renderer test doubles and source inspection; no actual mmdc render was performed |
| Semantic review accounting binds reviews to capture identity, preserves dissent and blocks critical failures | Verified tool-based | Successfully executed `test_skill_evaluation`; `evaluation_records.py:25–123` |
| Supplied-response lexical checks are bounded and explicitly disclaim semantic certification | Verified tool-based | Successfully executed regressions; `behavioral_eval.py:58–88` |
| Browser CI is separate from Node code/DOM checks; SHA-pinned CI actions and hash-locked optional wheels are present | Implemented, unverified | Directly inspected `.github/workflows/ci.yml:14–68`; remote CI status not assessed by this specialist |

## 5. Verified defects and scoped gaps

### QA-101 — Handoff validation does not verify generation manifest completeness or byte integrity

Priority **P1 — Foundational**; confidence high; evidence Successfully executed and Directly inspected. Capability classification **Partial**.

`artifact_compiler.py:106–120,164–171` generates exact artifact hashes and a generation manifest. Recovery checks those hashes (`128–140`). The validator resolves the committed generation (`validation_engine.py:365–370`) but treats its manifest as generic JSON syntax, skips Markdown, and checks API correspondence only when an API is actually present (`393–394,466,469–483`). It never verifies the manifest's expected file list or hashes.

Reproduction: generate a handoff from `tests/fixtures/rich-project.json`; baseline structural validation passes. Delete the manifest-listed `api.json`; structural validation still returns `policy_ok: true`, and the prior correspondence check disappears. Replace `architecture.md` with unrelated text; structural validation still returns green. `probes.json` retains all results.

This is **not** evidence that the checks it did run gave incorrect structural answers. It is a missing integrity/completeness dimension that can be mistaken for a complete handoff gate. The generation's immutability is a software convention, not filesystem enforcement. Reuse existing manifest and safe I/O utilities rather than add another artifact index.

### QA-102 — Full gate can pass an invalid AsyncAPI envelope

Priority **P1 — Foundational** if `full` is used for interface verification; confidence high; evidence Successfully executed and Directly inspected. Capability classification **Partial**.

File `asyncapi.json` containing `{"asyncapi":"bogus","info":{},"channels":{}}` passed `validate(path, gate='full')` with `policy_ok: true`. The only check is `AsyncAPI declaration: passed` and its detail says basic envelope only (`validation_engine.py:465`). `required_incomplete` covers OpenAPI/Mermaid/project checks but has no AsyncAPI schema requirement (`485`). Thus the tool's check detail is appropriately narrow while the selected gate does not make missing schema verification explicit.

A low-cost repair is to validate supported version/envelope fields, record a separate AsyncAPI schema check as unsupported/not run, and make a full interface gate incomplete when that check is required. Installing a new validator is unnecessary for honest behavior. Future full validation must be version-pinned and offline-reference constrained.

## 6. Missing capabilities

**QA-103 — No measured semantic software-engineering baseline in the inspected evaluation assets.** Priority P2; capability **Proposed** for the benchmark campaign; evidence Directly inspected / outcomes Unverified. `evals/architecture-cases.json` and example responses test lexical predicates. `evals/semantic-review-rubric.json` is explicitly an instrument. `evaluation_records.py:1–5,118–123` validates supplied review accounting without authenticating reviewer calibration or model execution. Those are sound limitations. Real task captures with repeat runs and independent review are needed to establish improvement from GitHub skill adoption.

No fresh real-browser result here (**Tool-dependent**, Blocked by unavailable access): installed browser tooling could not open the test server's loopback socket. No full screen-reader audit, performance/load benchmark, production security assessment or cross-platform validation was performed. These are unknowns, not demonstrated defects.

## 7. Risks

A caller may flatten `ok` and `policy_ok`, or read `full` as broader assurance than check applicability supports. The current note correctly limits scope, but machine-readable dimensions would reduce that risk. Hashes detect accidental or later artifact changes when checked; they cannot authenticate an attacker-controlled manifest. Coherent artifact bytes still cannot prove architecture quality. Test count growth can mask unchanged semantic coverage. Passing local tests does not establish remote CI or browser outcomes. Adding third-party skills before matched-task measurement risks increasing context and instruction conflict without quality gain.

## 8. Redundant functionality

No verified redundant skill/tool warrants removal from QA evidence alone. Existing lexical fixtures, structural validation and semantic review instruments serve different purposes. Consolidate duplicated status interpretation in consumers, not the evidence layers. `check_release` reruns Python and Node suites by design; avoid presenting both direct and aggregate runs as 386 unique Python cases or 74 unique Node checks.

## 9. Recommended improvements

- **QA-I01, linked QA-101:** add `Handoff manifest integrity` and `Handoff required-artifact coverage` checks when a generated handoff marker/manifest is detected. Validate bounded manifest shape, safe relative paths, source/generation identities, file existence/type/hash and declared membership before content checks. Preserve report-only inspection of other files after failures. Never repair or rewrite artifacts during validation.
- **QA-I02, linked QA-102:** define per-format applicability. AsyncAPI envelope inspection is separate from schema verification; unsupported schema verification must remain incomplete for a full interface gate. Invalid/unknown versions fail envelope checks. Preserve structural-only inspection as explicitly scoped.
- **QA-I03, linked QA-103:** create a compact matched-task benchmark for source-grounded changes, code generation and debugging. Capture exact prompt, response, selected skill/reference hashes, source state, actual check receipts, declared model and tool capabilities. Compare baseline against selectively adapted GitHub material with equivalent task/environment budgets. Retain raw results and disagreements.
- **QA-I04:** reuse nine existing browser cases on a host that permits loopback/browser execution, and add scenario-specific UI regressions only for discovered failures. No requirement to build a new browser framework.

## 10. Features to remove

Remove any downstream wording that treats a lexical score as an overall engineering-quality score, or treats structural success as complete manifest verification. No such universal claim was proven in the inspected CLI's own result notes. Do not remove useful optional checks merely because this host cannot run a renderer/browser.

## 11. Features to add

Add the two missing explicit check dimensions and an applicability table to the existing validator; add a reusable benchmark protocol and actual captures when authorized. Do not add one QA skill per test type, a new agent framework, or a second canonical project schema.

## 12. ChatGPT compatibility assessment

The toolkit is executable only when ChatGPT's host exposes a permitted execution workspace; its instructions alone cannot run tests. This session did expose Python/Node tools, so local test execution is Verified tool-based for this audit. Browser execution is Tool-dependent and blocked here. Review accounting and captured files are portable; they are not automatic cloud memory. User-supplied test output remains supplied evidence until independently reproduced. Keep assistant-generated code, applied changes, checks passed, runtime behavior and deployment as distinct outcomes.

## 13. Relevant plugin integrations

A permissioned GitHub connector can read exact source/CI artifacts when available. An authorized coding environment/CI runner can execute tests. Neither should be declared a native capability of a skill. Browser or security tools should be chosen by actual operation schemas and permissions; no plugin installation or account connection was performed here. Root is separately researching the ecosystem and GitHub programming skills. From QA's view every adopted skill needs pinned provenance, license review, trigger/conflict tests and a matched-task effectiveness experiment before an improvement claim.

## 14. Priority rankings

| Priority | Initiative | Value / effort / dependency |
|---|---|---|
| P1 | QA-I01 manifest integrity/coverage | High integrity value; small-to-medium change; reuse compiler manifest/safe I/O |
| P1 | QA-I02 AsyncAPI full-gate applicability | High verification honesty value; small change; no new installation required |
| P2 | QA-I03 captured semantic benchmark | High product evidence value; medium effort; actual model/task execution and reviewer availability |
| P2 | QA-I04 fresh browser evidence | High UI evidence value; low setup effort on permitted host; blocked by current host policy |

No P0 claim is justified by this bounded investigation.

## 15. Evidence and confidence

| Evidence | Result | Limit |
|---|---|---|
| QA-E01 `unittest.log` | 193 passed, 0 skipped, 3.321 seconds | Local Linux/Python 3.12.14; no model called |
| QA-E02 `workbench.log` | 37 passed | Node minimal DOM; no browser rendering |
| QA-E03 source manifest | 116 files, zero missing/unlisted/changed | Scoped inventory; no signature/authenticity claim |
| QA-E04 `release-check.json` | Aggregate check passed; Python repeated in 3.391-second test run | Same unique suites as E01/E02 |
| QA-E05 `browser.log` | Blocked before tests: `PermissionError: [Errno 1] Operation not permitted` creating socket | Nine defined tests, zero executed |
| QA-E06 `probe.py`,`probes.json` | Missing/tampered handoff and invalid AsyncAPI counterexamples reproduced; five malformed projects rejected without exceptions | Synthetic bounded probes, not production incident evidence |
| QA-E07 `baseline.json` + ledger | Zero tracked-source hash changes from initial inventory | Original target preserved |

Historical regression reconciliation: malformed shape crashes **fixed for tested cases**; round-trip loss, nested snapshots, editor draft preservation, revision integrity, cache overwrite, cost arithmetic, OpenAPI security refs and stale managed handoff removal **fixed for tested cases** in the fresh suites. Incomplete repository semantics remain **partial by design**; comprehensive behavioral model evaluation remains **unverified**. Handoff integrity validation is a newly reproduced gap; it does not imply stale-file removal regressed. Full browser/data-loss behavior remains **unverifiable on this host** despite passing Node checks. Do not collapse this into a claim that every historical failure is universally fixed.

## 16. Proposed acceptance criteria

**QA-I01:** An intact generated handoff passes existing structural checks plus independent manifest coverage/hash checks. Deleting any declared artifact, altering JSON/Markdown bytes or changing generation/source identity blocks integrity policy. Traversal, absolute paths, symlinks, duplicate names, malformed hash/type and over-budget entries fail safely without reads outside root. Extra user notes remain separately identified and are not deleted. Validator output reports expected/observed/missing/changed counts; never mutates handoff. Hashes remain untrusted integrity metadata, not signatures.

**QA-I02:** Invalid AsyncAPI version/info/channels fails envelope inspection. For supported valid envelopes without a full schema validator, structural result can state envelope checked, while a full interface requirement cannot pass; status must be unsupported or skipped with reason. Applicable OpenAPI 3.0/3.1 checks continue to pass/fail existing fixtures unchanged. Unknown format applicability is explicit. No network fetch occurs during offline checks.

**QA-I03:** Predeclare a representative task set spanning new multi-file program, bug reproduction/fix, API/data change, repository review, conflicting requirements, unavailable tools and injection. Record exact task/tool budgets, baseline and candidate skill bundle identities. Each actual change has independent executable acceptance where possible, semantic rubrics have two attributed calibrated reviewers and preserved disagreement, all critical failures block the claimed capability. Publish counts of passed/failed/skipped/blocked tasks and conditional improvement; no overall superiority claim from lexical scores. Candidate wins must not come from more permissions or extra hidden context.

**QA-I04:** All nine browser cases execute with exact browser/Playwright/source identity and per-case outcomes on a permitted host; failure traces retained. Node passes alone cannot satisfy a browser requirement. Remote CI status must refer to the reviewed commit, not merely an existing workflow file.

## 17. Unresolved questions

Who consumes `policy_ok` as a release gate, and which format/integrity dimensions are required there? Does the currently installed ChatGPT package match repository v0.9.1 (the root is verifying separately)? Are representative real model captures and calibration materials available outside inspected assets? Which host can run browser tests under the authorized scope? Should AsyncAPI full validation be implemented or explicitly deferred? No answer is invented.

## 18. Final verdict

Preserve the regression infrastructure and its truthful evidence distinctions. Correct manifest-integrity coverage and AsyncAPI applicability before calling broader handoff/interface gates complete. Use selective GitHub skill adoption as a testable change hypothesis. The current package is locally regression-tested and structurally capable; reliable model-driven program creation remains a capability to measure on actual tasks.
