import json, sys, time
from pathlib import Path
sys.path.insert(0,'/workspace/SOFTWARE-ARCHITECT-STUDIO/tools')
import execution_adapter as a
BASE=Path('/workspace/work/sas-audit-2026-11-01/specialist06')
root=BASE/'completion-fixture';root.mkdir(exist_ok=True);target=root/'source.txt';target.write_text('original')
child="import time;from pathlib import Path;time.sleep(.8);Path("+repr(str(target))+").write_text('late synthetic change')"
parent="import subprocess,sys;subprocess.Popen([sys.executable,'-c',"+repr(child)+"])"
policy={'schema_version':1,'root':str(root),'authorization_reference':'synthetic-disposable-probe','allow_checks':True,'checks':{'short':{'argv':[sys.executable,'-c',parent],'timeout_seconds':.2}}}
state=BASE/'completion-state';before=a.inspect(root)['source_hash']
receipt=a.run_checks(root,['short'],policy,expected_source_hash=before,operation_id='completion-probe',state_root=state)
first=a.reconcile(root,receipt,expected_operation='completion-probe',expected_source_hash=before,required_checks=['short'],state_root=state)
time.sleep(1)
second=a.reconcile(root,receipt,expected_operation='completion-probe',expected_source_hash=before,required_checks=['short'],state_root=state)
data={'receipt':receipt,'immediate_reconcile':first,'after_child_reconcile':second,'late_file_content':target.read_text()}
(BASE/'completion-results.json').write_text(json.dumps(data,indent=2));print(json.dumps({'check_status':receipt['status'],'immediate_reconcile':first['status'],'late_file_content':target.read_text(),'after_child_reconcile':second['status'],'late_blocker':second['issues']},indent=2))
