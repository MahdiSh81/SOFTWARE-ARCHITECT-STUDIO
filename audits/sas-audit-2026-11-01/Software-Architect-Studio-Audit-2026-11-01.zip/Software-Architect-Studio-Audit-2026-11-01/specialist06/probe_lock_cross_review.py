import json,sys,subprocess
from pathlib import Path
sys.path.insert(0,'/workspace/SOFTWARE-ARCHITECT-STUDIO/tools')
import revision_store as r
BASE=Path('/workspace/work/sas-audit-2026-11-01/specialist06');root=BASE/'independent-death-lock'
r.init_project(root,'Synthetic isolated lock review')
program='import sys,os;sys.path.insert(0,"/workspace/SOFTWARE-ARCHITECT-STUDIO/tools");from safe_io import project_lock;from pathlib import Path\nwith project_lock(Path(sys.argv[1])):os._exit(82)'
result=subprocess.run([sys.executable,'-B','-c',program,str(root)])
output={'child_exit':result.returncode,'lock_remains':(root/'.architecture.lock').exists(),'initial_revision':r.load_project(root)['revision']}
try:output['recovery']=r.recover(root)
except Exception as e:output['recovery_error']=type(e).__name__
output['revision_preserved']=r.load_project(root)['revision']==output['initial_revision']
# Leave scratch evidence intact; never unlink another actor's lock or target source.
(BASE/'cross-review-lock-results.json').write_text(json.dumps(output,indent=2));print(json.dumps(output,indent=2))
