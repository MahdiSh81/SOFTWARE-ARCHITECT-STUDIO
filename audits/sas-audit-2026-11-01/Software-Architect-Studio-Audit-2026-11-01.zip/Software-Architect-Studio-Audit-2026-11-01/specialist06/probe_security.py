import json, os, sys, time, copy
from pathlib import Path
sys.path.insert(0, '/workspace/SOFTWARE-ARCHITECT-STUDIO/tools')
from disclosure import minimized
from validation_engine import bounded_process, openapi_checks
from safe_io import read_bytes
import execution_adapter as a
BASE = Path('/workspace/work/sas-audit-2026-11-01/specialist06')
results = []
def record(name, data): results.append({'name':name, **data})
# Synthetic marker values only; no credential lookup.
examples={'unquoted': 'api_key=SYNTHETIC_VALUE', 'double_quoted': 'api_key="SYNTHETIC_VALUE"', 'single_quoted': "password='SYNTHETIC_VALUE'", 'bearer': 'Authorization: Bearer SYNTHETIC_VALUE', 'structured': {'token':'SYNTHETIC_VALUE'}}
record('minimization_synthetic_formats', {'input':examples, 'output':minimized(examples)})
root=BASE/'fixture';root.mkdir(exist_ok=True);(root/'a.txt').write_text('original')
plan=a.propose_change(root,[{'path':'a.txt','content':'changed'}])
try:
 a.apply_change(root,plan, {'schema_version':1,'root':str(root),'allow_write':True,'allowed_paths':['a.txt']}, state_root=BASE/'state')
 record('missing_authority', {'refused':False})
except ValueError as e: record('missing_authority', {'refused':True,'reason':str(e),'preserved':(root/'a.txt').read_text()=='original'})
for name in ('../outside.txt','/tmp/outside.txt','dir/../a.txt'):
 try:a.propose_change(root,[{'path':name,'content':'no'}]);refused=False
 except ValueError:refused=True
 record('unsafe_path',{'path':name,'refused':refused})
link=BASE/'synthetic-link';link.symlink_to(root/'a.txt')
try: read_bytes(link);refused=False
except ValueError: refused=True
record('symlink_read',{'refused':refused});link.unlink()
api={'openapi':'3.0.3','info':{'title':'synthetic','version':'1'},'paths':{},'components':{'schemas':{'A':{'$ref':'https://example.invalid/synthetic.json'}}}}
record('offline_external_ref', {'findings':openapi_checks(api)})
# Parent exits normally while an ordinary same-process-group child outlives timeout.
marker=BASE/'child-completed-marker'
child="import time;from pathlib import Path;time.sleep(0.9);Path("+repr(str(marker))+").write_text('synthetic-only')"
parent="import subprocess,sys;subprocess.Popen([sys.executable,'-c',"+repr(child)+"])"
start=time.monotonic();outcome=bounded_process([sys.executable,'-c',parent],timeout=.2,cwd=str(root));elapsed=time.monotonic()-start
record('child_lifetime_at_return',{'status':outcome['status'],'elapsed_seconds':elapsed,'marker_exists':marker.exists()})
time.sleep(1.0)
record('child_lifetime_after_declared_timeout',{'marker_exists':marker.exists(),'elapsed_seconds':time.monotonic()-start})
if marker.exists():marker.unlink()
(BASE/'probe-results.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
