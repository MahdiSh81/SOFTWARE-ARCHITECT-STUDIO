import json,sys,hashlib
from pathlib import Path
ROOT=Path('/workspace/SOFTWARE-ARCHITECT-STUDIO')
sys.path.insert(0,str(ROOT/'tools'))
from skill_registry import discover_skills,route_task,inventory_bundle
from evaluation_records import capture_identity,summarize_captures,validate_review

def review(c,who):
    return {'reviewer_id':who,'capture_id':c['id'],'source_hash':capture_identity(c),
      'reviewed_at':'2026-11-01T19:00:00+03:30','rubric_version':1,
      'scores':{k:3 for k in ('correctness','evidence','risk_handling','constraint_adherence','usefulness')},
      'critical_failures':[],'evidence_refs':['synthetic:probe'],'calibrated':True,
      'calibration_reference':'synthetic:calibration','conclusion':'Synthetic probe only; not an actual capture.'}

def main():
    malformed={'id':'synthetic-missing-prompt-and-response'}
    malformed['reviews']=[review(malformed,'a'),review(malformed,'b')]
    cases=json.loads((ROOT/'evals/routing-cases.json').read_text())['cases']
    conformance=[]
    for c in cases:
        out=route_task(c['task'],override=c.get('override'))
        conformance.append({'id':c['id'],'pass':('expected_primary' not in c or out['primary'] in c['expected_primary']) and ('expected_ambiguous' not in c or out['ambiguous']==c['expected_ambiguous'])})
    tasks=['Write a Python command-line calculator','Create a React expense tracker','Fix a crash when account deletion fails','Do not deploy; review only','Explain this backend stack trace','Implement accessible account settings with database migration','Generate a REST service','Debug the failing test','Explain consistent hashing']
    registry=discover_skills()
    runtime=Path('/workspace/work/sas-audit-2026-11-01/specialist07/runtime')
    comparisons=[]
    for p in sorted(runtime.glob('*.md')):
        local=ROOT/'skills'/p.name.replace('.md','')/'SKILL.md'
        comparisons.append({'id':p.stem,'runtime_bytes':p.stat().st_size,'source_bytes':local.stat().st_size,'same':p.read_bytes()==local.read_bytes()})
    out={'source_commit':'1fa377cc9cbe7054d7edbf8091e22efaa296c05e','registry':registry,
      'packaged_bundle_entry_count':len(inventory_bundle()['entries']),
      'runtime_source_comparisons':comparisons,'curated_conformance':{'cases':len(conformance),'passed':sum(x['pass'] for x in conformance),'results':conformance},
      'new_routing_probes':[{'task':t,'result':route_task(t)} for t in tasks],
      'malformed_capture':malformed,'malformed_capture_review_validation':[validate_review(r,malformed) for r in malformed['reviews']],
      'malformed_capture_summary':summarize_captures([malformed])}
    try:
        from jsonschema import Draft202012Validator
        schema=json.loads((ROOT/'schemas/capture-lineage-v1.schema.json').read_text())
        out['malformed_capture_schema_errors']=[e.message for e in Draft202012Validator(schema).iter_errors(malformed)]
    except ImportError:out['schema_check']='blocked: optional jsonschema missing'
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
