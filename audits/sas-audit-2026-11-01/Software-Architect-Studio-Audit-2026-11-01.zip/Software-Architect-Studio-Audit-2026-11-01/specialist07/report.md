# Specialist 07 — AI systems, skills and orchestration

**Final readback addendum:** the runtime refreshed after this independent first pass. At18:30:01–18:30:03 Asia/Tehran, this specialist independently reread all eleven definitions and confirmed exact UTF-8 equality with the selected GitHub0.9.1 source. See `runtime-transition.md`, `runtime-refresh-comparison.json` and `cross-review.md`. SKILL-102 below records the earlier time-scoped observation; it is not an open final parity defect. No cause/publication action is inferred.

Independent first pass, 1 November 2026 (Asia/Tehran). No new specialist reports were read. The user selected GitHub as source of record: [MahdiSh81/SOFTWARE-ARCHITECT-STUDIO at 1fa377c](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/tree/1fa377cc9cbe7054d7edbf8091e22efaa296c05e). Its clean local execution mirror was inspected without modification. Source inspection and synthetic local probes are separate from live model/host workflow evaluation.

## 1. Executive assessment

Retain the eleven outcome-oriented skills and smallest-owner coordinator. The repository has meaningfully stronger skill contracts, lineage and semantic-review accounting than a loose prompt collection. Correct the semantic-summary validation gap before calling its boolean a quality gate, reconcile the runtime delivery surface with the selected source release, and improve routing coverage using independently written tasks. Additional language-specific top-level skills are not justified by this review.

AI-101 is a reproduced correctness defect: a capture containing only an ID and two valid review records, without a prompt, response or provenance, reaches `semantic_gate_passed: true`. Existing tests all pass, demonstrating a missing negative case rather than a broken baseline suite. No live model-quality improvement is established.

## 2. Scope inspected

All eleven current `skills/*/SKILL.md` files, coordinator references relevant to evidence/routing/evaluation, `tools/skill_registry.py`, `tools/evaluation_records.py`, `tools/behavioral_eval.py`, capture/summary CLI wiring, `docs/recipes.md`, `docs/integrations.md`, `docs/implementation-adapter.md`, skill/capture/review/routing schemas, `evals/routing-cases.json`, `tests/test_skill_evaluation.py`, capabilities and manifests. The seven currently exposed cloud skill definitions were independently read through `skills.read` and retained under `runtime/`; the runtime catalog is not assumed to be the repository release.

## 3. Methodology

Inspect current source first; treat instructions as instructions and test instruments as instruments. Run the existing relevant suite with `PYTHONDONTWRITEBYTECODE=1` and the existing optional-validator environment. Add nine scratch routing probes and one deliberately malformed synthetic capture. Compare current runtime definitions to source. Preserve exact scripts/results under this directory. No installation, publication, account connection, model endpoint call, source edit or third-party data disclosure was performed.

## 4. Verified strengths

| Capability | Classification | Evidence status and scope |
|---|---|---|
| Local discovery of eleven versioned skill definitions | Verified tool-based | Successfully executed `discover_skills`; every source definition identifies 0.9.1. Registry describes scope and no authority. |
| Deterministic smallest-owner routing | Verified tool-based | Successfully executed 80/80 checked-in conformance cases; suggestions never invoke tools. This establishes fixture conformance only. |
| Loaded-context versus available-package identity | Verified tool-based | Existing tests and fresh probe confirm separate caller-declared loaded bundle and 28-entry available inventory. No authenticated model context trace is claimed. |
| Review source mismatch, duplicate reviewer, disagreement and critical-failure accounting | Verified tool-based | Existing 15-test skill/evaluation suite passed under existing optional validators; source retains dissent and fails edited-response reviews. |
| Domain workflows, uncertainty and permission boundaries | Instruction-only | Directly inspected eleven skills. They explicitly distinguish plans, edits, build/test/runtime/deployment, missing tools and user/host authority. This review did not evaluate complete model behavior for each skill. |
| Selective specialist review protocol | Instruction-only | Coordinator and `workflow_tools.specialist_plan` say plan-only; host execution is conditional and not fabricated. |

Strong source anchors: [registry](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/skill_registry.py#L31), [capture lineage](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/evaluation_records.py#L62), [coordinator task ownership](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/skills/software-architecture/SKILL.md#L100), [recipes and boundary statements](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/docs/recipes.md#L48).

## 5. Verified defects

### AI-101 — semantic-summary gate accepts a structurally absent capture (P1)

**Observed:** `summarize_captures` validates only a bounded ID and review list for each capture before counting complete calibrated attributed reviews. A synthetic object with `id` and two source-matching reviews but no `capture_schema`, `prompt`, `response`, `reported_model`, loaded bundle, available bundle or review-source hash returns `semantic_gate_passed: true` and `review_complete`. The checked-in capture schema rejects all seven missing fields. The real `quality-summary` CLI returned that result with exit 0.

**Sources:** [evaluation_records.py 79–123](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/evaluation_records.py#L79), [capture schema required fields](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/schemas/capture-lineage-v1.schema.json#L4), [CLI 110](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/architect_cli.py#L110). Reproduction: `probe.py`, `probe-results.json`, `malformed-captures.json`, `malformed-cli-result.json`. Evidence status: Successfully executed. Confidence: high.

**Impact:** malformed imported accounting can be green even when no response exists to assess. This does not mean review aliases or calibration must be authenticated; attributed reviews remain an intentionally documented trust boundary. The narrower defect is that required capture content/lineage is not structurally enforced at this consumer.

**Proposed fix:** add a bounded pure capture validator invoked by `summarize_captures` before any counting, consistent with the published schema and available without optional `jsonschema`. Require meaningful prompt/response/model strings, version, supported bundle shapes/hashes and matching recomputed capture identity. Do not fill absent provenance with guessed source/runtime information. Keep schema validation as an additional check when available. Refuse malformed captures with an exact diagnostic; preserve originals. Provide a nonzero validation failure from CLI. Preserve legitimate `reported_model: unknown` and attributed-review semantics.

### SKILL-101 — four current skills retain undefined short aliases/common contracts (P2)

Four new skills refer to `S01`–`S11`, “Common input”, and “Common result” without linking a current packaged definition. Their final link points to `docs/recipes.md`, which gives useful workflow guidance but does not define those aliases or one common envelope. The corresponding definitions can be found in historical audit material, but the current skills do not point to it and historical reports should not be a live dependency.

**Sources:** frontend, service/data, delivery and AI evaluation skills at lines 34, 38, 62–70; [frontend example](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/skills/frontend-interaction-and-accessibility/SKILL.md#L34), [current recipe](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/docs/recipes.md). Directly inspected; high confidence on missing linkage, moderate confidence on practical model impact. This is an instruction maintenance/composability defect, not demonstrated tool execution failure.

**Proposed fix:** replace opaque aliases with actual skill identifiers and links; put a small prose common input/result contract in the current recipe/reference and link it explicitly. Do not create another runtime service or mandatory metadata layer for simple advice.

## 6. Missing capabilities and delivery gaps

### SKILL-102 — runtime/source delivery parity is not established (P1 release assurance)

The source has eleven 0.9.1 skills. The available session catalog exposes seven, and the actually read coordinator says v0.7.2. All seven returned definitions differ from source; the six runtime specialists omit the current compact task contracts and explicit source version. The four source additions are absent from this session catalog. This directly establishes a session/source difference, not the cause, scope of publication, or that every user sees stale content.

Evidence: `runtime/*.md`, `probe-results.json.runtime_source_comparisons`, session catalog, [source root](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/skills/software-architecture/SKILL.md#L1). Evidence status: Directly inspected. Confidence high for current-session difference; release pipeline/installation causality Unknown.

Proposed release acceptance: record source commit, package release identity and expected skill hashes; inspect the published package through supported read tools; reload/restart in the intended host where required; read every expected skill again and compare identities. Do not publish or reinstall during this audit. If intentional, document compatibility and expected omissions instead of asserting parity.

### AI-102 — real task routing/generalization remains unmeasured (P2)

All 80 curated fixtures pass. New ordinary tasks “Write a Python command-line calculator”, “Create a React expense tracker”, “Fix a crash when account deletion fails”, and “Generate a REST service” produce no candidates and a low-confidence coordinator suggestion. “Explain this backend stack trace” is forced to conceptual advice despite a debug candidate. These are explainable limitations of current regexes, not evidence that ChatGPT itself activates the wrong skill or performs unsafe effects. “Do not deploy; review only” chooses operations; that owner selection alone is not a permission violation because the result is advisory and the skill itself separates review from action.

Evidence: [route patterns/conceptual rule](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/skill_registry.py#L100), `probe-results.json.new_routing_probes`. Evidence status: Successfully executed for examples; inferred task ownership judgment. Do not report a statistical failure rate from these deliberately selected counterexamples.

Proposed change: expand independently authored build/create/fix paraphrases and conceptual-versus-specific evidence distinctions; keep primary owner/ambiguity/manual override and bounded source. Add host activation traces only when exposed. Use held-out tasks and report coverage/errors, rather than enlarging regexes until a self-authored fixture set is green.

## 7. Risks

Malformed-capture green status can contaminate downstream quality decisions (AI-101). Runtime/source divergence can make repository capabilities appear available when session instructions differ (SKILL-102). Aliases and implicit common contracts increase maintenance ambiguity (SKILL-101). Regex suggestions can be mistaken for semantic activation if consumers ignore the explicit limitation (AI-102). Caller-declared skill bundles and reviewer aliases are not authenticated; this is an explicit limit, not a newly discovered exploit. No memory/continuity mechanism should be described as automatic cloud persistence. Related-model agreement is not independent truth.

## 8. Redundant functionality

The six compact specialists repeat failure/validation/shared-boundary paragraphs and the four long skills repeat 22 headings. Repetition is directly visible; token/latency cost was not measured. Core permission/evidence contracts can be referenced, but critical no-fabrication/authority reminders should remain local. Repository inspection, implementation coordination, testing, security, contracts, frontend behavior, service/data invariants, operations and AI evaluation own different outputs. No whole-skill merge is justified solely because these tasks share steps.

## 9. Recommended improvements

1. I07-01 / AI-101: validate capture content and provenance before semantic accounting; 1–2 engineering days provisional, dependent on schema compatibility review; no external infrastructure. Rollback retains old source and rejects unsupported imported captures with recovery bytes.
2. I07-02 / SKILL-102: establish source/package/runtime compatibility evidence; 1–3 days provisional plus host release access. A read-only inspection precedes any separately authorized release. Keep existing sharing and identity.
3. I07-03 / SKILL-101: make current skill identifiers and shared prose contracts resolvable; under one day plus review. Keep old skill IDs and intent ownership; no data migration.
4. I07-04 / AI-102: broaden task evidence and routing tests, then evaluate host-level activation if accessible; 2–4 days plus study execution. Measure candidate coverage, inappropriate-owner rate, clarification burden, semantic task outcomes and context cost on a declared task set.

Effort estimates describe implementation slices, not promises. Proposed status: none implemented by this audit.

## 10. Features to remove

Remove unresolved numeric skill aliases from live skills after replacing them with resolvable names. Remove any reporting that treats curated conformance as live model quality. Retain all eleven skills and Quick/Guided/Full depth; no evidence justifies deleting actual capabilities. Do not remove explicit unsupported/unknown status to simplify outputs.

## 11. Features to add

Add malformed capture negative fixtures and source/runtime parity receipts; add a small shared instruction contract and held-out routing corpus. Prefer relevant upstream programming patterns as on-demand references inside existing owners. No new top-level skill is required by these findings. Root research covers actual upstream provenance/licensing before adoption; this reviewer did not evaluate those repositories.

## 12. ChatGPT compatibility assessment

The design is ChatGPT-native at the instruction layer. Local discovery, CLI and adapter actions remain Tool-dependent outside an available authorized runner. Source files are not automatically loaded just because they exist in GitHub. The current host's `skills.read` actually returned seven cloud definitions, so the intended eleven-skill target is not verified as delivered here. Specialist instructions and `review-plan` do not instantiate agents; this current ten-specialist audit uses actual host delegation authorized by the user's mandate. Persistent project continuity requires actual files/Git/storage or user-mediated export, not assumed chat synchronization.

## 13. Relevant plugin integrations

Use available authorized GitHub reads for source identity and receipts; selected coding runner for actual edits/tests; real browser for UI claims; schema validators for applicable contract checks. Optional documentation/security/provider integrations are Tool-dependent until inspected and called. Native instructions should own synthesis/evidence/reconciliation. No automatic plugin-to-plugin invocation is inferred. No plugin installation/connection or external effect was attempted.

## 14. Priority rankings

P1: AI-101 fail-open capture accounting, SKILL-102 source/runtime release assurance. P2: SKILL-101 shared-contract linkage, AI-102 routing evidence. P3: measured context/reference compression if repeated task observations show value. No P0 demonstrated. Security or global quality severity must not be inferred from the word “semantic” in an accounting boolean.

## 15. Evidence and confidence

| Evidence ID | Artifact/source | Status | Confidence |
|---|---|---|---|
| E07-01 | Eleven source skills and registry; source version0.9.1 | Directly inspected | High |
| E07-02 | `runtime/*.md`, seven successful skills.read results; coordinator0.7.2 | Directly inspected | High within this session |
| E07-03 | `skill-tests.log`: 15 tests, all passed, includes80 routing fixtures | Successfully executed | High for scoped code behavior |
| E07-04 | `probe.py`, `probe-results.json`, malformed CLI output | Successfully executed | High for AI-101 |
| E07-05 | Nine new routing probes | Successfully executed | High for exact outputs; moderate for owner judgment |
| E07-06 | Capture/review/bundle schemas and CLI wiring | Directly inspected | High |
| E07-07 | End-to-end instruction quality, live model comparative benefit, real user value | Unverified | No measured claim |

Maturity: skill responsibilities/output definitions Level3 Repeatable as a documented workflow design, moderate confidence; source inventory and curated routing Level4 Validated within the stated local fixture scope, high confidence; semantic accounting Level2 Defined with critical import-validation gap, high confidence; host activation/delivery parity Level2 Defined, incomplete evidence; live semantic model quality Unknown (no defensible numeric maturity assignment). These are separate axes, not an overall score.

## 16. Proposed acceptance criteria

- AI-101: missing/wrong/whitespace prompt,response,model/version/bundle/source hash cases fail with exact diagnostics before review counting in both core-only and optional-validator environments. Valid unknown-model captures pass structural checks; zero captures/unreviewed/critical failure/duplicate reviewer/source mismatch/disagreement retain their existing nongreen behavior. CLI malformed input exits nonzero and preserves source file.
- SKILL-102: every expected source skill is either read successfully in the intended runtime at exact reviewed content identity, or documented as intentionally unsupported with compatibility mapping; no repository-only capability is advertised as runtime verified. Record release/tool/host identity.
- SKILL-101: all live skill references resolve without consulting historical audit text; stable identifiers used; a reviewer can list common input/result fields from the linked current resource; conceptual questions remain lightweight.
- AI-102: an independently labeled declared task set covers ordinary build/create/fix forms, conceptual explanations, source-specific diagnosis, mixed-owner ambiguity, negations, unavailable-tool cases and manual overrides. Report all slices, disagreement and limitations; set improvement thresholds before the run. Never treat owner choice as authority.

## 17. Unresolved questions

Which plugin release backs this session's skill catalog, and is its older content intentional? What host restart/reload or update process is required? Are loaded-context traces observable beyond caller declarations? Which task populations justify the four additional specialists in practice? Should quality-summary expose a separate `records_valid` versus `semantic_review_accounting_passed` field to reduce misuse? What semantic user-task benefit does routing produce against the coordinator alone? None can be answered by local fixtures alone.

## 18. Final verdict

The current GitHub design is coherent and does not need a sprawling programming-skill collection. Preserve the eleven owners, repair capture ingestion, make skill references explicit, verify runtime delivery, and measure actual task outcomes before broader claims. Full per-skill dispositions/contracts are in `skill-inventory.md`. Ready for cross-examination; no source change was implemented.
