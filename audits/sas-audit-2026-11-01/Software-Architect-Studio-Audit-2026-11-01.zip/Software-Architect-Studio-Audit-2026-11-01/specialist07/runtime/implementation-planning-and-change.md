---
name: implementation-planning-and-change
description: Convert an approved requirement or defect into a minimal reviewable code-change plan using authorized tools when available.
---
# Implementation Planning and Change

Establish repository/ref, source identity, dirty state, accepted requirements/ADRs, available tool capabilities, and permissions. If an actual editor or runner is unavailable, provide a plan or patch proposal and mark execution blocked.

1. Convert the request into acceptance criteria and affected files/contracts.
2. Inspect relevant source and existing tests.
3. Define a regression test before implementation.
4. Produce a minimal plan and diff; flag generated and unrelated changes.
5. Validate scope and constraints.
6. Obtain required authorization before consequential writes/deployments.
7. Apply only through an authorized tool with expected-hash preconditions where supported.
8. Run targeted and relevant regression/build/security checks using actual runners.
9. Record source identity, changed files, hashes, versions, checks run/not run, and residual risks.
10. Reconcile code and architecture artifacts without silently overwriting accepted decisions.

Never claim a patch, build, test, or deployment happened without a real tool result. Do not blindly retry non-idempotent operations.

