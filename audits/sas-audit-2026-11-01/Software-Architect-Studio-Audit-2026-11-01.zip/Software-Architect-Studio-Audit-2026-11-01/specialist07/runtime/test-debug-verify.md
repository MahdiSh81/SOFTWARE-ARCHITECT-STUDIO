---
name: test-debug-verify
description: Diagnose failures, design discriminating regression tests, and report evidence-backed verification status.
---
# Test, Debug, Verify

1. Establish expected behavior, symptom, source identity, environment, versions, and reproduction.
2. Separate observed facts from hypotheses and identify the smallest discriminating test.
3. Add/select a regression test.
4. Apply a minimal fix only when authorized and a real editing tool is available.
5. Run targeted tests, then relevant regression/build/security checks.
6. Capture exact commands, source hash/commit, versions, status, logs/artifacts, and skipped checks.
7. Reconcile results with acceptance criteria and state residual uncertainty.

Use passed, failed, blocked, timed_out, skipped, partial, or unknown. A required skipped check is not green. One unit test does not establish runtime or production behavior. "Fixed" requires evidence the regression no longer occurs. Never fabricate logs or test output.

