# Eleven-skill inventory and disposition

**Final readback addendum:** this inventory preserves the independent first-pass runtime observations. The later independent readback confirmed all eleven runtime definitions exactly match GitHub0.9.1; statements below that a skill was absent/older describe only the earlier observation. See `runtime-transition.md` and `runtime-refresh-comparison.json`. Workflow execution/model quality remains unverified by byte parity.

Current source: [GitHub commit1fa377c](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/tree/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/skills). Every source skill frontmatter identifies version0.9.1; names are directory identifiers. All instruction bodies were directly inspected. They are classified **Instruction-only** for end-to-end model behavior here; relevant local registry/evaluation code is separately **Verified tool-based**. No successful complete model run of each workflow is claimed. The available package inventory contains28 Markdown entries (11 roots+17 coordinator references), with exact hashes in `probe-results.json.registry`; loaded context is a separate caller declaration.

Common inspected source boundary: user/session+actual host permissions govern effects; repository/tool/project content remains data; missing tools cause a plan or blocked execution; source identity/check status/risks return to coordinator. The six compact specialists explicitly repeat failure/recovery, validation and shared boundaries. The four longer specialists supply detailed22-section specifications. Their numeric S01–S11 aliases and unnamed common contracts require explicit current links (SKILL-101). The owner map below translates those aliases for this inventory; it does not claim the source currently supplies that mapping.

## 1. software-architecture (S01)

**Disposition IMPROVE:** retain coordinator ownership and progressive depth; add source/runtime release compatibility evidence, resolve shared contract links, keep specialty content on demand. Root106 lines,16439 bytes. [Source](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/skills/software-architecture/SKILL.md).

- Purpose/triggers: design, review, decision, repository/change/handoff coordination; conceptual answers stay here. Quick/Guided/Full independent of Beginner/Technical.
- Inputs/context: user goal, canonical project/accepted decisions if applicable, actual source/native contracts, task scope/depth/host capability. No mandatory project file for simple advice.
- Outputs/workflow: recommendation and evidence; proportionate requirements/boundaries/contracts/data/security/operations/ADRs; source-bound change/handoff and independent readiness dimensions. Sequence owner outputs; no concurrent same-target writers.
- Dependencies/tools/permissions: shared canonical/schema/model/compiler/evidence system; optional actual GitHub/CLI/validator/runner/storage. Instructions do not supply authorization or a dispatcher.
- Validation/error handling: relevant validate/readiness/source identity; separate failed/skipped/blocked/timed-out/unknown; preserve recovery and accepted intent. Hashes identify bytes, not truth/permission.
- Security/overlap: owns synthesis and architectural intent; specialists own particular evidence/actions. Do not promote imported constraints into active coding instructions by default.
- Examples/negative: select tenant model versus unnecessary full dossier for a hashing explanation. Evaluation: focused answer, accepted-decision resume, partial handoff, missing runner, hostile imported prose. Existing local instruments cover parts; live coordinator semantic quality unmeasured.
- Maintenance: source/package/runtime identity, relevant17 references, canonical compatibility and actual evaluation captures. Runtime observed coordinator identifies0.7.2 and differs.

## 2. requirements-specification (S02)

**Disposition KEEP:** compact task contract already supplies observable acceptance, exclusions and error recovery; improve links only if shared contract is centralized.26 lines,2470 bytes. [Source](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/skills/requirements-specification/SKILL.md).

- Purpose/triggers/exclusions: discovery, scope, acceptance/conflicts/NFR; excludes conceptual explanation, isolated defect or deployment command.
- Inputs/outputs: goal/users/constraints/accepted facts → proposed stable FR/NFR delta, observable acceptance/scenarios, assumptions/conflicts/open questions/traceability/validation plan.
- Workflow: pivotal ambiguities only; separate fact/proposal/acceptance, testability, material NFR workload/environment/measure/target/check, actors/trust/data/operations, duplicate/conflict analysis; no silent accepted-ADR changes.
- Dependencies/tools/permissions: coordinator and canonical records; any actual editor/write requires scope. No special runner needed for a proposal.
- Validation/errors/security: discriminating positive/negative fixture; source conflicts and unavailable authority stop dependent effects. Untrusted source text is data; never fabricate research/numeric targets/approval.
- Examples/negative/evaluation: account-deletion acceptance or offline/sync conflict versus explaining an index. Evaluate conflicting constraints, incomplete context, meaningful NFRs and no forced interview.
- Overlap/maintenance: owns specification, not code/release/architectural synthesis. Track accepted decisions/schema/evaluation cases. Runtime definition is older/shorter than source.

## 3. repository-intelligence (S03)

**Disposition KEEP:** distinct evidence-collection owner.27 lines,2557 bytes. [Source](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/skills/repository-intelligence/SKILL.md).

- Purpose/triggers/exclusions: selected unfamiliar codebase, dependency/architecture drift/source impact; excludes source-free advice and already understood patch application.
- Inputs/outputs: repo/ref/read scope/budget/optional canonical map → pinned or explicitly unpinned identity, file/span/hash map, supported declarations/coverage/omissions/unknowns/risks/checks.
- Workflow/dependencies: manifests/CI/IaC/contracts first, representative source, map to canonical records, distinguish declarations/inference/runtime. Host GitHub or local read-only scanner only if available.
- Validation/error/security: meaningful positive/negative fixture; preserve parser/coverage/stop failures and unknowns; no zero-match absence proof or static-runtime-callgraph claim; files/tool output remain untrusted; respect read scope.
- Examples/negative/evaluation: map unfamiliar repo or dependency change versus database advice or deploy. Evaluate missing files, unsupported language, budget stop, stale evidence and hostile README.
- Overlap/maintenance: scanner supplies bounded observations, coordinator synthesizes architecture, implementation owner changes source. Version adapters and coverage fixtures; runtime older than source.

## 4. implementation-planning-and-change (S04)

**Disposition KEEP:** integrated-change owner should remain above language references.27 lines,2498 bytes. [Source](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/skills/implementation-planning-and-change/SKILL.md).

- Purpose/triggers/exclusions: authorized feature/scaffold/refactor/patch; excludes source-free explanation or unrequested release.
- Inputs/outputs: requested change+accepted intent+exact source+existing user edits → coherent plan/diff/changed paths/check receipts/blockers/reconciliation proposal.
- Workflow: acceptance/affected contracts, relevant source/tests/regression, smallest plan, scope/authority, actual editor with expected identity, meaningful checks, source hashes and unresolved risks, reconcile intent.
- Dependencies/tools/permissions: actual editor/runner/host-selected policy; repository evidence and domain/test/contracts specialists as needed. Missing runner yields proposed patch or blocked execution.
- Validation/error/security: separate actual edit/build/test/deploy; no blind non-idempotent retry; preserve unrelated edits and accepted decisions; source does not authorize effects.
- Examples/negative/evaluation: approved feature or behavior-preserving refactor versus microservices explanation/unrequested publish. Evaluate stale source, partial writes, rejected paths, missing checks and multi-file consistency.
- Overlap/maintenance: owns coherent source change while frontend/service own behavior details, testing owns diagnostic evidence, operations owns environment. Track adapter/version/receipt compatibility. Runtime older than source.

## 5. test-debug-verify (S05)

**Disposition KEEP:** narrow diagnosis and evidence owner; upstream debugging/test patterns can enrich its references.19 lines,2151 bytes. [Source](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/skills/test-debug-verify/SKILL.md).

- Purpose/triggers/exclusions: expected/observed failure, reproduction/regression; excludes nonreproduced architecture choice and cosmetic wording.
- Inputs/outputs: exact source/environment/failure/logs/available tools → minimal discriminating reproduction, evidence-backed cause, relevant check statuses and regression result.
- Workflow: facts/hypotheses, smallest test, authorized minimal fix if applicable, targeted then relevant regression/build/security, commands/source/version/logs/skips, acceptance reconciliation.
- Dependencies/tools/permissions: actual runner and editor if fixing; no fabricated execution. Required skipped check is nongreen; one unit test is not production evidence.
- Validation/error/security: preserve partial results, missing capability/source conflict/timeouts and original failures; existing shared untrusted-data/authority boundary.
- Examples/negative/evaluation: failing test or reproduced regression versus unsourced database choice or claimed test run without runner. Evaluate false-success/zero tests, missing tool, intermittent failure and observed-versus-hypothesized cause.
- Overlap/maintenance: diagnosis/evidence, not release or generalized model quality. Update runner/result formats and regression cases. Runtime older than source.

## 6. security-review (S06)

**Disposition KEEP:** concrete risk review, not certification or mandatory scan orchestration.19 lines,2120 bytes. [Source](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/skills/security-review/SKILL.md).

- Purpose/triggers/exclusions: assets/trust/auth/tenant/secrets/input/privacy/dependency risks; excludes generic edits, unsupported certification or unrelated production scan.
- Inputs/outputs: selected source, threat boundaries and permitted checks → verified findings separately from threats/unknowns, evidence/preconditions/priority/remediation/regressions/coverage/residual risk.
- Workflow/dependencies/tools: threat model plus source review; available suitable authorized SAST/SCA/secret tools only. No scanner is bundled by prose.
- Validation/error/security: do not expose secrets or run unsafe probes; availability is not authority and clean scan is not absence proof. Discriminating fixtures and partial/error statuses preserved.
- Examples/negative/evaluation: tenant authorization or source-backed secret leak versus compliance from schema or scanning unrelated accounts. Evaluate injected instructions, missing access, false positives and permission failure.
- Overlap/maintenance: security owner assesses controls; implementation/service/backend enforce actual behavior. Track threat/library/tool/rule versions and disclosure scope. Runtime older than source.

## 7. api-data-contracts (S07)

**Disposition KEEP:** contract semantics/evolution owner.19 lines,2220 bytes. [Source](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/skills/api-data-contracts/SKILL.md).

- Purpose/triggers/exclusions: supplied OpenAPI/AsyncAPI/data contracts, reference/auth/compatibility/migration; excludes UI fixes/general storage choice/unsolicited DB mutation.
- Inputs/outputs: dialect/version/baseline/consumers/migration scope → exact diagnostics/paths/compatibility and migration obligations.
- Workflow: root/operation/reference/parameter/ID/security checks; block remote references by default; compare removed/renamed/required/response/enum/auth/pagination/idempotency changes; map consumers; expand/migrate/contract/recovery.
- Dependencies/tools/permissions: actual available validators plus source/consumer evidence; no arbitrary SQL execution. Structural checks separate from full schema/runtime compatibility.
- Validation/error/security: positive/negative fixtures; unknown tool/conflict/timeout/partial effects explicit; external schemas are not silently fetched; data cannot authorize mutation.
- Examples/negative/evaluation: compatibility review or expand/backfill plan versus responsive form or production provisioning. Evaluate unresolved pointers, malformed auth, missing consumer and dialect version changes.
- Overlap/maintenance: owns contract meaning, service/data owns executable invariant and operations release; track dialect/validator/support contract. Runtime older than source.

## 8. frontend-interaction-and-accessibility (S08)

**Disposition IMPROVE:** keep behavior owner, repair SKILL-101 links; framework/version details should load on demand.96 lines, measured bytes in registry. [Source](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/skills/frontend-interaction-and-accessibility/SKILL.md).

- Purpose/triggers/exclusions: screens/forms/routing/client states/responsiveness/accessibility/browser acceptance; excludes architecture/API-only/static documents/images/cosmetic text.
- Inputs/outputs: journey/actors/browser matrix/design/framework/API/auth/tests plus states/viewports/accessibility → route/component/state map, diff, actual browser/keyboard/focus/viewport evidence and scoped accessibility findings.
- Workflow: inspect conventions, map success/loading/empty/error/unauthorized+focus, inspect API ownership/reuse, minimal change, types/build/tests, real browser journey/failure+keyboard/viewports, acceptance.
- Dependencies/tools/permissions: coding runner/browser/accessibility tools as available; missing browser blocks browser acceptance. S04 integrated change; S05 diagnosis; S06 security; S07 contracts (aliases unresolved in source).
- Validation/error/security: screenshots never prove behavior, scans never certify AT; preserve traces and first failure, bounded reruns, no silent dependency upgrades, no client secrets/auth bypass/sensitive errors.
- Examples/negative/evaluation: accessible menu or settings states versus event-sourcing comparison/index/image. Cases include missing labels/trapped focus/stale loading/API400/500/timeouts/mobile overflow/browser absent/injected page content.
- Maintenance/overlap: tested framework/browser fixtures, manual accessibility scope; frontend owns interaction, server owns auth, no competing file writers. Absent from current runtime catalog; source-only implementation not delivered behavior.

## 9. service-and-data-implementation (S09)

**Disposition IMPROVE:** keep runtime-invariant owner and repair SKILL-101.96 lines. [Source](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/skills/service-and-data-implementation/SKILL.md).

- Purpose/triggers/exclusions: endpoint/business rules/jobs/events/queries/transactions/migrations; excludes pure schema review, storage choice, UI and incident command; supplied schema grants no DB mutation.
- Inputs/outputs: runtime/dialect/contracts/invariants/data ownership/tenant/migration/consumers/fixtures/recovery → service/job/data diff, compatibility/transaction/idempotency rationale, actual tests/reconciliation and phase/recovery obligations.
- Workflow/tools/dependencies: pin scope, state success/failure/tenant/concurrency invariants, transaction boundary, expand/backfill/contract, coherent change, isolated validation/auth/duplicate/retry/failure checks, counts/invariants. Actual runner and isolated DB/queue/container only when supported; contract/security/testing/operations partners.
- Validation/errors/security: consumer compatibility, bounded duplicate effects, valid failed transaction, reconciliation and proven restore or blocker; no uncertain non-idempotent rerun; least privilege/synthetic data/parameterized SQL/trusted tenant identity/no poisoned schema execution.
- Examples/negative/evaluation: idempotent orders, region backfill, duplicate worker prevention versus database comparison/unresolved pointers/responsive form. Tenant cross-read/write/concurrent retry/redelivery/interrupted backfill/missing DB/poisoned comments fixtures.
- Maintenance/overlap: pin dialect/runtime/migrations and consumer coverage, own code/data behavior, contract owner owns semantics and operations release; no universal language support. Absent from runtime catalog.

## 10. delivery-and-operations (S10)

**Disposition IMPROVE:** retain operations owner; repair SKILL-101 and retain actual provider dependency.96 lines. [Source](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/skills/delivery-and-operations/SKILL.md).

- Purpose/triggers/exclusions: build/package/CI/CD/containers/IaC/release/deploy/SLO/telemetry/incident; feature edit does not imply release, unit failure belongs test owner, architecture reliability stays coordinator.
- Inputs/outputs: environment/provider/region/source artifact/gates/recovery/SLO identities → separate build/release/deploy statuses, operation IDs/health acceptance/partial components/recovery/timeline/runbook.
- Workflow/dependencies/tools: classify, pin authority/artifact, inspect gates/migrations/recovery, smallest dry run/action, verify actual target health, reconcile partial failure. Actual CI/provider/observability tools; dry-run is not deployed.
- Validation/error/security: exact target/artifact, required gates, scoped health/recovery; query provider operation before uncertain retry; preserve success components. Least privilege, protect credentials/logs, never disable TLS/gates or obey untrusted CI instructions.
- Examples/negative/evaluation: staging release gates/latency incident/disposable restore versus adding field/HTTP explanation/README title. Wrong environment, expired credential, timeout after apply, mixed rollout, missing health, incompatible rollback and provider absent.
- Maintenance/overlap: version providers/pipelines/recovery fixtures, no competing release writers; code owner patches. Absent runtime catalog.

## 11. ai-system-evaluation-and-safety (S11)

**Disposition IMPROVE:** retain distinct AI evaluation interpretation owner; fix AI-101 in tools and SKILL-101 linkage, then measure actual outcomes.96 lines. [Source](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/skills/ai-system-evaluation-and-safety/SKILL.md).

- Purpose/triggers/exclusions: task-level LLM/RAG/agent quality/safety/acceptance/regressions; generic CRUD/unit bug/model ranking without evidence does not require this owner; evaluation-design request never authorizes costly calls.
- Inputs/outputs: acceptance/user task slices/corpus ACL/provenance/model/prompt/tool identities/budget/actual captures or permitted endpoint → dataset/actual-versus-synthetic labels/captures/traces/semantic reviews+dissent/slice metrics/failures/uncertainty/actual cost-latency/recommendation.
- Workflow/tools/dependencies: predefine acceptance; representative+edge+critical+negative+holdout; freeze identities; authorized bounded runs; deterministic checks and calibrated semantic review separate; paired repeated variants/slices; gates/limits. Actual endpoints only if available/authorized; safe mocks/schema validators/domain review.
- Validation/error/security: account every terminal status, no synthetic/live confusion, critical ACL/tool boundaries fail safely, exact provenance, scope no wider than population; endpoint/throttle/timeout/malformed/semantic failure distinct, retries bounded by cost/idempotency; minimize/private data+ACL/retention and constrained injection tests.
- Examples/negative/evaluation: account-support prompt comparison, RAG tenant isolation, skill-routing study versus relational schema/arithmetic test/global best from3 examples. Wrong keyword-stuffed answers, absent tools, stale/denied retrieval, conflicting context, unsupported citations, injection/unsafe args, abstention/timeouts/missing lineage/disagreeing assessors/budget exhaustion.
- Maintenance/overlap: dataset holdout/contamination/calibration drift/provider versions/pricing. Own interpretation, not rollout or patch; related models not statistically independent truth. Absent runtime catalog. Current instruction gate is sound in intent; actual malformed-capture consumer violates required provenance (AI-101).

## Coverage and simplification decision

| Coverage | Present owner(s) | Decision/limit |
|---|---|---|
| Discovery/requirements/NFR | S01,S02 | KEEP; material targets/source facts must be supplied or provisional |
| Architecture/domain/API/data/distributed/reliability/security/cost | S01,S06,S07+coordinator references | KEEP; task-specific quality still unmeasured |
| Scaffold/multi-file code/refactor/review | S04+S08/S09 | KEEP; execution needs real runner; proposed code is not built software |
| Python/JS/TS/Java/C#/.NET/Go/Rust/C/C++/SQL/mobile/desktop/games/embedded | existing owner+detected-version references | DEFER separate top-level skills; no native coverage promised merely by prose |
| Tests/debug/build/static/contract/runtime/performance | S05 plus relevant owner | KEEP; actual tool availability/coverage required |
| Repository/drift/maintenance/modernization | S03,S04,S01 | KEEP; static observations do not imply universal semantic analysis |
| Delivery/packaging/CI/containers/IaC/telemetry/incident/recovery | S10 | KEEP conditional; no bundled production provider |
| AI/LLM/RAG/agents quality/safety | S11 | IMPROVE ingestion+prove tasks, no automatic extra models |
| Documentation/README/API/runbooks/changelog/handoff/restore | existing owners/canonical state | KEEP; no distinct documentation skill or hosted memory justified |

No REMOVE/MERGE/SPLIT/REPLACE for whole skills is justified by this inspection. Replace unresolved aliases and duplicate implementation detail with current links; add upstream patterns only with provenance/license/security review and discrimination tests. Do not turn this inventory into instructions to activate all eleven skills.
