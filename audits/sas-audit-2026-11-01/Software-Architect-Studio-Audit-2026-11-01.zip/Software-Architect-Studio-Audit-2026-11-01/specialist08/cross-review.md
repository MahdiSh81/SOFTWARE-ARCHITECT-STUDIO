# Specialist 08 — Cross-examination and final interpretation

Cross-review date: 2026-11-01. Reviewed specialist03/report.md, specialist03/probe-results.json, specialist07/report.md, current evaluation consumer source, github-skill-adoption.json and runtime-refresh/comparison.json. Independent first-pass report remains unchanged. No new target edits, installations or external service writes were performed in this cross-review.

## Findings challenged and reconciled

| Claim / objection | Counterevidence and resolution | Final verdict |
|---|---|---|
| CODE-101 executable-mode preservation is only a host limitation | The retained fixture shows ordinary executable 0755 changed to0600 after adapter apply returned passed; chmod alone does not change source_hash. The adapter itself chooses source replacement and identity semantics. Generic private-record IO intentionally uses0600, so globally changing safe_io defaults would weaken a separate control. | **Uphold P1.** Use a source-specific replacement path and versioned mode identity; preserve private-record defaults. Do not claim arbitrary metadata/OS parity. |
| A working three-file fixture establishes a real program-generation capability | The fixture source and tests were supplied by Specialist03, while the adapter applied and checked them. The same tools do not establish that Studio's model generates correct arbitrary programs. | **Uphold CODE-102 as a measurement gap**, separate Verified tool-based editing/checking from Unknown generated-program success rate. |
| CODE-103 can be fixed by merely adding tool_version to receipts | Existing receipts already identify studio.local0.9.1. The missing identity is the actual approved command/check specification, policy and executable/environment relevant to reproducing the result. A hash alone cannot reconstruct missing inputs or authenticate them. | **Uphold P2 with narrower specification.** Retain minimized trusted check identity, not raw secret-bearing policy. Query a tool version only through a known safe authorized command; do not automatically run an arbitrary repository executable with --version. |
| AI-101 is harmless because the field describes supplied review accounting | The consumer can return semantic_gate_passed=true with no actual prompt/response/lineage. Its scope disclaimer limits model-quality claims but does not make structurally absent required evidence valid. Conversely, schema validity cannot authenticate reviewers/calibration or establish model quality. | **Uphold P1 import-validation defect.** Validate before counting; keep accounting validity and actual semantic/task-quality evidence distinct. |
| SKILL-102 proves the currently exposed package remains stale | Root's later runtime-refresh/comparison.json contains all11 skill definitions and identical runtime/source hashes and byte counts. This is positive counterevidence to a final stale-definition claim. The initial7/0.7.2 observation remains historically true at the earlier boundary. No audit publication occurred, and release/backend cause is unknown. | **Reclassify as observed runtime transition, current definition parity confirmed.** Do not retain an open P1 stale-content conclusion. Definition parity still does not prove tools, scripts, references, provider connections or whole-package delivery parity. |
| Named permission lookup not_installed proves Studio is absent | My initial exact-name permission result was ambiguous; current successful reads of all11 definitions provide stronger positive availability evidence. Permission inspection has different identity/resolution semantics. | **Reject absence inference.** Keep backend/release identity mapping Unknown; no reinstallation or guessed plugin ID is justified. |

## GitHub programming-skill adoption review

The registry contains17 inspected candidates:10 ADAPT,2 REFERENCE ONLY,2 REFERENCE TECHNIQUE,1 DEFER,1 OPTIONAL REFERENCE and1 OPTIONAL ADAPTER. Each records an immutable commit/path, existing owner, proposed status and unverified behavioral gain. This is a coherent **adoption blueprint**, not17 installed skills or evidence of “best” measured performance.

I support mapping the practices into existing owners. The strongest choices connect directly to demonstrated audit needs: evidence-first debugging and completion; discriminating regressions; source-matched CI diagnosis; property/invariant testing of serialization, metadata and validators; source-grounded threats and risk-focused diffs. The registry correctly excludes forced agent chains, destructive restarts, unconditional latest-package installation, frontmatter-as-authority, forced approval interviews and mandatory tooling migrations.

Seven entries map to the frontend owner. Browser observation, interaction, console/trace evidence and capability preflight overlap across OpenAI, Anthropic and Microsoft references. Consolidate these into **one on-demand browser-verification reference with alternative tool mappings**, retaining primary-source attribution. Do not load three browser orchestration prompts together. React performance/composition remains a separate version-aware reference: a source pin preserves inspected text, not compatibility with the user's installed React/Next.js.

No extra top-level universal programming coordinator, automatic dispatcher, browser service or plugin-to-plugin bus follows from these files. Installation, existing skill exposure and allowed-tools frontmatter remain distinct from callable authorized runtime capability.

For content copied/adapted from MIT/Apache sources, preserve applicable attribution/license/notices and record modifications. Trail of Bits entries are appropriately reference-technique candidates under the inspected CC-BY-SA4.0 declaration. A separate directory alone does not establish license compliance for a derivative; decide the actual derivative/content boundary before packaging. No copyrighted upstream content was installed by this audit.

## Acceptance additions

1. **Mode/check provenance:** detect chmod-only source changes; preserve0755 and0644 source behavior while private records remain0600; same-named different approved commands must have distinct check identities; credentials do not enter receipts.
2. **Capture ingestion:** reject malformed imported captures before semantic accounting in both core-only and optional-validator environments; valid unknown model identity remains representable; no reviewer-authenticity claim is introduced.
3. **Runtime evidence:** retain both observation snapshots and timestamps; current11 definition hashes match GitHub. Explicitly state which references/scripts/tool operations were inspected or executed rather than infer whole-package parity.
4. **Adoption:** resolve existing owner, exact source/version/license and host tool before loading a reference. An unavailable browser/CI/provider tool produces blocked/manual evidence, not installation. One owner controls writes.
5. **Evaluation:** compare held-out actual tasks with the same model/tools/budgets; set required outcomes before evaluation; failed/blocked outcomes and correction burden remain visible. No benefit is inferred from candidate count or lexical fixtures.
6. **Release:** INT-101 remains an independently demonstrated P1 until a revised commit's workflow parses and its actual GitHub jobs finish. Local passes cannot supersede that remote evidence.

## Final verdict and remaining dissent

Support the minimal existing-owner adoption plan and retain confirmed correctness fixes ahead of expansion. No disagreement remains about the source-specific executable regression, capture validation gap or remote CI failure. I disagree with carrying the initial runtime/source mismatch forward as a current stale-definition defect after the later11/11 matching observation.

The user's separately authorized Google Doc delivery is a report artifact operation outside the read-only investigation's source/plugin boundary. It does not imply permission to publish a plugin, edit GitHub source, install candidates or change app access.

