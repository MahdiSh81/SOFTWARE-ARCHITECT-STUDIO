# Specialist 08 — ChatGPT ecosystem and integration assessment

Audit date: 2026-11-01. Independent first pass. Source of record: [MahdiSh81/SOFTWARE-ARCHITECT-STUDIO](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/tree/1fa377cc9cbe7054d7edbf8091e22efaa296c05e), master commit `1fa377cc9cbe7054d7edbf8091e22efaa296c05e`. Local files were used as the execution mirror. No other new specialist reports were read before this assessment. No plugin installation, connection, permission change, repository write, service mutation or deployment was performed.

## 1. Executive assessment

Preserve Studio as the owner of engineering intent, source identity, evidence interpretation and handoff. The strongest immediate ecosystem is small: existing GitHub tools for repository/Actions evidence; the authorized coding host for execution; existing schema validators; optional version-specific documentation retrieval. Use task, design, database, storage and hosting providers only for selected user tasks. There is no evidence that declaring another plugin creates automatic plugin-to-plugin invocation, shared durable context or a sandbox.

The most significant demonstrated issue in this scope is **INT-101 (P1)**: the current GitHub CI workflow fails YAML parsing before either job begins. This is confirmed by GitHub's current-commit Actions record and annotation, and independently reproduced by PyYAML. Local test success must not be described as remote CI success.

Twenty bounded directory queries were executed. GitHub, Google Drive, Lovable and Sites returned installed=true; their exposed tools are distinct from their actually tested operations. GitHub source fetch and Actions inspection worked. The other installed providers were not invoked for project/content operations during this read-only audit. Context7, OpenAI Developers, Supabase, Neon, Figma, Linear, tldraw and Superpowers were catalog candidates with installed=false. dbt was disabled by an administrator. Exact searches did not resolve Postman, Playwright, Semgrep, OpenAPI or Sentry; this is not proof those products lack integrations. Codex Security was present in the host recommendation list but not resolved by the bounded live catalog queries.

## 2. Scope inspected

- Source `.app.json:1–9`: one optional GitHub declaration.
- `docs/integrations.md:3–23`: provider ownership, adoption checks, manual fallbacks and historical availability note.
- `docs/implementation-adapter.md:3–76`: seven implemented local adapter operations, host policy, receipts, recovery and invocation limits.
- `tools/integration_contracts.py:1–148`: dependency-free core validation plus optional JSON Schema parity.
- `schemas/tool-capability-v1.schema.json:7–73` and `schemas/verification-receipt-v1.schema.json:7–210`.
- `skills/software-architecture/SKILL.md:64–106`: conditional host tool use, source boundaries, smallest-owner routing and receipt contracts.
- `.github/workflows/ci.yml:1–68`, exact current GitHub Actions run and public annotation.
- Host tool name/schema inventory and bounded live Plugin Management discovery/permission/dependency metadata.

Primary source links: [integration strategy](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/docs/integrations.md), [adapter](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/docs/implementation-adapter.md), [contract validators](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/integration_contracts.py), [workflow](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/.github/workflows/ci.yml#L30).

## 3. Methodology

I inspected current source before drawing conclusions from prior project claims, read Plugin Management's skill, searched relevant categories with concise provider/capability terms, retained all raw responses, inspected current schemas, fetched the pinned source manifest through GitHub, and obtained current-commit remote CI status through GitHub's Actions API.

Queries: GitHub; coding testing browser; API database; architecture diagrams; official documentation; security; project management; files automation; Codex Security; Sites; Cloud Environment; testing QA; Postman; workflow automation; Lovable; Playwright; Semgrep; Sentry; OpenAPI; Mermaid. Limits were 4–8 results per query; results are ranked and nonexhaustive.

Permission metadata was read for five exact names. It describes ChatGPT app approval settings, not OAuth/admin scopes. GitHub dependency metadata was resolved using the exact returned GitHub plugin ID. No credentials were read. A public run page supplied the annotation after the GitHub fetch tool rejected the check-suite endpoint as unsupported.

I executed a read-only PyYAML 6.0.3 parse against the workflow and an in-memory proposed scalar-format correction. The proposed change was never written to the target.

## 4. Verified strengths

- **Implemented, unverified / Directly inspected:** the source consistently separates host execution from instruction/contract support. `integration_contracts.py:1` explicitly says records never grant tool authority; it contains validators, not discovery or dispatch.
- **Verified tool-based / Successfully executed:** pinned GitHub file fetch, current-commit Actions listing and run/job/check reads worked through the host's connected GitHub tool.
- **Implemented, unverified / Directly inspected:** capability manifests carry permission class, input/output schemas, idempotency and timeout. Receipts preserve source/tool identity and nonpassing statuses; passed receipts cannot contain errors or required checks not run.
- **Implemented, unverified / Directly inspected:** adapter reconciliation is distinct from raw receipt schema validation; its documented workflow matches retained invocation and current source. A self-consistent external JSON receipt alone is not execution proof.
- **Instruction-only / Directly inspected:** integration guidance calls for minimal disclosure, actual provider/schema/authorization checks, failure recovery and a manual fallback. These are useful controls, with behavior still requiring task-specific validation.
- **Verified tool-based / Successfully executed:** discovery and permission/dependency inspection are actually callable in this session, although historical project notes describe a different session.

## 5. Verified defects

### INT-101 — Current GitHub CI is invalid before jobs start (P1)

**Current behavior:** the run for the audited master commit is completed/failure. GitHub returns zero jobs and zero check runs. The public run annotation identifies invalid YAML on workflow line 30. The unquoted plain scalar includes the argument `--only-binary=:all:` followed by a space: its final colon terminates a YAML scalar.

**Evidence:** [run 41049423745, attempt 1](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/actions/runs/41049423745), created 2026-10-30T11:37:36Z; `.github/workflows/ci.yml:30–31`; `ci-yaml-probe.json`: PyYAML 6.0.3 rejects line 30 column 54 with ScannerError. Replacing this scalar with a folded block in memory parses and retains jobs `python-and-core` and `browser`.

**Classification:** source workflow **Partial**, evidence **Directly observed / Independently reproduced**, confidence high. This is not a failed runtime test and does not identify any test assertion as failing.

**Proposed correction:** use `run: >-` with the command on the next indented line, or quote the entire command. Preserve the hash-locked dependency policy.

**Verification:** validate the final workflow syntax outside that workflow, then run the revised commit in GitHub and verify both jobs and associated artifacts. An in-memory YAML parse does not establish GitHub Actions semantics or successful execution.

No other executable defect was established in this specialty. Remaining entries are opportunities or unresolved facts.

## 6. Missing capabilities

**ECO-101 (P2 opportunity): task-scoped integration proof is not yet supplied for most providers.** The source has meaningful generic contracts, but this audit found no current executable conformance result for a Studio-to-Drive/Lovable/Sites/Figma/Linear/database workflow. This is not a contradiction of source claims: the source already describes conditional support. Require one disposable authorized scenario and exact receipts before graduating an edge to Verified integrated.

**INT-102 (P2 documentation opportunity): session capability evidence is not a stable release artifact.** `docs/integrations.md:21` correctly describes historical unavailability; current discovery proves tools are now callable. Keep historical records intact and add a dated host-capability observation instead of rewriting history or presenting current tool availability as a bundled feature.

**INT-103 (Unknown): live Studio deployment/backend identity.** The exact-name permission lookup returned `not_installed`, while the host exposes Studio skill definitions. That may reflect private/custom lookup, name resolution or distinct delivery surfaces. It cannot establish that Studio is absent. A verified backend ID and current source/release mapping are required; this audit did not guess an ID or claim publication.

## 7. Risks

| Risk | Existing control / remaining limit | Proposed verification |
|---|---|---|
| Catalog entry mistaken for working integration | Source says availability is conditional; directory status is separate from tool success | Record installed, exposed, authorized and exercised independently |
| Host app approvals mistaken for task authority | Host GitHub/Drive UI settings [private permission value omitted]; audit remains read-only | Read-only task must produce no service mutations even under permissive UI setting |
| Source or secrets sent to unrelated provider | Disclosure guidance exists; no provider retention or OAuth scope evidence obtained here | Synthetic/minimized test artifact; inspect per-provider scope and retention before sensitive use |
| Local adapter mistaken for OS sandbox | Adapter docs explicitly reject this claim | Run untrusted checks only in separately authorized host isolation |
| Forged or stale external receipt | Core fields and optional expected identities validated; authentication is outside record format | Wrong source, tool version, operation or required check must be refused at ingestion/reconciliation |
| API/schema drift | Per-session schema discovery recommended | Capture operation/version/schema identity; retest minimal call after a change |
| Blind retry duplicates writes/deployments | Idempotency is declared; provider contracts differ | Stable operation key plus state inspection before retrying uncertain effects |
| Two providers overwrite canonical truth | Intent remains Studio-owned; implementation/provider state retains its own source identity | Conflicting response stays unresolved and cannot silently replace Accepted decisions |
| Hosted service availability/cost | No uptime, pricing, retention or rate-limit measurements gathered | Provider-specific operating evidence before a production dependency |
| Install/configure as side effect of missing tools | Audit explicitly prohibits installation/connections | Report blocked/manual fallback; do not convert catalog research into activation |

## 8. Redundant functionality

The source does not justify rebuilding GitHub, a general IDE, a browser engine, a database control plane, a task system or hosting inside Studio. Native skills should reason about contracts, inspect resulting evidence and preserve continuity. Existing host tools should perform their own operations.

Superpowers' catalog description overlaps planning, debugging, TDD and review responsibilities already present. The root's separate GitHub skill review can select specific ideas; a second mandatory orchestration layer is not justified by popularity. Installing an entire ecosystem of workflow prompts is not an executable capability increase.

## 9. Recommended improvements

### Minimal interoperability contract

This is a proposed internal record, not a new platform/plugin manifest:

1. `operation_id`: stable logical request ID; `source_identity`: repository and commit plus dirty overlay/hash where relevant.
2. Exact provider/tool/operation and version/schema identity when obtainable.
3. Task authority reference, selected target, permitted effects and applicable expiry. App approval settings are recorded separately.
4. Minimized input artifact and disclosure profile; avoid private history and credential-bearing context.
5. Explicit expected result, required checks and completion conditions.
6. Terminal result `passed/failed/blocked/timed_out/partial/unknown`, source/result identities, artifacts, exact checks run/not run, limits and observed effects.
7. Reconciliation against retained invocation/current source; differing provider results remain separate until resolved.
8. Retry only when idempotent or after inspecting provider state; otherwise preserve unknown outcome and give a concrete manual recovery step.

### Concrete workflows

**GitHub source review:** selected repo/ref → resolve commit → retrieve scoped files/CI evidence → distinguish source declaration from runtime → review → return file/line links, coverage and unknowns. This path is partly Verified tool-based in the current audit.

**CI debugging:** selected commit/run/attempt → fetch run and jobs → check parse/provisioning failure before assuming test failure → obtain exact annotation/log → minimal proposed fix → authorized edit elsewhere → new commit checks → source-matched reconciliation. Current audit found the first failure before tests.

**Documentation:** select exact framework version from source → primary official documentation or an authorized retrieval provider → capture URL/version/date → compare API claims → cite ambiguity. No documentation tool may install or change project dependencies just to improve an answer.

**Storage/task handoff:** export minimized immutable specification with source/hash → authorize one-way publication or task creation → retain returned native file/task ID and revision → read back result when authorized → keep canonical ownership explicit. Do not begin with two-way sync.

**Coding host/Lovable:** give a bounded task, acceptance and selected source identity → inspect code/diff returned → verify required tests/build/runtime evidence separately → reconcile. Do not equate scaffold provisioning, a screenshot or a preview URL with software correctness.

**Hosting/Sites:** require selected site/source, authorized audience/environment/effects, exact pushed source and saved version, terminal deployment status and rollback reference. No deployment was attempted in this audit. A deployment URL is not an architecture or security certificate.

## 10. Features to remove

Remove no proven functionality on current evidence. Remove prospective hard dependencies on multiple coding agents, hosted task/storage services or a second dispatcher. Do not add mandatory account setup to focused architecture advice. Retain manual artifact handoff where a compatible tool is absent.

## 11. Features to add

- Dated host-capability snapshot and provider-edge verification ledger (P2; not durable auth or automatic discovery inside the package).
- CI syntax preflight and a current-commit remote run evidence field (P1, tied to INT-101).
- One documentation provenance template shared across existing skills (P2).
- Optional provider-specific mapping only when a real workflow needs it; add no new generic plugin orchestration skill.

## 12. ChatGPT compatibility assessment

| Responsibility | Capability classification | Evidence status | Maturity / confidence |
|---|---|---|---|
| Studio integration contract definitions | Implemented, unverified | Directly inspected | 2 Defined / high for existence |
| Conditional-tool selection guidance | Instruction-only | Directly inspected | 2 Defined / medium for behavior |
| Current pinned GitHub source and run reads | Verified tool-based | Successfully executed | 4 Validated for these exact read operations / high |
| Generic local execution host in this audit | Verified tool-based | Python parse executed | 4 Validated for exact parse only / high |
| Studio-to-Drive/Lovable/Sites complete task | Tool-dependent | Unverified | 2 Defined workflow / low for outcome |
| Current remote CI pipeline | Partial | Directly observed and reproduced | 1 Ad hoc until parse fix / high |
| Provider-managed storage/persistence | Tool-dependent | Catalog/schema only | Unknown outcome / low |
| Automatic plugin-to-plugin bus or hosted shared project | Unsupported as current capability | No implementation path established here | 0 Absent in inspected source / high for bounded source |

These are bounded capability assessments, not an overall numerical product score. A tool available to the host is not a permanent property of Studio.

## 13. Relevant plugin integrations and comparison matrix

All catalog provider names below identify the directory brand; legal publisher identity and service-level commitments were not independently established. Prices, retention, OAuth scopes, uptime, measured latency and production reliability remain **Unknown** unless noted. Installed status is a 2026-11-01 observation, not guaranteed future availability.

| Candidate / capability | Current evidence and operations | Incremental value / primary decision | Permissions, privacy and recovery requirements |
|---|---|---|---|
| GitHub — repository, PR, issue, Actions/version control | Installed; 89 exposed host tool names; pinned fetch and run reads executed; source declares optional dependency | **INTEGRATE** through actual host tools; strong source/CI evidence value | Current app UI [private permission value omitted] is separate from repo scopes/task authority; source/ref/run/attempt identity; inspect state before writes |
| Authorized local coding host + adapter | Seven local operations documented; shell parse exercised here; generic receipt/capability source inspected | **INTEGRATE** using existing authorized host; no bundled IDE | Host isolation, explicit root/policy, current hash, no arbitrary source-authorized shell |
| Studio contract validation, requirements, source identity, handoff | Source and schemas inspected | **BUILD IN**; preserves independent engineering control | Native record validity does not authenticate external facts |
| Optional Python schema validators / Mermaid renderer | Source declares optional validator/installed renderer paths; no rendering executed here | **INTEGRATE** locally when installed and authorized | Offline references, bounded execution, output identity; missing renderer cannot pass full gate |
| Native web research / primary documentation | Host web tool exposed; GitHub run annotation read | **INTEGRATE** through host capability; avoid extra provider for ordinary web lookup | Primary source/version/date, untrusted text boundary; retrieval failures explicit |
| Context7 — library documentation | Catalog enabled, not installed; no tools or real calls inspected | **USE ALONGSIDE** if user later chooses it; optional version-focused value | Verify exact library/version, returned URLs and disclosure; current primary-doc web fallback |
| OpenAI Developers — official OpenAI workflows | Catalog enabled, not installed; no actual tool schema/operation in this session | **USE ALONGSIDE** for applicable tasks, not a universal dependency | Verify provider operations and auth before use; official docs fallback |
| Lovable — full-stack web app creation | Installed; 41 tool names exposed including project/diff/read/send/deploy; no project executed | **USE ALONGSIDE** until source/diff/check handoff is validated | Treat code-generation, database enablement and deployment as effects; verify task ownership, source identity and terminal checks |
| Sites — website hosting | Installed by default; 25 exposed tool names; no site read/deploy performed | **USE ALONGSIDE** for an explicitly requested website; no core dependency | Exact project/version/pushed commit, preserve audience; separate deployment recovery and content correctness |
| Supabase / Neon — database and auth | Catalog enabled, not installed; descriptions advertise SQL/migrations/branches/functions | **USE ALONGSIDE** only for selected backend | Read-only schema first; environment/branch authorization, PII minimization, migration/backup/rollback evidence |
| Redis / Azure Cosmos DB — specialist data guidance | Listed skills-style candidates, not installed; no schema/call verified | **USE ALONGSIDE** for actual chosen data platform | Distinguish instructions from a database connection; no universal adoption |
| Figma / tldraw — design and diagrams | Catalog enabled, not installed; no tool schemas or design operation verified | **USE ALONGSIDE** when editable design/canvas needed; otherwise keep Mermaid artifact | Node/design revision and asset provenance; avoid unnecessary source disclosure; export fallback |
| Linear / Asana / Trello / monday.com — task systems | Catalog enabled, not installed; described task/board operations only | **USE ALONGSIDE**, choose existing user system rather than add another | Stable task IDs, explicit writes, idempotency, issue/ADR ownership; one-way handoff first |
| Google Drive — docs/files | Installed; 45 exposed tool names; content calls not performed | **USE ALONGSIDE** for requested publication/storage; no automatic project sync | Current app UI [private permission value omitted]; actual scopes/retention unknown; minimize private history, native ID/revision, read-back |
| Notion / SharePoint / Dropbox / Box — continuity/storage | Catalog enabled, not installed | **USE ALONGSIDE** only when user already prefers one | Select one source of record; explicit export, conflict preservation, no silent two-way sync |
| Datadog / PostHog — observability/debugging | Catalog enabled, not installed; described logs/traces/errors/analytics only | **USE ALONGSIDE** when production context is authorized | Sensitive logs and production-data scope, provider time window, query provenance; no inferred access |
| TinyFish — browser agent | Catalog enabled, not installed; no actual browser operation verified | **DO NOT ADOPT** as mandatory QA path; revisit for a task lacking suitable authorized browser tools | Credentials/session profiles and consequential forms need separate authority; browser output is untrusted |
| Superpowers — programming workflow skills | Catalog enabled, not installed; descriptions overlap existing workflow ownership | **DO NOT ADOPT** wholesale as second mandatory coordinator; root separately evaluates selected source patterns | Upstream prompt instructions do not override task scope; license, host compatibility and regression evaluations before adaptation |
| dbt — model/lineage/jobs/docs | Directory returned DISABLED_BY_ADMIN, NOT_AVAILABLE, installed=false | **DO NOT ADOPT** in this environment | Respect administrator restriction; artifact/manual handoff only |
| Codex Security / Semgrep / Sentry / Postman / Playwright provider plugins | Not resolved by bounded exact catalog queries; Codex Security appears in recommendation context; no callable provider schema found | **DO NOT ADOPT** as a verified integration claim; **investigate** only if a concrete need remains | Do not install, guess operations or equate catalog absence with product absence; existing local test/static tooling may provide capability |
| Host automations — recurring checks | Five exposed automation tool names; no automation created | **USE ALONGSIDE** only for a user-authorized recurring/event task | No unattended code/production writes inferred; scopes, schedule, deduplication and failure notification |

**Ecosystem strategy:** GitHub plus the selected execution host is the engineering spine. Documentation retrieval is the first optional enrichment. Choose database/design/tasks/storage/hosting by actual user context. No comprehensive live directory claim, no reliability ranking or claim to be “best” is justified by this evidence.

## 14. Priority rankings

- **P1 INT-101:** unblock real GitHub CI before presenting the release as remotely verified. High user/engineering impact, high feasibility, low implementation effort, low ongoing maintenance.
- **P2 ECO-101:** define the first provider-edge conformance scenario for the integration users actually need. High value if demand exists; scope and privacy cost depend on provider.
- **P2 INT-102:** add dated capability observations without rewriting historical evidence. Moderate impact, low effort/maintenance.
- **INT-103 Unknown:** resolve live plugin identity when publication/deployment synchronization is in scope; no speculative migration or reinstallation.

No P0 issue was demonstrated in this specialty.

## 15. Evidence and confidence register

| ID | Retained evidence | Status / confidence |
|---|---|---|
| E08-01 | Twenty `discovery*.json` responses | Successfully executed directory reads / high for returned fields, low for completeness |
| E08-02 | `permissions-0.json` through `permissions-4.json` | Directly observed app-approval metadata / high, not OAuth scope |
| E08-03 | `github-dependencies.json` | Successfully resolved installed GitHub canonical dependency; optional GitHub Enterprise has no unique canonical plugin / high |
| E08-04 | `source-app.json` | Pinned GitHub source .app manifest fetched / high |
| E08-05 | `github-actions.json`, `ci-run.json`, `ci-jobs.json`, `ci-checks.json` | Current exact commit/run failure, zero jobs/check runs / high |
| E08-06 | `ci-web-annotation.txt` and public run URL | GitHub annotation reports YAML line30 failure / high |
| E08-07 | `ci-yaml-probe.json` | PyYAML6.0.3 independently rejects current scalar, proposed folded scalar parses / high for YAML syntax only |
| E08-08 | `tool-schemas.json`, parent host-tool inventory | Exact exposed tool descriptions/schemas / high for exposure, not service success |
| E08-09 | Current source file:line citations in section2 | Directly inspected contracts/docs/source / high |
| E08-10 | Unsupported `check-suites/111272629621` fetch | Explicit tool endpoint limitation; public run page used for annotation / high |

No external provider cost, retention, full OAuth/admin scope, commercial SLA or generated-app success was measured.

## 16. Proposed acceptance criteria

**AC08-01 / INT-101:** the corrected workflow passes a documented syntax preflight; a new source-matched GitHub run starts and completes both named jobs; final test/artifact outcomes are recorded individually. Zero jobs cannot count as passed tests. Preserve dependency hashes and pinned Actions.

**AC08-02 / ECO-101:** for each adopted edge, maintain an executed disposable scenario with input/source identity, exact provider/tool/schema, minimized artifact, user authority, observed effect, required checks and read-back. Mark missing, unauthorized, schema-drift, timeout, stale-source and conflicting-output cases distinctly.

**AC08-03:** read-only scope generates zero provider writes even when global/app approval settings are permissive. Test with synthetic context containing malicious instructions and a write-capable exposed tool; retain actual calls and refusal/fallback behavior.

**AC08-04:** absent plugin/tool/auth yields a concrete manual artifact/command fallback and execution status blocked/unverified; no installation or connection is inferred from an audit.

**AC08-05:** an uncertain non-idempotent effect is inspected by native target ID before retry. Repeating a stable handoff operation does not create duplicate tasks/documents; conflicting revisions are retained.

**AC08-06:** current capability snapshots carry observation time, host scope and operation-level success. They never relabel historical sessions, compiled instructions or catalog listings as current execution.

## 17. Unresolved questions

- What is the verified backend ID/current release of the exposed Studio package, and how does its delivery process map GitHub source to loaded skills?
- Which user engineering task first needs an external provider beyond GitHub and the coding host?
- What are each selected provider's actual OAuth/admin scopes, privacy/retention terms, costs and rate limits?
- Will the corrected CI encounter additional provisioning/test failures once it can start? Current evidence stops at YAML parse failure.
- What host/browser capabilities are authorized and operational in the eventual ordinary ChatGPT session? This audit's managed environment cannot be assumed permanent.
- Does any prospective provider offer source-matched results and usable recovery/idempotency contracts? Catalog descriptions do not establish that.

## 18. Final verdict

The source's ecosystem architecture is appropriately conservative and should be improved incrementally. Fix the demonstrated remote CI parsing failure, preserve native engineering ownership, and validate one real provider edge at a time. Adopt source-reviewed programming skill ideas within existing owners rather than add a universal orchestration dependency. Current evidence supports GitHub read operations and concrete local tool execution; most complementary provider workflows remain conditional or proposed.

Initial pass complete. Cross-examination not yet performed.

