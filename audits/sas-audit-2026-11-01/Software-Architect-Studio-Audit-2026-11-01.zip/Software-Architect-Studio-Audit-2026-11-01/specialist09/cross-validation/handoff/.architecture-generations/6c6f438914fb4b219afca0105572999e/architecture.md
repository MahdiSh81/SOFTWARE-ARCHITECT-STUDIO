# Atlas SaaS — architecture

Revision 1; canonical input SHA-256 923bd6ec83536acbc9c4d65acdbebffacf4627d42038f9717ae5a21d72bba8e0; projection SHA-256 d096428bdc01b37318455d145bd2c0337b398f1aa2f1f01cec98da0e99271645. Design intent; not deployed behavior.

## Brief
Small multi-tenant business application; proposed design only.

## Constraints
- Five developers
- Low operating budget
- Tenant data must be isolated

## Components
- web-api: Application API — Serve authorized requests
- database: PostgreSQL — Store tenant-scoped records

## Open questions
- Does the customer need EU data residency?
- What are peak request rates?