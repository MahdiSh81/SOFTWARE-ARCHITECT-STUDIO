# Data models (proposal)

- **DATA-001** Tenant records

```json
{
  "components": [
    "database"
  ],
  "id": "DATA-001",
  "name": "Tenant records",
  "requirements": [
    "FR-001"
  ],
  "tables": [
    "records",
    "tenants"
  ]
}
```
- **DATA-002** Audit events

```json
{
  "components": [
    "database"
  ],
  "id": "DATA-002",
  "name": "Audit events",
  "requirements": [
    "FR-002"
  ],
  "tables": [
    "audit_events"
  ]
}
```