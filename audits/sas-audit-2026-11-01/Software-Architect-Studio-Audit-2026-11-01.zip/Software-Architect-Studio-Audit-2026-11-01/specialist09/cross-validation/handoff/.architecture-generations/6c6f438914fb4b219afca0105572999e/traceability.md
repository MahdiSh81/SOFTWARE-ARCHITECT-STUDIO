# Traceability

{
  "functional_requirements": 2,
  "nfr_requirements": 1,
  "nfr_without_passed_verification": [
    "NFR-001"
  ],
  "review_note": "Links and plans do not prove satisfaction; applicability and measured verification require review.",
  "without_declared_component": [],
  "without_declared_interface": [],
  "without_declared_task": [
    "FR-002"
  ]
}
