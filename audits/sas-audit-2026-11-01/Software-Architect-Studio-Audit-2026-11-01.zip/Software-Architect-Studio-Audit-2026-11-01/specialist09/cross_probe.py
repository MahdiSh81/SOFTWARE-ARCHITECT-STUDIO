import json, pathlib, sys
sys.dont_write_bytecode=True
sys.path.insert(0,'/workspace/SOFTWARE-ARCHITECT-STUDIO/tools')
from artifact_compiler import handoff,resolve_generation,recover_handoff
from validation_engine import validate
root=pathlib.Path(__file__).parent/'cross-validation'; root.mkdir()
project=root/'project'; project.mkdir()
(project/'project.json').write_bytes(pathlib.Path('/workspace/SOFTWARE-ARCHITECT-STUDIO/tests/fixtures/rich-project.json').read_bytes())
output=root/'handoff';handoff(project,output)
generation=resolve_generation(output)
baseline=validate(output,gate='structural')
(generation/'api.json').unlink()
missing=validate(output,gate='structural')
try:recovery={'result':recover_handoff(output)}
except Exception as exc:recovery={'type':type(exc).__name__,'message':str(exc)}
asyncapi=root/'asyncapi.json';asyncapi.write_text(json.dumps({'asyncapi':'bogus','info':{},'channels':{}}))
asyncresult=validate(asyncapi,gate='full')
result={'baseline_structural_policy_ok':baseline['policy_ok'],'missing_api_structural_policy_ok':missing['policy_ok'],'recover_missing_api':recovery,'invalid_asyncapi_full_policy_ok':asyncresult['policy_ok'],'asyncapi_checks':asyncresult['checks']}
(root/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
