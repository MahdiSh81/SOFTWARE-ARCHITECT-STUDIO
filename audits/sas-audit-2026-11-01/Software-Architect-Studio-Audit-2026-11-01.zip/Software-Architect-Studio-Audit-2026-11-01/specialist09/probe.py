"""Synthetic operational probes; no target-source mutation."""
import json, os, pathlib, subprocess, sys, threading, time
sys.dont_write_bytecode=True
SOURCE=pathlib.Path('/workspace/SOFTWARE-ARCHITECT-STUDIO')
sys.path.insert(0,str(SOURCE/'tools'))
import revision_store as rs
import execution_adapter as ea
from safe_io import digest

ROOT=pathlib.Path(__file__).parent
results={}

# Simulate an abrupt exit immediately after a real prepared revision journal write.
project=ROOT/'crash-project'
rs.init_project(project,'Crash baseline')
crasher='''import os,sys
sys.dont_write_bytecode=True
sys.path.insert(0,sys.argv[1])
import revision_store as rs
from safe_io import digest
from pathlib import Path
root=Path(sys.argv[2]);p=rs.load_project(root);p['name']='Crash proposed'
original=rs.atomic_write
def interrupted(path,data,*args,**kwargs):
    original(path,data,*args,**kwargs)
    if Path(path).name=='.architecture-journal.json':os._exit(91)
rs.atomic_write=interrupted
old=rs.load_project(root)
rs.commit_project(root,p,'Crash probe',digest(old))
'''
proc=subprocess.run([sys.executable,'-B','-c',crasher,str(SOURCE/'tools'),str(project)],capture_output=True,text=True)
crash={'exit_code':proc.returncode,'lock_exists':(project/'.architecture.lock').exists(),'journal_status':rs.read_json(project/'.architecture-journal.json')['status'],'revision_before_recovery':rs.load_project(project)['revision']}
try:crash['recover_result']=rs.recover(project)
except Exception as exc:crash['recover_error']={'type':type(exc).__name__,'message':str(exc)}
# Controlled scratch cleanup proves that the valid journal is recoverable once lock is handled.
(project/'.architecture.lock').unlink()
crash['manual_scratch_unlock_recovery']=rs.recover(project)
crash['revision_after_manual_unlock']=rs.load_project(project)['revision']
results['abrupt_exit_stale_lock']=crash

# Two explicitly authorized cooperating adapter operations change A -> B -> A while a check runs.
workspace=ROOT/'aba-workspace';workspace.mkdir()
(workspace/'value.txt').write_text('A')
(workspace/'check.py').write_text("import pathlib,time\ntime.sleep(.3)\nv=pathlib.Path('value.txt').read_text()\nprint('OBSERVED='+v,flush=True)\ntime.sleep(.5)\nassert v=='B', 'check requires B but read '+v\n")
state=ROOT/'aba-state'
policy={'schema_version':1,'root':str(workspace),'authorization_reference':'synthetic-audit-probe','allow_write':True,'allowed_paths':['value.txt'],'allow_checks':True,'include_output':True,'checks':{'value-check':{'kind':'command','argv':[sys.executable,'-B','check.py'],'timeout_seconds':2}}}
identity=ea.inspect(workspace)['source_hash']
control=ea.run_checks(workspace,['value-check'],policy,expected_source_hash=identity,operation_id='control-aa',state_root=state)
holder={}
def check():
    try:holder['receipt']=ea.run_checks(workspace,['value-check'],policy,expected_source_hash=identity,operation_id='overlap-aa',state_root=state)
    except Exception as exc:holder['error']={'type':type(exc).__name__,'message':str(exc)}
thread=threading.Thread(target=check);thread.start()
time.sleep(.12)
plan_b=ea.propose_change(workspace,[{'path':'value.txt','content':'B'}],expected_source_hash=identity)
apply_b=ea.apply_change(workspace,plan_b,policy,operation_id='apply-bb',state_root=state)
time.sleep(.35)
plan_a=ea.propose_change(workspace,[{'path':'value.txt','content':'A'}],expected_source_hash=ea.inspect(workspace)['source_hash'])
apply_a=ea.apply_change(workspace,plan_a,policy,operation_id='apply-aa',state_root=state)
thread.join()
receipt=holder.get('receipt')
results['cooperating_aba_checks']={'control':control,'initial_source_hash':identity,'apply_B_status':apply_b['status'],'apply_A_status':apply_a['status'],'overlap':holder,'final_source_hash':ea.inspect(workspace)['source_hash'],'reconcile':ea.reconcile(workspace,receipt,expected_operation='overlap-aa',expected_source_hash=identity,required_checks=['value-check'],state_root=state) if receipt else None}

(ROOT/'probe-results.json').write_text(json.dumps(results,indent=2))
print(json.dumps({'crash':crash,'aba':{'control_status':control['status'],'apply_B_status':apply_b['status'],'apply_A_status':apply_a['status'],'overlap_status':receipt.get('status') if receipt else holder,'check':receipt.get('details') if receipt else None,'same_start_end':identity==ea.inspect(workspace)['source_hash'],'reconcile':results['cooperating_aba_checks']['reconcile']}},indent=2))
