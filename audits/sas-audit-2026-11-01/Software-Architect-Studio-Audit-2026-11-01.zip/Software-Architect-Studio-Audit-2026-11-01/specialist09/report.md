# Specialist 09 — Reliability, performance and operational architecture

Independent first pass, 2026-11-01. Source of record: [MahdiSh81/SOFTWARE-ARCHITECT-STUDIO at 1fa377cc9cbe7054d7edbf8091e22efaa296c05e](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/tree/1fa377cc9cbe7054d7edbf8091e22efaa296c05e). The root investigator verified GitHub master equals this execution mirror; this reviewer inspected the mirror and confirmed its HEAD and clean Git status. No other newly produced specialist report was read before this assessment. All new probes and reports are outside the target under `work/sas-audit-2026-11-01/specialist09/`. No installation, connection, publication, deployment or target modification occurred.

## 1. Executive assessment

Keep the local recoverable toolkit and its candid host boundary. It has useful byte/count bounds, fsync-backed publication, hash preconditions, revision journals, committed handoff generations, cache provenance and partial-outcome reporting. Two fresh counterexamples show that recovery availability and source-bound verification remain incomplete: abrupt process death leaves an unrecoverable-through-the-documented-command lock, and cooperating concurrent edits can make a check verify different bytes from its attributed source. These are confirmed P1 foundational reliability defects, not proof of hostile sandbox escape or project data loss.

The appropriate next release is a focused reliability hardening release. Hosted monitoring, distributed locks, global indexes and universal deployment automation would add infrastructure without fixing these local invariants. No production latency, uptime, cost, token-use or external recovery evidence was supplied; none is claimed.

## 2. Scope inspected

Inspected `tools/safe_io.py`, `revision_store.py`, `artifact_compiler.py`, `execution_adapter.py`, `operations_profile.py`, `repository_evidence.py`, `workflow_tools.py`, the relevant CLI routes and validation process wrapper; current README, adapter/integration documentation, operational skill and project-lifecycle reference; relevant existing test definitions; optional validator requirements and browser documentation. Historical operations report at `audits/sas-audit-2026-10-29/reviewers/expert09.md` was read only after current-source inspection and fresh probes.

Primary immutable evidence:

- [Lock and bounded IO implementation](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/safe_io.py#L68): writes lines68–90, lock lines99–105.
- [Revision commit and recovery](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/revision_store.py#L52): recovery lines52–78, commit lines80–102.
- [Adapter apply/check/reconcile](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/execution_adapter.py#L265): apply lock296; checks364–456; reconciliation486–524.
- [Committed handoff generations](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/artifact_compiler.py#L123): pointer123–126, recovery128–143, publication145–176.
- [Cache and coverage accounting](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/repository_evidence.py#L198): independent budgets198–206, cache256–311, explicit cooperative deadline313.
- [Operational skill](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/skills/delivery-and-operations/SKILL.md#L20) and [operational intent renderer](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/operations_profile.py).

## 3. Methodology

Source-first inspection distinguished implemented guarantees from explicit limitations. A synthetic probe used the actual unmodified toolkit modules with bytecode writes disabled. Probe A deliberately exited a child process immediately after a prepared revision journal was durably written. Probe B ran a source-reading assertion concurrently with two authorized adapter applies against the same workspace and state directory. A no-concurrency negative control established that the check fails against the attributed final source. Only scratch fixtures were changed.

Exact command: `PYTHONDONTWRITEBYTECODE=1 python -B /workspace/work/sas-audit-2026-11-01/specialist09/probe.py`. It exited0 after recording counterexamples; this is probe-script completion, not evidence the counterexamples passed their intended reliability properties. Raw evidence: `probe-results.json`. Elapsed command observation was 1.724 seconds on this execution host; it is not a performance benchmark. No whole-suite repetition, browser run or provider action was performed by this reviewer.

## 4. Verified strengths

| Capability | Capability classification | Evidence status | Practical limit |
|---|---|---|---|
| Bounded regular-file IO, no-follow POSIX directory operations and fsync attempts | Implemented, unverified | Directly inspected | This reviewer did not run a hostile race/power-loss campaign; non-POSIX fallback is explicitly weaker. |
| Expected-hash revision writes and validated recoverable journal | Verified tool-based | Successfully executed | Probe recovered the prepared revision after controlled scratch lock removal; no process-death lock recovery is built in. |
| Atomic handoff pointer plus immutable generation reader path | Implemented, unverified | Directly inspected | Legacy projections can be incomplete; this reviewer did not inject publication failure. |
| Refusal to replay unknown/partial adapter operations | Implemented, unverified | Directly inspected | Retained local state must be protected by the host; no authenticated audit-log claim. |
| Apply/check/reconcile real local operations with explicit authority | Verified tool-based | Successfully executed | Concurrent source attribution flaw OPS-102 applies. |
| Read/extraction limits and explicit cooperative scanner deadline | Implemented, unverified | Directly inspected | The cooperative deadline is not a hard wall-clock guarantee. |
| Cache hits labeled untrusted and freshness absence stays unknown | Implemented, unverified | Directly inspected | Cache improves extraction cost, not semantic truth; all observed bytes are still reread/hashed. |
| Operational intent stays distinct from runtime/deploy/restore evidence | Instruction-only | Directly inspected | `operations_profile.py` returns `not_run` for all execution/drill dimensions. |

## 5. Verified defects

### OPS-101 — P1: process death leaves a lock that blocks documented recovery

**Observed result.** Probe A initialized revision 1, then a child used `commit_project` and exited 91 immediately after writing a valid `status=prepared` revision journal. `.architecture.lock` remained. `recover(root)` raised `FileExistsError` on that lock before inspecting the journal. Controlled deletion of the lock in this disposable fixture allowed recovery to commit revision 2. No canonical bytes or last committed revision were lost in this probe.

**Cause and evidence.** `safe_io.py:99–105` implements ownership through exclusive lock-file creation and removes it only in Python `finally`; abrupt death bypasses cleanup. `revision_store.py:72–75` acquires that same lock before recovery. There is no stale-lock inspection/release operation or documented operator procedure in the inspected current README/docs/lifecycle reference. The general recovery contract in `references/project-lifecycle.md:7` therefore needs a liveness-qualified path. The same helper is used for project revisions, handoff publication/recovery and adapter apply state.

**Proposed change.** Prefer supported POSIX process-lifetime advisory locking for cooperating local writers, with precise unsupported-platform behavior. If lock-file ownership is retained, provide a read-only lock diagnosis and an explicit recovery procedure that preserves metadata, identifies host/process/start identity, refuses a live or uncertain owner, and rechecks expected canonical/journal hashes. Do not automatically remove an arbitrary existing lock based only on age or a reusable PID.

**Acceptance.** Abrupt exit at pre-journal, prepared-journal, canonical-replacement and committed-journal boundaries must preserve the last committed project, allow a documented safe recovery path, and advance an intended revision at most once. A live-writer fixture must remain excluded. Stale/unknown-host/PID-reuse fixtures must not delete an active owner's lock. Repeated recovery is idempotent; user edits and invalid journals stay untouched. Proposed operator-start-to-recovery target: <=60 seconds on the local fixture, subject to measurement; not achieved here as a product SLO.

**Risk/rollback.** Lock changes affect every writer and need migration tests with old lock files. Retain original journal/lock bytes. Roll back the lock implementation only on a quiescent workspace; never downgrade while writers run.

### OPS-102 — P1: concurrent cooperating edits defeat source-bound check attribution

**Observed result.** A scratch workspace began with `value.txt=A`. Its named assertion reads the file after 0.3 seconds, prints the value, waits 0.5 seconds and asserts `B`. On unchanged A the control check failed. During the next run, two fully authorized `apply_change` calls using the same selected root and state directory changed A→B, then B→A. Both applies returned `passed`. The check printed `OBSERVED=B` and returned `passed`, while its start/end source hashes both identifiedA and `source_changed=false`. `reconcile` returned `passed`, no issues, and proposed recording verification for that exactA source. The fixture demonstrates a false source correspondence, not a forged receipt or hostile-writer attack.

**Cause and evidence.** `apply_change` holds `project_lock(state)` at `execution_adapter.py:296`. `run_checks:390–450` observes source before/after but takes no shared writer lock across the command. `reconcile:505–506` verifies only that those endpoint hashes equal current source; an A→B→A sequence is invisible. A content hash identifies bytes at observation time and cannot establish which bytes a concurrent check read. Current host caveats do not make this particular receipt correspond to its claimed source.

**Proposed change.** Serialize cooperating apply and check operations on one canonical workspace lock, from initial identity capture through process completion and final capture; refuse/bound lock contention rather than silently overlap. Define one state/lock ownership mapping so a caller-selected alternate state root cannot accidentally create an independent cooperating lock. For hosts that cannot enforce this invariant, run checks against a read-only immutable source snapshot or downgrade source correspondence to unknown. Host isolation is still required against noncooperating writers and child processes.

**Acceptance.** The exact control must remain failed on A. During the overlap fixture the competing edit must be blocked until checking completes, or the result must be unknown/blocked/partial; no `passed` reconciliation for A may be issued from a check that read B. Test different operation IDs and alternate state-root selection, changed-source checks, timeout and receipt-write failure. Preserve explicit authority and non-replay behavior. Do not infer broad OS isolation from a passing cooperating-lock test.

**Risk/rollback.** Long checks increase lock contention; nested adapter writes from a check may deadlock unless explicitly refused or bounded. Keep lock acquisition deadlines/status visible. Roll back by disabling concurrent verification claims and retaining the existing inspect/propose/manual workflow, not by returning green evidence without correspondence.

## 6. Missing capabilities

**OPS-103 — P2 operational risk, not a demonstrated defect:** revision snapshots and immutable handoff generations have no inspected disk-retention/pruning contract (`revision_store.py:90–100`, `artifact_compiler.py:164–171`). Individual envelopes are bounded but cumulative retained storage is not. No disk-exhaustion failure was reproduced. Add read-only retained-byte/generation accounting and preflight free-space diagnostics first. Add opt-in reviewed retention only after defining referenced/current generations, recovery predecessors, privacy/purge and backup ownership; no automatic history deletion is justified by this audit.

No native production telemetry reader, remote deployment engine, distributed consensus, cross-device synchronization, power-loss certification or host-wide token/cost controller is established. These are Tool-dependent or Unsupported in this package, depending on the actual host mechanism, rather than broken existing services.

## 7. Risks

| Risk | Evidence | Mitigation and residual risk |
|---|---|---|
| Exact-source verification issued after transient source changes | Successfully executed OPS-102 | Cooperating lock/snapshot; hostile concurrent writers still require host isolation. |
| Recovery unavailable after abrupt writer death | Successfully executed OPS-101 | Process-lifetime locks or documented safe stale-owner recovery; no distributed safety implied. |
| Cumulative disk growth and cleanup errors | Directly inspected OPS-103 | Account/preflight before retention automation; backups and explicit purge remain operator responsibilities. |
| Hard host budgets inferred from logical metadata | Directly inspected `doctor`, capability metadata and scanner deadline note | Keep enforced/local/advisory/unsupported dimensions distinct; measure wall time and memory on representative workloads. |
| Lost browser state or private backup exposure | Documented in current browser/README materials | Export/backup; local storage remains unencrypted and quota-limited. No browser drill was performed here. |
| Provider timeouts retried as if no operation happened | Instruction-only operational workflow | Query actual operation identity/state before replay; actual integration remains untested. |

## 8. Redundant functionality

Compatibility exports in `project_workflows.py` are small and deliberate; no removal is justified from their existence. Main coordinator and operations skill overlap on SLO/recovery concepts but have different responsibility: architecture specifies intent; the specialist handles environment-scoped actions/evidence. Keep that ownership distinction. There is no demonstrated need for separate skills per cloud provider or an always-on orchestration service.

## 9. Recommended improvements

1. **OPS-I01 (P1, OPS-101):** local lock liveness and recovery contract; shared `safe_io`, revision/handoff/apply callers, lifecycle docs and interruption tests. Estimated2–4 engineer-days plus platform review; estimate, not measured effort.
2. **OPS-I02 (P1, OPS-102):** workspace-wide cooperating execution isolation/source correspondence; adapter and host-policy contract, concurrency tests and receipt limitation text. Estimated3–5 engineer-days; immutable snapshots may require a larger separate design.
3. **OPS-I03 (P2, OPS-103):** read-only storage accounting/free-space diagnostics and retention proposal. Estimated1–2 engineer-days for accounting only; deletion/migration is a separate reviewable scope.
4. **OPS-I04 (P2 opportunity):** fixed-corpus cold/warm timing and failure-recovery instruments after correctness fixes; source/tool/OS/hardware/limits recorded. Do not choose a universal p95, SLO or price before measuring representative use.

Dependencies: I01 defines lock ownership before I02 adopts it; I02 depends on process-lifecycle/isolation behavior of the host. Keep legacy state readable, version any changed identity/policy semantics, and require current-source regression evidence before release. One successful fixture does not establish optimized operational maturity.

## 10. Features to remove

No existing capability is proven valueless. Remove any unconditional assertion that a same-start/end hash alone proves the source checked, and any implication that a recover command can progress while a stale exclusive lock persists. Replace those claims with enforceable conditions and precise failure states. Do not remove immutable generations, journals or data-preserving conflict refusal to simplify the code.

## 11. Features to add

Add minimal lock inspection/liveness-safe recovery, shared execution isolation, storage accounting and reproducible operational evidence. Keep provider-specific actions optional and capability-discovered. Do not add hosted collaboration, distributed locking or automatic cloud resources without a separately justified product requirement.

## 12. ChatGPT compatibility assessment

The instruction and local-tool split is viable. Skills guide selection and output contracts; they do not supply a terminal, browser, credentials or deployment authority. In this host the local Python toolkit actually executed. Elsewhere a missing runner must produce a manual plan with blocked execution status. Project files and hashes are portable context, not automatic ChatGPT persistence or permission. ChatGPT-level cancellation, token ceilings and recurring monitoring cannot be promised by these skill files.

Maturity (0–5 supplied rubric) and confidence:

| Area | Level | Confidence/reason |
|---|---|---|
| Local revision and handoff design | 3 Repeatable | High source confidence; process-death availability gap prevents general validated recovery claim. |
| Adapter source-bound verification | 3 Repeatable | High: real fixture plus reproducible OPS-102 prevents broad level4 claim. |
| Scanner/cache budget reporting | 3 Repeatable | Medium: inspected scope, no new performance corpus. |
| Operational specification workflow | 2 Defined | High instruction confidence; real service outcomes unmeasured. |
| Production deployment/telemetry execution | 0 Absent natively | High package inspection; conditional host tools can separately supply execution. |
| Latency/token/cost optimization | 1 Ad hoc | Low evidence for actual user workloads; no percentile/cost baseline. |

## 13. Relevant plugin integrations

GitHub is the source-of-record and can separately expose Actions receipts; source publication is not a CI success receipt. A browser runner can verify workbench interactions if the host permits sockets/browser execution. Actual build/deploy/telemetry providers own environment operations; Studio should reconcile target/source/operation/check evidence. This specialist neither called nor verified a provider integration, and no automatic plugin-to-plugin communication is assumed. Current integration documentation supplies a contract, not evidence that a service was deployed.

## 14. Priority rankings

P1: OPS-101 and OPS-102, because they invalidate a core recovery path or exact-source verification promise with current reproducible input. Neither is assigned P0: no current project loss, unauthorized external effect or security compromise was shown. P2: bounded cumulative storage/accounting and representative workload instrumentation. P3/defer: hosted monitoring, distributed workspaces and provider expansion until demand and an operational owner justify them.

## 15. Evidence and confidence

Directly inspected source and immutable links support mechanisms. `probe.py` and retained JSON support Successfully executed counterexamples and controls. The no-concurrency check failed; overlapping check passed while printingB; start/end hash equality and successful reconciliation are retained verbatim in structured evidence. Recovery failure and successful post-unlock recovery are retained separately. Historical report claims are Based on historical reporting, not current test counts.

Historical reconciliation: previous missing inventory verifier/version/lock/receipt/descriptor issues have current implementations and declarations (`check_source_manifest.py`, common 0.9.1 identity, hash lock, typed run telemetry, descriptor diagnostics); this reviewer did not re-run every historical test and calls them implemented, unverified here. The optional operations handoff proposed historically is now present in `operations_profile.py` and compiler outputs. Historical advice explicitly listed active-versus-stale lock drilling; OPS-101 shows that liveness case still needs treatment. Parent QA independently owns whole-suite verification; its results are not relabeled as this reviewer's execution.

## 16. Proposed acceptance criteria

Release gate for I01/I02: deterministic negative control plus all interruption/ABA/concurrency fixtures above, with no false-green source attribution, no unexplained overwrite, no live-owner lock deletion, no duplicate committed revision, and explicit blocked/partial statuses. Preserve exact tool/source identity, invocation and per-stage outcomes. Required process checks must have completed and the host must disclose isolation limits.

Operational measurement plan: fixed source corpus, pinned tool/environment, separate cold/warm runs; retain wall time, peak RSS, visited/read/omitted files, bytes, cache hits, stop reasons, lock contention and recovery duration. Report median/p95 only after enough repeated declared runs; report sample count and workload limits. Token/cost-per-success requires actual host usage/pricing and a defined successful-task denominator. Proposed targets must remain provisional until measured. A storage report must account all managed generations/history, preserve unowned edits, and perform no deletion by default.

## 17. Unresolved questions

- Must Windows or network/shared filesystems be supported? Current declared runtime is Linux/POSIX Python 3.12; do not broaden from this probe.
- Does the intended host guarantee one canonical state directory and exclusive workspace execution? Current API permits alternate state roots and does not enforce it across checks.
- Which users need retained-generation pruning versus explicit backups/private purges?
- What representative workload and hardware define acceptable latency, memory and recovery targets?
- Which real provider operations are authorized and exposed in a deployment session? No such operation was needed for this read-only audit.

## 18. Final verdict

The design has credible local reliability primitives and honest boundaries. Harden lock liveness and check/source correspondence before making stronger execution-readiness claims. Preserve journals, immutable generations, cache uncertainty and partial-effect reporting. No measured user-value, production-performance or globally optimized reliability claim is justified by this bounded review. Target Git status remained clean at the frozen commit after all probes.
