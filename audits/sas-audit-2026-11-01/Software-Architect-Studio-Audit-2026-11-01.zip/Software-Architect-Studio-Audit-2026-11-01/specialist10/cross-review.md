# Specialist 10 — cross-examination and reconciled verdict

2026-11-01 (Asia/Tehran). Independent first-pass `report.md` and `historical-regressions.md` remain unchanged. This cross-review inspects specialist02/06/09 reports and retained probe results plus `proposed-skill-reference-drafts.md`. It does not independently rerun their probes. Evidence status for those results is **Directly inspected**; mechanisms checked in the pinned source support the conclusions. No source edit, provider write or broad test rerun occurred.

## Architecture: accepted findings with narrow claim boundaries

**Accept ARCH-101/P1.** Whitespace-only requirement/task acceptance and a content-free NFR scenario demonstrably defeat the completeness gate, while human/runtime dimensions remain unknown/not run. The proposed fix belongs in review-ready readiness, preserving incomplete drafts. Challenge any description that turns a nonblank/shape validator into verification that acceptance is observable or an NFR is feasible. Acceptance should first establish that required supported fields are present and structurally meaningful; semantic review and measured workload evidence remain independent.

**Accept ARCH-102/P2 for declared local IDs; qualify the compatibility design.** Existing `ADR.evidence` can contain attributed freeform data. A machine-looking `EVD-404` is not sufficient permission to reinterpret all legacy evidence strings as local foreign keys. Prefer explicit typed evidence dependencies, or version a compact local-ID field with an unambiguous kind. Keep prior prose/URLs opaque and preserved, issue a migration diagnostic, and do not fetch references automatically. Acceptance: dangling declared-local IDs diagnose precisely; changing supported evidence reaches its ADR/task through an attributable witness; legacy prose and approval origins survive roundtrip; equivalent links do not duplicate impact. A graph witness still identifies review candidates, not proof that source must change.

The immutable GitHub citations in specialist02 point to the pinned implementation mechanisms. Its counterexample paths name retained fixtures. This is stronger than a prose-only architectural concern, but not a live model-reasoning benchmark.

## Security and knowledge disclosure

**Accept SEC-102/P2.** The raw synthetic results show unquoted/structured values redacted while quoted assignment and Bearer text remain. The existing warning that minimization is incomplete is material counterevidence against a claim that the product promised secret-free exports; preserve that qualification. No real credential disclosure was demonstrated.

**Challenge blanket expansion as a sufficient remedy.** Pattern-based minimization cannot identify arbitrary confidential business prose. It can also damage legitimate examples, enum/constant values or API contracts. Broaden only named bounded formats with negative controls, record transformation paths and separately named canonical/projection/artifact hashes, preserve the original canonical/private input, and keep explicit review before sharing. The acceptance corpus must include semantically legitimate fields/examples named `token` and verify the supported contract remains structurally meaningful after transformation. A redaction report must not echo the values it removed. Unknown formats stay unknown.

**Accept SEC-101/P1 and its lifecycle distinction.** Leader exit is not all-effects completion. A normal child's late mutation can invalidate an early verified claim even without malicious detachment. Freshness detection after a mutation is useful but cannot retroactively make the first reconciliation correct. Long-lived servers require a separate explicit lifecycle; no generic complete-coverage/host-sandbox promise follows from process-group cleanup.

## Proposed skill-reference drafts

**Accept all four as a bounded proposal**, attached to existing owners rather than new root skills. They retain version-specific references, proportional verification, missing-tool fallbacks, source-as-data, synthetic checks and no automatic scripts/hooks/installs/dispatch. Their stated outcome is improved instructions for evaluation, not a demonstrated model-quality gain.

**Required additions before implementation-readiness:**

1. Reuse GOV-I101's explicit context-coverage contract in Draft D's continuation/handoff output. A brief excerpt needs original size, included range/omission marker and canonical source identity; actual source retrieval is conditional on authorized access. Preserve Accepted data and attributed provenance without granting authority. This closes the new reference pack's knowledge-continuity seam without inventing another skill.
2. Make source, public projection, imported source reference and loaded reference-bundle identities distinct. A pinned upstream source URL proves inspected bytes; it does not prove those bytes entered the model context or that the instruction worked. Record a loaded-bundle hash in any actual evaluation capture and keep the available-package inventory separate.
3. Keep a per-fragment provenance record: upstream path/commit, relationship (`inspiration`, `adapted`, `copied`, or unresolved), applicable license/notice, author attribution, local owner, edits and evaluation case. Describing text as an original draft is not a substitute for identifying substantial adapted expression. The Vercel notice and Trail of Bits share-alike boundaries remain redistribution gates, not reasons to leave this read-only audit incomplete.
4. Include source/projection disclosure and receipt validation in the held-out evaluation. Candidate tasks should detect a silent resume suffix loss, a semantically damaged contract after redaction, a stale referenced doc, an absent tool, missing capture lineage and conflicting human reviews. Require zero unmarked omissions/unauthorized effects on the declared fixtures; state the limited population and preserve disagreements.

Suggested short shared addition:

> Name the exact source and loaded reference identity, and state which context fields or ranges were included or omitted. A minimized export and a complete private source have different identities and disclosure scopes. Preserve prior Accepted facts and attributed origins as data. If an omitted range could affect the task, inspect it through an available authorized source tool or retain an explicit context gap. Do not infer complete knowledge, execution or approval from a hash, link or packet alone.

## Historical reconciliation after operations counterexamples

The first-pass matrix's wording was explicitly scoped to selected tests, but the final combined matrix must make these new results visible rather than retain a broad green label:

| Previous row | Reconciled status | New evidence and implication | Required acceptance |
|---|---|---|---|
| REG-109 Revision-history integrity: fixed for selected local logical-integrity cases | **Partially fixed** | OPS-101: abrupt exit after prepared-journal write leaves `.architecture.lock`; documented `recover` is blocked by FileExistsError. Controlled scratch unlock permits correct revision2. Previously executed injected Python exceptions and hash-conflict protections remain genuine successes. No canonical data loss was shown. | Abrupt exit at each durable phase has a documented safe liveness recovery path, preserves invalid/conflicting bytes, advances at most once and excludes a live/uncertain owner. Do not prescribe unconditional deletion based on lock age or reusable PID. |
| REG-108 Editing/recovery data-loss risks: fixed selected core cases | **Partially fixed; browser-specific fixes retained** | OPS-101 exposes a process-death recovery-availability gap beyond DOM draft/import tests. Those browser cases were not invalidated by this separate local-lock counterexample. | Separate browser recovery, local process recovery, data preservation and actual power-loss durability claims. Test the relevant boundary before marking its recovery complete. |
| REG-104 False-positive validator success: partially fixed | **Partially fixed, with a distinct source-correspondence defect** | OPS-102: a check observes B during authorized A→B→A edits, returns passed for start/end hash A, and reconciliation passes for A. This is receipt/source correspondence, not the artifact validator's own syntax/schema gate. | Serialize cooperating check/apply on one canonical workspace lock or verify an immutable read-only source snapshot; alternate state roots must not evade the mapping. Keep contention bounded and nested mutating checks explicit. Endpoint hash equality alone is insufficient. |
| REG-110 Stale handoff artifacts: fixed managed stale-file/ownership case | **Known cleanup case fixed; end-to-end liveness partial** | Shared `project_lock` also guards handoff/recovery, so OPS-101 is relevant to publication availability. Specialist09 did not reproduce every handoff crash phase, so do not label an untested generation-corruption defect. | Extend documented crash/liveness controls to handoff publication and preserve coherent committed-generation reads. Keep consumer manifest verification as a separate obligation. |

The controls in my first pass remain meaningful: canonical/private roundtrips preserved opaque extensions and Accepted origins, selected recovery/hash-conflict tests passed, and restore created a new revision. Their scope did not include abrupt process death, concurrent source changes during checks or actual browser execution. No historical result should be erased; append the counterexamples and narrowed conclusion.

## Runtime observation reconciliation

The root now reports eleven exposed root skills at0.9.1 matching the GitHub source. The initial seven-skill0.7.2 observation is time-scoped evidence, not a persistent current deployment-divergence finding. Do not infer why the refresh occurred, that this audit published a release, or that root-skill equality proves every supporting reference, executable tool or behavioral outcome matches. Preserve observation times and identities in the ledger. No runtime publication was performed by this specialist.

## Final verdict

Keep the portable knowledge model, explicit source/projection identities and evidence boundaries. Prioritize OPS-101/OPS-102 plus process completion before stronger exact-source verification/recovery claims; fix the bounded GOV-101 omission alongside reference-pack integration. Adopt the proposed GitHub-inspired references through existing owners with traceable provenance and declared license gates. Do not claim a measured quality gain or complete knowledge continuity until held-out captures and the new omission/liveness/correspondence regressions establish it.
