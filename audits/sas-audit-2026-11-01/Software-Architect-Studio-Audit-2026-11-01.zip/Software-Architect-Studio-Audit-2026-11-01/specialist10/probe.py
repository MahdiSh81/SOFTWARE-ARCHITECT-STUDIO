import json, pathlib, sys, subprocess, tempfile, unittest, os
BASE=pathlib.Path('/workspace/SOFTWARE-ARCHITECT-STUDIO'); OUT=pathlib.Path('/workspace/work/sas-audit-2026-11-01/specialist10')
sys.path.insert(0,str(BASE/'tools'))
from project_model import new_project,require_project,resume_packet,supersede
from codec import digest,dumps
from revision_store import init_project,load_project,snapshot,commit_project,restore,recover
from artifact_compiler import compile_plan
p=new_project('Continuity probe');p['brief']='A'*4000+' CRITICAL: data must remain in EU';p['extension']={'private':'opaque continuity sentinel'};p['decisions']=[{'id':'ADR-001','title':'Retain history','decision':'Use local backup','status':'Accepted','approval_origin':'synthetic prior decision'}]
require_project(p)
py=resume_packet(p)
js='const C=require('+json.dumps(str(BASE/'workbench/project-core.js'))+');let s="";process.stdin.on("data",x=>s+=x);process.stdin.on("end",()=>{const p=JSON.parse(s),state=C.importDocument(p),back=C.importDocument(JSON.parse(JSON.stringify(state)));console.log(JSON.stringify({resume:C.resume(p),roundtrip:C.sameJSON(p,back.project),status:back.project.decisions[0].status,extension:back.project.extension}));});'
r=subprocess.run(['node','-e',js],input=json.dumps(p),capture_output=True,text=True,timeout=5,check=True);node=json.loads(r.stdout)
files,rep=compile_plan(p,include_private=True)
with tempfile.TemporaryDirectory(dir=OUT) as tmp:
 root=pathlib.Path(tmp)/'project';init_project(root,'probe');q=load_project(root);q['brief']='first';q['custom']={'retained':True};q['decisions']=p['decisions'];commit_project(root,q,'Record intent',digest(load_project(root)));snapshot(root,'Before change');q=load_project(root);q['brief']='changed';commit_project(root,q,'Change intent',digest(load_project(root)));restore(root,2,digest(load_project(root)),'Restore as new revision');restored=load_project(root)
 lifecycle={'revision':restored['revision'],'brief':restored['brief'],'accepted':restored['decisions'][0]['status'],'custom':restored['custom'],'history_records':len(list((root/'.architecture-history').glob('commit-*.json'))),'recover_status':recover(root)['status']}
result={'python_resume':{'source_brief_chars':len(p['brief']),'packet_brief_chars':len(py['brief']),'sentinel_present':'data must remain in EU' in py['brief'],'fields':list(py),'acceptance_preserved':py['accepted_decisions'][0]['approval_origin']=='synthetic prior decision'},'js_resume':{'brief_chars':len(node['resume']['brief']),'sentinel_present':'data must remain in EU' in node['resume']['brief']},'canonical_roundtrip':{'node_lossless':node['roundtrip'],'node_accepted':node['status'],'node_extension':node['extension'],'python_private_lossless':json.loads(files['project.json'])==p},'revision_restore':lifecycle,'target_head':subprocess.check_output(['git','-C',str(BASE),'rev-parse','HEAD'],text=True).strip()}
(OUT/'probe-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
sys.path.insert(0,str(BASE/'tests'))
from test_release import ReleaseTests
from test_audit_followups import AuditFollowupTests
names=['test_missing_envelope_rejected','test_invalid_shapes_are_diagnostics','test_snapshot_failure_retries_without_double_revision','test_history_projection_failure_recoverable','test_commit_conflict_preserves_project','test_restore_as_new_revision','test_supersede_preserves_predecessor','test_stale_owned_adr_removed_and_unowned_note_preserved','test_cache_preserves_unrelated_file','test_numeric_overflow_nan_and_nonfinite_weights']
suite=unittest.TestSuite([ReleaseTests(n) for n in names]+[AuditFollowupTests(n) for n in ['test_openapi_security_scheme_must_be_declared','test_committed_journal_mismatch_preserves_current_project_and_history','test_handoff_identity_distinguishes_canonical_and_projection_hashes']])
with (OUT/'focused-tests.log').open('w') as stream:res=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
print({'selected_tests':res.testsRun,'failures':len(res.failures),'errors':len(res.errors),'skips':len(res.skipped)})
