# Specialist 10 — Knowledge management, documentation and developer experience

Independent first pass, 1 November 2026 (Asia/Tehran). Source of record: [MahdiSh81/SOFTWARE-ARCHITECT-STUDIO at 1fa377cc9cbe7054d7edbf8091e22efaa296c05e](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/tree/1fa377cc9cbe7054d7edbf8091e22efaa296c05e). Local files are an execution mirror of that pinned source. No new specialist report was read during this first pass. Target files were not modified; scratch files and synthetic project fixtures were kept in this report directory.

## 1. Executive assessment

Retain the canonical project, Accepted-decision provenance, explicit revision/restore workflow, immutable handoff generations and separate private/shareable disclosure profiles. They form a useful engineering continuity system with honest local-storage boundaries. There is no basis to replace them with a hosted knowledge service or semantic index.

One independently reproduced continuity defect remains: **GOV-101 (P2)**. Python `resume_packet` silently removes brief content beyond character 4,000 while the browser packet retains it. A 4,033-character valid brief lost its final 33-character data-residency constraint in the CLI packet. Canonical source bytes were preserved: this is lossy, unmarked context projection, not stored-project data loss. Historical PROD-005 therefore remains partially fixed at a length boundary.

Most requested historical regression classes have meaningful scoped repairs, but a broad claim that all validation/behavioral/repository risks are fixed would exceed the evidence. See `historical-regressions.md`.

## 2. Scope inspected

Current README and recipes; canonical project model; revision store, safe IO and artifact compiler; browser core and Node fixture definitions; validation and repository-evidence logic; calculators; capture/review instruments; implementation ledger, 0.9.1 follow-ups and historical test assertions. Exact files include:

- `tools/project_model.py:18–129` and `schemas/project-v2.schema.json`.
- `tools/revision_store.py:15–117`; `tools/artifact_compiler.py:54–176`.
- `workbench/project-core.js:40–56`; `tests/test_workbench.cjs:7–45`.
- `tools/evaluation_records.py:25–159`; `docs/recipes.md`.
- `release/implementation-0.9.0.json`; `release/followups-0.9.1.json`.

Primary immutable references: [project model](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/project_model.py#L110), [browser continuity](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/workbench/project-core.js#L43), [revision store](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/revision_store.py#L80), [handoff compiler](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/artifact_compiler.py#L54).

## 3. Methodology

Inspect the current implementation before interpreting the historical ledger. Test a boundary counterexample rather than equating declared contracts with behavior. Execute narrowly selected existing regressions in disposable directories; do not rerun the full suite owned by the QA specialist. Set `PYTHONDONTWRITEBYTECODE=1`. Compare the actual Python and Node surfaces. Preserve distinctions between canonical lossless backup, intentionally minimized sharing and compact resume projection.

Executed: `PYTHONDONTWRITEBYTECODE=1 python .../specialist10/probe.py`. It performs independent continuity fixtures and 13 selected existing unittest methods. Results: `probe-results.json`, `focused-tests.log`, and source `probe.py`. All 13 selected tests passed, zero failures/errors/skips. These are local toolkit tests, not proof of a live ChatGPT session or human user outcomes.

## 4. Verified strengths

| Capability | Classification | Evidence status | Result/limit |
|---|---|---|---|
| Canonical unknown-field preservation | Verified tool-based | Successfully executed | Synthetic Node project roundtrip and Python `include_private=True` handoff both equal the input, including an opaque extension. |
| Accepted decision continuity | Verified tool-based | Successfully executed | Accepted state and supplied approval origin survive resume/roundtrip/restore. No tool authority is granted by the data. |
| Restore as new revision | Verified tool-based | Successfully executed | Independent init/commit/snapshot/change/restore ended at revision 5, restored the earlier brief/extension/Accepted decision, retained four history commit records. |
| Conflict-safe local recovery | Verified tool-based | Successfully executed | Selected expected-hash, injected snapshot/history-failure and committed-journal/current-hash mismatch tests passed. Scope: cooperating local writers. |
| Owned stale handoff cleanup | Verified tool-based | Successfully executed | Selected test removes a managed stale ADR, retains an unrelated note. |
| Representation identities | Verified tool-based | Successfully executed | Selected canonical/projection/artifact-identity regression passed. Hashes identify bytes, not authenticity. |
| Honest storage and evidence boundaries | Implemented, unverified | Directly inspected | Recipes distinguish browser DOM checks, runtime checks, restores, lexical fixtures, actual captures and user studies. End-user comprehension was not measured. |

## 5. Verified defects

### GOV-101 — Unmarked CLI resume truncation and cross-surface inconsistency (P2)

**Trigger:** a valid canonical brief longer than 4,000 Unicode code points.

**Actual:** `tools/project_model.py:112` uses `p.get('brief','')[:4000]`. No field reports truncation, original length or a source range. `workbench/project-core.js:56` returns the whole brief. The independent fixture uses 4,000 `A` characters followed by ` CRITICAL: data must remain in EU`; source length is 4,033, Python packet length 4,000 and the constraint disappears; Node packet length is 4,033 and retains it. Both paths retain Accepted provenance.

**Impact:** a consumer that treats the CLI packet as complete continuation context can reason without a constraint present in the source. The source hash still identifies the full canonical document, but it does not reveal which content the packet omitted. This is a projection defect; the canonical file is intact.

**Evidence:** `probe-results.json`; [project_model.py:110–116](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/tools/project_model.py#L110); [project-core.js:56](https://github.com/MahdiSh81/SOFTWARE-ARCHITECT-STUDIO/blob/1fa377cc9cbe7054d7edbf8091e22efaa296c05e/workbench/project-core.js#L56). Evidence status: Successfully executed and Directly inspected. Confidence: high. Capability classification: Partial.

**Disposition:** IMPROVE the existing continuity output, rather than add a new knowledge-management skill.

## 6. Missing capabilities

Automatic cross-chat/device persistence, authenticated reviewer identity, representative human-use outcome evidence and hosted multi-user concurrency are not established. Current source explicitly avoids claiming them. These are absent/unknown outcomes or conditional infrastructure, not hidden defects. A source-aware coverage contract for resume excerpts is missing and justified by GOV-101.

## 7. Risks

Local browser data is unencrypted and quota-limited; Git/backups must actually exist for durable continuity. A source digest cannot authenticate acceptance or authorize actions. Human-generated provenance fields remain attributed data. Raw private backups may retain secrets/history and require deliberate disclosure. An artifact manifest establishes intended generation identity only when a consumer checks it. Context omitted from a resume packet can still be relevant to a subsequent task. A hosted service would introduce authorization, ownership, retention and conflict costs not justified by current demand evidence.

## 8. Redundant functionality

Python and browser deliberately implement overlapping portable core operations, which supports an offline browser and CLI; merging them into one host-only engine would lose that option. Their duplicated contracts require shared fixtures/parity checks. There is no evidence that the eleven skills need a separate documentation, history, restore or memory skill; those concerns should remain shared output/continuity standards. Do not duplicate semantic claims in release ledgers, skill prose and generated receipts as if each were independent proof.

## 9. Recommended improvements

**Initiative GOV-I101 (P2, small-to-medium effort, estimate not measured): explicit context-projection coverage.**

- Current: Python uses an unmarked 4,000-character slice; Node returns a full brief.
- Outcome: every resume consumer can tell whether it has the full brief and retrieve a precise authorized remainder.
- Design: use one versioned resume projection contract across CLI/browser. Include canonical project/source identity, `context_coverage` entries naming each included/excluded field, `original_characters`, included ranges and `truncated` reason. A bounded excerpt is acceptable; silent truncation is not. Do not make raw private history/extensions active context.
- Affected components: `tools/project_model.py`, `workbench/project-core.js`, lifecycle reference and cross-surface fixture tests. No external tool or new infrastructure required.
- Error handling: refuse unsupported projection versions; keep canonical input unchanged. If omitted source cannot be read, return an explicit context gap and limit conclusions.
- Security: preserve current Accepted data/authority boundary and private-history exclusions. Retrieve source only through actual authorized access.
- Acceptance: 3,999/4,000/4,001-character, non-ASCII, empty/absent brief fixtures; every omitted suffix has an explicit truncation/range record; source digest identifies the same canonical project on both surfaces; Accepted origin and opaque canonical fields remain unchanged; no hidden source loss; complete and partial consumer behavior tested.
- Regression: canonical roundtrip/property fixture; parity of coverage semantics; sentinel after budget; new revision/Accepted preservation. No need to impose whole-suite UI tests on a prose-only change.
- Rollback: keep a compatibility adapter for current packet fields; additive coverage metadata can be ignored by old consumers, but new consumers must treat absent coverage as unknown completeness.
- Metric: unmarked omissions on the fixed boundary fixtures = 0. Real-task continuation correction burden remains unmeasured until actual observations exist.

Proposed shared instruction draft:

> When resuming work, identify the actual canonical project revision and source hash. State which context fields or source ranges were included, excerpted or omitted. Never present a bounded excerpt as the complete brief. Read the relevant authorized source when omitted content could affect the current task; if it cannot be read, preserve the gap explicitly. Retain prior Accepted decisions and their attributed approval origins without converting them into tool permissions. Keep private history and opaque extensions outside active instructions unless the user has deliberately requested the relevant data.

## 10. Features to remove

No current feature merits unconditional removal from this review. Remove any future claim of automatic memory/sync, authenticated acceptance, complete recovery certification or semantic quality based only on fixture/record validation. These are claim limits, not evidence that the current source makes all such claims. Replace silent truncation with a declared projection.

## 11. Features to add

Add context coverage metadata and on-demand source-range retrieval behavior to the existing resume workflow. Retain a compact task/source/evidence checklist in handoff documentation: identity, accepted constraints, exact delivered paths, checks and unresolved gaps. This is one shared contract improvement; no new top-level skill is proposed. A hosted knowledge store remains DEFER until demand/owner/security requirements justify it.

## 12. ChatGPT compatibility assessment

The current design is compatible with instruction/skill-based reasoning plus conditional tools. Local CLI and HTML are host-mediated artifacts, not automatically executed or synchronized by the plugin. An uploaded canonical JSON or an authorized GitHub file can support user-mediated continuation without a local runner. Source retrieval and execution must reflect actual exposed tools. Adding coverage metadata is feasible in the present repository and can be consumed in ordinary ChatGPT text workflows; publishing that source to the installed plugin is a distinct release action.

## 13. Relevant plugin integrations

BUILD IN: canonical identity, decision semantics, disclosure/context coverage and evidence interpretation. INTEGRATE only through an actually available authorized GitHub read tool for pinned source and a storage tool when requested. USE ALONGSIDE: document/task providers via minimized, versioned one-way handoff until conflict semantics are validated. DO NOT ADOPT: automatic bidirectional sync or hosted memory solely because a catalog offers storage. This specialist did not probe provider installations/scopes/costs; integration specialist owns current discovery. No service was connected or written.

## 14. Priority rankings

1. P2 GOV-101/GOV-I101: bounded continuity output must disclose omission.
2. P2 retain cross-surface parity fixtures and explicit identity/disclosure boundaries.
3. P2 collect actual held-out continuation/handoff observations before claiming reduced correction burden.
4. P3 conditional task/storage publication with revisioned handoff, after verified schemas and authorization.
5. DEFER hosted collaboration and semantic memory until real demand and operating ownership exist.

No P0 or P1 knowledge-specific defect was demonstrated in this independent review.

## 15. Evidence and confidence

| Area | Maturity | Confidence | Reason |
|---|---|---|---|
| Canonical portable state and Accepted provenance | 4 — Validated within selected local scope | High | Independent Python/Node roundtrip plus selected controls. No cross-platform/host authenticity claim. |
| Local revision/restore/recovery | 4 — Validated within selected local scope | High | Independent sequence and injected-failure controls. No distributed or hostile-writer safety claim. |
| Resume projection | 3 — Repeatable, with a confirmed completeness gap | High | Python/Node discrepancy directly reproduced. |
| Handoff/provenance/documentation | 3 — Repeatable; selected identity/ownership checks validated | Medium-high | Compiler and fixtures inspected; end-user understanding not measured. |
| Live user value and AI engineering quality | Unknown | Low | Records/instruments do not supply actual representative outcomes. |

The 13-test results are newly executed. The historical 67 Python/14 workbench and release 193/37/9 claims remain historical within this specialist's evidence; this specialist does not relabel them current. The QA specialist's separate fresh ledger may establish current suite outcomes. See `focused-tests.log` for exact test method names.

## 16. Proposed acceptance criteria

A complete continuation workflow must preserve the source project identity, prior Accepted content/provenance and unknown canonical fields; restore must create a new revision and preserve conflicting drafts; every excluded/excerpted field must have explicit coverage metadata; canonical input and minimized export hashes must name their representations; handoff readers must select one committed generation and verify the required artifact inventory; actual checks/unrun gaps must be distinct. Human task-completion/error metrics require actual consented observations and retained disagreement, not manufactured scores.

For GOV-I101, pass all stated boundary fixtures and demonstrate that a consumer either reads the trailing data-residency constraint or explicitly refuses to treat context as complete. A passing source schema alone is insufficient.

## 17. Unresolved questions

Which continuation paths do users actually use (uploaded JSON, browser clipboard, CLI packet, GitHub)? What measurable correction burden does each produce? Which omitted brief regions are most likely to contain hard constraints? What retention/audience do real users need for backups and handoffs? Does the installed plugin contain this GitHub source version? These questions do not block preparing the source-level fix; they do block claims of user impact magnitude and deployed behavior.

## 18. Final verdict

KEEP the portable, source-attributed continuity foundation. IMPROVE explicit coverage and cross-surface parity. Separate canonical backup, minimized handoff and resume excerpt semantics. Do not add a memory service or another skill merely to fill a category. The evidence supports a targeted source-level repair and a disciplined continuation benchmark, not a wholesale redesign.
